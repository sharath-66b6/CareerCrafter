import '/flutter_flow/flutter_flow_util.dart';
import 'editdistance_widget.dart' show EditdistanceWidget;
import 'package:flutter/material.dart';

class EditdistanceModel extends FlutterFlowModel<EditdistanceWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
