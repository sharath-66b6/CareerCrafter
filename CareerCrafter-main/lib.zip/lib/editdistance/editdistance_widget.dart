import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'editdistance_model.dart';
export 'editdistance_model.dart';

class EditdistanceWidget extends StatefulWidget {
  const EditdistanceWidget({super.key});

  @override
  State<EditdistanceWidget> createState() => _EditdistanceWidgetState();
}

class _EditdistanceWidgetState extends State<EditdistanceWidget> {
  late EditdistanceModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => EditdistanceModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Edit Distance',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \nGiven two strings A and B, find the minimum number of steps required to convert A to B. (each operation is counted as 1 step.)\n\nYou have the following 3 operations permitted on a word:\n\nInsert a character\nDelete a character\nReplace a character\n\n\nInput Format:\n\nThe first argument of input contains a string, A.\nThe second argument of input contains a string, B.\nOutput Format:\n\nReturn an integer, representing the minimum number of steps required.\nConstraints:\n\n1 <= length(A), length(B) <= 450\nExamples:\n\nInput 1:\n    A = \"abad\"\n    B = \"abac\"\n\nOutput 1:\n    1\n\nExplanation 1:\n    Operation 1: Replace d with c.\n\nInput 2:\n    A = \"Anshuman\"\n    B = \"Antihuman\"\n\nOutput 2:\n    2\n\nExplanation 2:\n    => Operation 1: Replace s with t.\n    => Operation 2: Insert i.\n\n\n\n\n\nAnswer :-\n/**\n * @input A : String termination by \' * @input B : String termination by \' * \n * @Output Integer\n */\nint min(int a, int b) {\n    return a<b?a:b;\n}\nint Minimum(int a, int b, int c) {\n    return min(min(a,b),c);\n}\nint minDistance(char* X, char* Y)\n{\n    // Cost of alignment\n    int cost = 0;\n    int leftCell, topCell, cornerCell, i, j;\n \n    int m = strlen(X)+1;\n    int n = strlen(Y)+1;\n \n    // T[m][n]\n    int *T = (int *)malloc(m * n * sizeof(int));\n \n    // Initialize table\n    for(i = 0; i < m; i++)\n        for(j = 0; j < n; j++)\n            *(T + i * n + j) = -1;\n \n    // Set up base cases\n    // T[i][0] = i\n    for(i = 0; i < m; i++)\n        *(T + i * n) = i;\n \n    // T[0][j] = j\n    for(j = 0; j < n; j++)\n        *(T + j) = j;\n \n    // Build the T in top-down fashion\n    for(i = 1; i < m; i++)\n    {\n        for(j = 1; j < n; j++)\n        {\n            // T[i][j-1]\n            leftCell = *(T + i*n + j-1);\n            leftCell += 1; // deletion\n \n            // T[i-1][j]\n            topCell = *(T + (i-1)*n + j);\n            topCell += 1; // insertion\n \n            // Top-left (corner) cell\n            // T[i-1][j-1]\n            cornerCell = *(T + (i-1)*n + (j-1) );\n \n            // edit[(i-1), (j-1)] = 0 if X[i] == Y[j], 1 otherwise\n            cornerCell += (X[i-1] != Y[j-1]); // may be replace\n \n            // Minimum cost of current cell\n            // Fill in the next cell T[i][j]\n            *(T + (i)*n + (j)) = Minimum(leftCell, topCell, cornerCell);\n        }\n    }\n \n    // Cost is in the cell T[m][n]\n    cost = *(T + m*n - 1);\n    free(T);\n    return cost;\n}',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=eMnyEDYGobA&pp=ygUaaW50ZXJ2aWV3Yml0IGVkaXQgZGlzdGFuY2U%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
