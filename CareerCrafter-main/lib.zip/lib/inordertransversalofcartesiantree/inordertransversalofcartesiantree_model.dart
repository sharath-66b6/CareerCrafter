import '/flutter_flow/flutter_flow_util.dart';
import 'inordertransversalofcartesiantree_widget.dart'
    show InordertransversalofcartesiantreeWidget;
import 'package:flutter/material.dart';

class InordertransversalofcartesiantreeModel
    extends FlutterFlowModel<InordertransversalofcartesiantreeWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
