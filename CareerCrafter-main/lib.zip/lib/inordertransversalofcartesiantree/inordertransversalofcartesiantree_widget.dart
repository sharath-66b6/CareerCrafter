import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'inordertransversalofcartesiantree_model.dart';
export 'inordertransversalofcartesiantree_model.dart';

class InordertransversalofcartesiantreeWidget extends StatefulWidget {
  const InordertransversalofcartesiantreeWidget({super.key});

  @override
  State<InordertransversalofcartesiantreeWidget> createState() =>
      _InordertransversalofcartesiantreeWidgetState();
}

class _InordertransversalofcartesiantreeWidgetState
    extends State<InordertransversalofcartesiantreeWidget> {
  late InordertransversalofcartesiantreeModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model =
        createModel(context, () => InordertransversalofcartesiantreeModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Inorder Traversal of Cartesian Tree',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2000.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \nGiven two binary trees, write a function to check if they are equal or not.\n\nTwo binary trees are considered equal if they are structurally identical and the nodes have the same value.\n\nReturn  0 / 1  ( 0 for false, 1 for true ) for this problem\n\nExample :\n\nInput : \n\n   1       1\n  / \\     / \\\n 2   3   2   3\n\nOutput : \n  1 \n\n\n\n\nAnswer :-\nint isSameTree(treenode* A, treenode* B) {\n    if(A==NULL && B== NULL) return 1;\n    if(A!=NULL && B==NULL) return 0;\n    if(A==NULL && B!=NULL) return 0;\n    if(A->val==B->val && isSameTree(A->left,B->left) && isSameTree(A->right,B->right)) return 1;\n    else return 0;\n    \n}\nGiven an inorder traversal of a cartesian tree, construct the tree.\n\nCartesian tree :  is a heap ordered binary tree, where the root is greater than all the elements in the subtree.\n\nNote: You may assume that duplicates do not exist in the tree.\n\nExample :\n\nInput : [1 2 3]\n\nReturn :   \n          3\n         /\n        2\n       /\n      1\n\n\n\nAnswer :-\nint cmpfunc(const void *a,const void *b)\n{\n    return (*(int*)a - *(int *)b);\n}\nint max(int *A,int left,int right)\n{\n    int m=left,i;\n    if(left==right) return left;\n    for(i=left+1;i<=right;i++)\n    {\n        if(A[m]<A[i])\n        m = i;\n    }\n    return m;\n}\n\n\ntreenode *construct(int *A,int left,int right)\n{\n    int index;\n    if(left<=right)\n    {\n        index = max(A,left,right);\n        treenode *root = (treenode *)malloc(sizeof(treenode));\n        root->val = A[index];\n        root->left = construct(A,left,index-1);\n        root->right = construct(A,index+1,right);\n        return root;\n    }\n    if(left>right) return NULL;\n}\n\ntreenode* buildTree(int* A, int n1) {\n    //qsort(A,n1,sizeof(int),cmpfunc);\n    treenode *root;\n    root = construct(A,0,n1-1);\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=wv4XfOcIQWg&pp=ygUyaW50ZXJ2aWV3Yml0IGlub3JkZXIgdHJhbnN2ZXJzYWwgb2YgY2FydGVzaWFuIHRyZWU%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
