import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'disjointintervals_model.dart';
export 'disjointintervals_model.dart';

class DisjointintervalsWidget extends StatefulWidget {
  const DisjointintervalsWidget({super.key});

  @override
  State<DisjointintervalsWidget> createState() =>
      _DisjointintervalsWidgetState();
}

class _DisjointintervalsWidgetState extends State<DisjointintervalsWidget> {
  late DisjointintervalsModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => DisjointintervalsModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Disjoint Intervals',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2400.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nGiven a set of N intervals denoted by 2D array A of size N x 2, the task is to find the length of maximal set of mutually disjoint intervals.\n\nTwo intervals [x, y] & [p, q] are said to be disjoint if they do not have any point in common.\n\nReturn a integer denoting the length of maximal set of mutually disjoint intervals.\n\n\n\nProblem Constraints\n1 <= N <= 105\n\n1 <= A[i][0] <= A[i][1] <= 109\n\n\n\nInput Format\nFirst and only argument is a 2D array A of size N x 2 denoting the N intervals.\n\n\n\nOutput Format\nReturn a integer denoting the length of maximal set of mutually disjoint intervals.\n\n\n\nExample Input\nInput 1:\n\n A = [\n       [1, 4]\n       [2, 3]\n       [4, 6]\n       [8, 9]\n     ]\nInput 2:\n\n A = [\n       [1, 9]\n       [2, 3]\n       [5, 7]\n     ]\n\n\nExample Output\nOutput 1:\n\n 3\nOutput 2:\n\n 2\n\n\nExample Explanation\nExplanation 1:\n\n Intervals: [ [1, 4], [2, 3], [4, 6], [8, 9] ]\n Intervals [2, 3] and [1, 4] overlap.\n We must include [2, 3] because if [1, 4] is included thenwe cannot include [4, 6].\n We can include at max three disjoint intervals: [[2, 3], [4, 6], [8, 9]]\nExplanation 2:\n\n Intervals: [ [1, 9], [2, 3], [5, 7] ]\n We can include at max two disjoint intervals: [[2, 3], [5, 7]]\n\n\n\n\nAnswer :-\n/**\n * @input A : 2D integer array \n * @input n11 : Integer array\'s ( A ) rows\n * @input n12 : Integer array\'s ( A ) columns\n * \n * @Output Integer\n */\n \ntypedef struct Time {\n    int start;\n    int end;\n}time;\n\nint cmpfunc(const void *a, const void *b) {\n    const time *t1 = *((time**)a);\n    const time *t2 = *((time**)b);\n  //    printf(\"\'%d %d\'\",  t1->end,  t2->end);\n    return t1->end - t2->end;\n}\nint solve(int** A, int n11, int n12) {\n    if (n11 ==0 || n12 == 0) {\n        return 0;\n    }\n    int i =0;\n    time **t = (time**)malloc(sizeof(time*)*n11);\n    for (i = 0; i < n11; i++) {\n        t[i] = (time*)malloc(sizeof(time)*n12);\n        t[i]->start = A[i][0];\n        t[i]->end = A[i][1];\n    }\n      for (i = 0; i < n11; i++) {\n //   printf(\"%d %d-\",  t[i]->start,  t[i]->end);\n         \n     }\n    qsort(t, n11, sizeof(time), cmpfunc);\n     for (i = 0; i < n11; i++) {\n   //  printf(\"%d %d-\",  t[i]->start,  t[i]->end);\n         \n     }\n    int count = 1;\n    int  endtime = t[0]->end;\n    for (i = 1; i < n11; i++) {\n        if (t[i]->start > endtime) {\n        //    printf(\"endtime %d\", endtime);\n            count++;\n            endtime = t[i]->end;\n        }\n    }     \n    return count;\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=VavHRCO1sSo&pp=ygUfaW50ZXJ2aWV3Yml0IGRpc2pvaW50IGludGVydmFscw%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
