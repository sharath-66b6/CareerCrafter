import '/flutter_flow/flutter_flow_util.dart';
import 'disjointintervals_widget.dart' show DisjointintervalsWidget;
import 'package:flutter/material.dart';

class DisjointintervalsModel extends FlutterFlowModel<DisjointintervalsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
