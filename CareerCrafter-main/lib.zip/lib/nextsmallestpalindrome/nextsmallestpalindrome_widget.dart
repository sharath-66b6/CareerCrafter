import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'nextsmallestpalindrome_model.dart';
export 'nextsmallestpalindrome_model.dart';

class NextsmallestpalindromeWidget extends StatefulWidget {
  const NextsmallestpalindromeWidget({super.key});

  @override
  State<NextsmallestpalindromeWidget> createState() =>
      _NextsmallestpalindromeWidgetState();
}

class _NextsmallestpalindromeWidgetState
    extends State<NextsmallestpalindromeWidget> {
  late NextsmallestpalindromeModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => NextsmallestpalindromeModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Next Smallest Palindrome!',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 3000.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nGiven a numeric string A representing a large number you need to find the next smallest palindrome greater than this number.\n\n\n\nProblem Constraints\n1 <= |A| <= 100\n\nA doesn\'t start with zeroes and always contain digits from 0-9.\n\n\n\nInput Format\nFirst and only argument is an string A.\n\n\n\nOutput Format\nReturn a numeric string denoting the next smallest palindrome greater than A.\n\n\n\nExample Input\nInput 1:\n\n A = \"23545\"\nInput 2:\n\n A = \"999\"\n\n\nExample Output\nOutput 1:\n\n \"23632\"\nOutput 2:\n\n \"1001\"\n\n\n\nAnswer :- \n/**\n * @input A : String termination by \'\\0\'\n * \n * @Output string. Make sure the string ends with null character\n */\n//https://www.geeksforgeeks.org/given-a-number-find-next-smallest-palindrome-larger-than-this-number/\nvoid generateNextPalindromeUtil (char *A, int n) \n{ \n    // find the index of mid digit \n    int mid = n / 2; \n  \n    // A bool variable to check if copy of left side to right is sufficient or not \n    int leftsmaller = 0; \n  \n    // end of left side is always \'mid -1\' \n    int i = mid - 1; \n  \n    // Beginning of right side depends if n is odd or even \n    int j = (n % 2)? mid + 1 : mid; \n  \n   // Initially, ignore the middle same digits  \n    while (i >= 0 && A[i] == A[j]) {\n        i--;\n        j++; \n    }\n  \n    // Find if the middle digit(s) need to be incremented or not (or copying left  \n    // side is not sufficient) \n    if (i < 0 || A[i] < A[j]) \n        leftsmaller = 1; \n  \n    // Copy the mirror of left to tight \n    while (i >= 0) \n    { \n        A[j] = A[i]; \n        j++; \n        i--; \n    }\n    //printf(\"1:%s\\n\", A);\n  \n    // Handle the case where middle digit(s) must be incremented.  \n    // This part of code is for CASE 1 and CASE 2.2 \n    if (leftsmaller) \n    { \n        int carry = 1; \n        i = mid - 1; \n  \n        // If there are odd digits, then increment \n        // the middle digit and store the carry \n        if (n % 2 == 1) \n        { \n            A[mid] = (A[mid] - \'0\') + carry; \n            carry = A[mid] / 10; \n            A[mid] = A[mid] % 10 + \'0\';\n            j = mid + 1; \n        } \n        else\n            j = mid;\n  \n        //printf(\"2: %s\\n\", A);\n        // Add 1 to the rightmost digit of the left side, propagate the carry  \n        // towards MSB digit and simultaneously copying mirror of the left side  \n        // to the right side. \n        while (i >= 0) \n        { \n            A[i] = A[j] - \'0\' + carry; \n            carry = A[i] / 10; \n            A[i] = A[i] % 10 + \'0\'; \n            A[j++] = A[i--]; // copy mirror to right \n            //printf(\"3: %s\\n\", A);\n        } \n    } \n} \n  \nchar* solve(char* A) {\n    int i;\n    int n = strlen(A);\n    int all_are_9 = 1;\n    char *ret;\n    \n    for( i = 0; i < n; ++i ) \n        if( A[i] != \'9\' ) {\n            all_are_9 = 0;\n            break;\n        }\n\n    // Input type 1: All the digits are 9, simply o/p 1 \n    // followed by n-1 0\'s followed by 1. \n    if(all_are_9) \n    { \n        ret = calloc(sizeof(char), n + 2);\n        ret[0] = \'1\';\n        for(i = 1; i < n; i++) ret[i] = \'0\';\n        ret[n] = \'1\';\n        ret[n + 1] = 0;\n        return ret;\n    } \n  \n    // Input type 2 and 3 \n    generateNextPalindromeUtil(A, n); \n    \n    return A;\n} \n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=3COJ95juomM&pp=ygUlaW50ZXJ2aWV3Yml0IG5leHQgc21hbGxlc3QgcGFsaW5kcm9tZQ%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
