import '/flutter_flow/flutter_flow_util.dart';
import 'nextsmallestpalindrome_widget.dart' show NextsmallestpalindromeWidget;
import 'package:flutter/material.dart';

class NextsmallestpalindromeModel
    extends FlutterFlowModel<NextsmallestpalindromeWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
