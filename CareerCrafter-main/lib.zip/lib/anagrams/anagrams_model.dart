import '/flutter_flow/flutter_flow_util.dart';
import 'anagrams_widget.dart' show AnagramsWidget;
import 'package:flutter/material.dart';

class AnagramsModel extends FlutterFlowModel<AnagramsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
