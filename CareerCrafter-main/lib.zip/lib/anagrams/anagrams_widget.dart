import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'anagrams_model.dart';
export 'anagrams_model.dart';

class AnagramsWidget extends StatefulWidget {
  const AnagramsWidget({super.key});

  @override
  State<AnagramsWidget> createState() => _AnagramsWidgetState();
}

class _AnagramsWidgetState extends State<AnagramsWidget> {
  late AnagramsModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => AnagramsModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Anagrams',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2400.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven an array A of N strings, return all groups of strings that are anagrams.\n\nRepresent a group by a list of integers representing the index(1-based) in the original list. Look at the sample case for clarification.\n\nNOTE: Anagram is a word, phrase, or name formed by rearranging the letters, such as \'spar\', formed from \'rasp\'.\n\n\n\nProblem Constraints\n1 <= N <= 104\n\n1 <= |A[i]| <= 104\n\nEach string consists only of lowercase characters.\n\nThe sum of the length of all the strings doesn\'t exceed 107\n\n\n\nInput Format\nThe first and only argument is an integer array A.\n\n\n\nOutput Format\nReturn a two-dimensional array where each row describes a group.\n\nNote:\n\nOrdering of the result :\n You should not change the relative ordering of the strings within the group suppose within a group containing A[i] and A[j], A[i] comes before A[j] if i < j.\n\n\n\nExample Input\nInput 1:\n\n A = [cat, dog, god, tca]\nInput 2:\n\n A = [rat, tar, art]\n\n\nExample Output\nOutput 1:\n\n [ [1, 4],\n   [2, 3] ]\nOutput 2:\n\n [ [1, 2, 3] ]\n\n\nExample Explanation\nExplanation 1:\n\n \"cat\" and \"tca\" are anagrams which correspond to index 1 and 4 and \"dog\" and \"god\" are another set of anagrams which correspond to index 2 and 3.\n The indices are 1 based ( the first element has index 1 instead of index 0).\nExplanation 2:\n\n All three strings are anagrams.\n\n\nAnswer :-\n/**\n * @input A : Read only ( DON\'T MODIFY ) array of strings termination by \'\\0\'\n * @input n1 : number of strings in array A\n * \n * @Output 2D int array. You need to malloc memory. Fill in len1 as row, len2 as columns \n */\nint ** anagrams(const char** A, int n1, int *len1, int *len2) {\n    \n    int*ram=(int*)malloc(sizeof(int)*26);\n    int i,j,k;for(i=0;i<26;i++)ram[i]=0;\n    char**B=(char**)malloc(sizeof(char*)*n1);\n    \n    for(i=0;i<n1;i++){\n        B[i]=(char*)malloc(sizeof(char)*(strlen(A[i])+1));\n        for(j=0;A[i][j];j++){\n            B[i][j]=A[i][j];\n            ram[A[i][j]-\'a\']++;\n        }\n        B[i][j]=\'\\0\';\n        k=0;\n        for(j=0;j<26;j++){\n            while(ram[j]>0)\n            {\n                B[i][k++]=\'a\'+j;\n                ram[j]--;\n            }\n        }\n    }\n    int*v=(int*)malloc(sizeof(int)*n1);\n    for(i=0;i<n1;i++)v[i]=0;\n    for(i=0;i<n1;i++){\n        if(v[i]==1)continue;\n        v[i]=1;\n        printf(\"[%d \",i+1);\n        for(j=i+1;j<n1;j++){\n            if(strcmp(B[i],B[j])==0){\n                v[j]=1;printf(\"%d \",j+1);\n            }\n        }\n        printf(\"] \");\n    }\n    for(i=0;i<n1;i++)\n    free(B[i]);free(B);free(v);\n    *len1=*len2=0;return NULL;\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=RR2RlM5uRro&pp=ygUVaW50ZXJ2aWV3Yml0IGFuYWdyYW1z',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
