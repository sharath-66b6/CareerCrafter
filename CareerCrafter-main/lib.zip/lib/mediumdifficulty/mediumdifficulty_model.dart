import '/flutter_flow/flutter_flow_util.dart';
import 'mediumdifficulty_widget.dart' show MediumdifficultyWidget;
import 'package:flutter/material.dart';

class MediumdifficultyModel extends FlutterFlowModel<MediumdifficultyWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
