import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'maximalstring_model.dart';
export 'maximalstring_model.dart';

class MaximalstringWidget extends StatefulWidget {
  const MaximalstringWidget({super.key});

  @override
  State<MaximalstringWidget> createState() => _MaximalstringWidgetState();
}

class _MaximalstringWidgetState extends State<MaximalstringWidget> {
  late MaximalstringModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MaximalstringModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Maximal String',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2100.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      '\nProblem Description\n \n \n\nGiven a string A and integer B, what is maximal lexicographical string that can be made from A if you do atmost B swaps.\n\n\n\nProblem Constraints\n1 <= |A| <= 9\n\nA contains only digits from 0 to 9.\n\n1 <= B <= 5\n\n\n\nInput Format\nFirst argument is string A.\n\nSecond argument is integer B.\n\n\n\nOutput Format\nReturn a string, the naswer to the problem.\n\n\n\nExample Input\nInput 1:\n\nA = \"254\"\nB = 1\nInput 2:\n\nA = \"254\"\nB = 2\n\n\nExample Output\nOutput 1:\n\n 524\nOutput 2:\n\n 542\n\n\nExample Explanation\nExplanation 1:\n\n Swap 2 and 5.\nExplanation 2:\n\nSwap 2 and 5 then swap 4 and 2.\n\n\n\n\n\n\nAnswer :- \n/**\n * @input A : String termination by \'\\0\'\n * @input B : Integer\n * \n * @Output string. Make sure the string ends with null character\n */\n \n void swap( char *x, char *y){\n     char temp = *y;\n     *y = *x;\n     *x =temp;\n }\n \n void sol(char *A, int B, char *str){\n     if(B==0)\n        return;\n    \n    int i,j, len = strlen(A);\n    for(i=0; i<len-1; i++){\n        for(j=i+1; j<len; j++){\n            if(A[i]<A[j]){\n                swap(&A[i], &A[j]);\n                \n                if(strcmp(A, str)>0)\n                    strcpy(str, A);\n                \n                // puts(str);\n                sol(A, B-1, str);\n                swap(&A[i], &A[j]);\n            }\n                \n        }\n    }\n    // printf\n    // str[0]=\'0\';\n }\nchar* solve(char* A, int B) {\n    char *str = malloc(sizeof(char)* (strlen(A)+1));\n    // str[0] = 0;\n    strcpy(str, A);\n    \n    sol(A, B, str);\n    \n    return str;\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=7rRibptKjus&pp=ygUbaW50ZXJ2aWV3Yml0IG1heGltYWwgc3RyaW5n',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
