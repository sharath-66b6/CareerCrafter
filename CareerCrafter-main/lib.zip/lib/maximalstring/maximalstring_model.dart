import '/flutter_flow/flutter_flow_util.dart';
import 'maximalstring_widget.dart' show MaximalstringWidget;
import 'package:flutter/material.dart';

class MaximalstringModel extends FlutterFlowModel<MaximalstringWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
