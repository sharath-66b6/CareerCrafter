import '/flutter_flow/flutter_flow_util.dart';
import 'minimumappendsforpalindrome_widget.dart'
    show MinimumappendsforpalindromeWidget;
import 'package:flutter/material.dart';

class MinimumappendsforpalindromeModel
    extends FlutterFlowModel<MinimumappendsforpalindromeWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
