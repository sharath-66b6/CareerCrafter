import '/flutter_flow/flutter_flow_util.dart';
import 'findnthfibonnaci_widget.dart' show FindnthfibonnaciWidget;
import 'package:flutter/material.dart';

class FindnthfibonnaciModel extends FlutterFlowModel<FindnthfibonnaciWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
