import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'findnthfibonnaci_model.dart';
export 'findnthfibonnaci_model.dart';

class FindnthfibonnaciWidget extends StatefulWidget {
  const FindnthfibonnaciWidget({super.key});

  @override
  State<FindnthfibonnaciWidget> createState() => _FindnthfibonnaciWidgetState();
}

class _FindnthfibonnaciWidgetState extends State<FindnthfibonnaciWidget> {
  late FindnthfibonnaciModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => FindnthfibonnaciModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Find Nth Fibonacci',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2000.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nGiven an integer A you need to find the Ath fibonacci number modulo 109 + 7.\n\nThe first fibonacci number F1 = 1\n\nThe first fibonacci number F2 = 1\n\nThe nth fibonacci number Fn = Fn-1 + Fn-2 (n > 2)\n\n\n\nProblem Constraints\n1 <= A <= 109.\n\n\n\nInput Format\nFirst argument is an integer A.\n\n\n\nOutput Format\nReturn a single integer denoting Ath fibonacci number modulo 109 + 7.\n\n\n\nExample Input\nInput 1:\n\n A = 4\nInput 2:\n\n A = 3\n\n\nExample Output\nOutput 1:\n\n 3\nOutput 2:\n\n 2\n\n\nExample Explanation\nExplanation 1:\n\n F3 = F2 + F1 = 1 + 1 = 2\n F4 = F3 + F2 = 2 + 1 = 3\nExplanation 2:\n\n F3 = F2 + F1 = 1 + 1 = 2\n\n\n\nAnswers:-\n#include<math.h>\nvoid multiply(long F[2][2],long M[2][2]){\n    long x =  F[0][0]% 1000000007*M[0][0]% 1000000007 + F[0][1]% 1000000007*M[1][0]% 1000000007; \n    long y =  F[0][0]% 1000000007*M[0][1]% 1000000007 + F[0][1]% 1000000007*M[1][1]% 1000000007; \n    long z =  F[1][0]% 1000000007*M[0][0]% 1000000007 + F[1][1]% 1000000007*M[1][0]% 1000000007; \n    long w =  F[1][0]% 1000000007*M[0][1]% 1000000007 + F[1][1]% 1000000007*M[1][1]% 1000000007; \n      \n    F[0][0] = x; \n    F[0][1] = y; \n    F[1][0] = z; \n    F[1][1] = w; \n \n}\n\nvoid power(long F[2][2], int n){\n    if(n==0||n==1)\n        return;\n    long M[2][2]={1,1,1,0};\n    power(F,n/2);\n    multiply(F,F);\n    if(n%2!=0){\n        multiply(F,M);\n    }\n}\n\nint solve(int A) {\n    long F[2][2]={1,1,1,0};\n    if(A==1)\n        return 1;\n    power(F,A-1);\n    F[0][0]=F[0][0]%1000000007;\n    return (int)F[0][0];\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=e-sbCk5FOF8&pp=ygUjaW50ZXJ2aWV3Yml0IGZpbmQgdGhlIG50aCBmaWJvbmFjY2k%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
