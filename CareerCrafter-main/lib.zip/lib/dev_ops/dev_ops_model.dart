import '/flutter_flow/flutter_flow_util.dart';
import 'dev_ops_widget.dart' show DevOpsWidget;
import 'package:flutter/material.dart';

class DevOpsModel extends FlutterFlowModel<DevOpsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
