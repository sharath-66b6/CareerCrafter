import '/flutter_flow/flutter_flow_util.dart';
import 'matrixmedian_widget.dart' show MatrixmedianWidget;
import 'package:flutter/material.dart';

class MatrixmedianModel extends FlutterFlowModel<MatrixmedianWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
