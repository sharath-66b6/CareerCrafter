import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'matrixmedian_model.dart';
export 'matrixmedian_model.dart';

class MatrixmedianWidget extends StatefulWidget {
  const MatrixmedianWidget({super.key});

  @override
  State<MatrixmedianWidget> createState() => _MatrixmedianWidgetState();
}

class _MatrixmedianWidgetState extends State<MatrixmedianWidget> {
  late MatrixmedianModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MatrixmedianModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Matrix Median',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2000.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven a matrix of integers A of size N x M in which each row is sorted.\n\nFind and return the overall median of matrix A.\n\nNOTE: No extra memory is allowed.\n\nNOTE: Rows are numbered from top to bottom and columns are numbered from left to right.\n\n\n\nProblem Constraints\n1 <= N, M <= 10^5\n\n1 <= N*M <= 10^6\n\n1 <= A[i] <= 10^9\n\nN*M is odd\n\n\n\nInput Format\nThe first and only argument given is the integer matrix A.\n\n\n\nOutput Format\nReturn the overall median of matrix A.\n\n\n\nExample Input\nInput 1: \n\nA = [   [1, 3, 5],\n        [2, 6, 9],\n        [3, 6, 9]   ] \nInput 2: \n\nA = [   [5, 17, 100]    ]\n\n\nExample Output\nOutput 1: \n\n 5 \nOutput 2: \n\n 17\n\n\nExample Explanation\nExplanation 1: \n\nA = [1, 2, 3, 3, 5, 6, 6, 9, 9]\nMedian is 5. So, we return 5. \nExplanation 2:\n\nMedian is 17.\n\n\nAnswer :- \nimport bisect\n\nclass Solution:\n    # @param A : list of list of integers\n    # @return an integer\n    def findMedian(self, A):\n        \n        temp = []\n        \n        for i in range(0, len(A)):\n            for j in range(0, len(A[0])):\n                temp.append(A[i][j])\n        \n        temp.sort()\n        \n        return temp[len(temp)/2]\n        \n        # l = 0\n        # r = 1000*1000*1000\n        # req = len(A) * len(A[0])\n        # assert(req % 2);\n        # while(r - l > 1):\n        #     mid = l + (r - l) / 2\n        #     cnt = 0\n        #     for i in A: \n        #         #using upper bound in a sorted array to count number of elements smaller than mid\n        #         low = 0\n        #         p = bisect.bisect_right(i, mid)\n        #         cnt += p\n        #     if cnt >= (req/2 +1):\n        #         r = mid\n        #     else:\n        #         l = mid\n        # return r\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=Q9wXgdxJq48&pp=ygUaaW50ZXJ2aWV3Yml0IG1hdHJpeCBtZWRpYW4%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
