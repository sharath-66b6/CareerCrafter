import '/flutter_flow/flutter_flow_util.dart';
import 'andriod_widget.dart' show AndriodWidget;
import 'package:flutter/material.dart';

class AndriodModel extends FlutterFlowModel<AndriodWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
