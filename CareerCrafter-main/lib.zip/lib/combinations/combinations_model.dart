import '/flutter_flow/flutter_flow_util.dart';
import 'combinations_widget.dart' show CombinationsWidget;
import 'package:flutter/material.dart';

class CombinationsModel extends FlutterFlowModel<CombinationsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
