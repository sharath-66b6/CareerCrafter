import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'combinations_model.dart';
export 'combinations_model.dart';

class CombinationsWidget extends StatefulWidget {
  const CombinationsWidget({super.key});

  @override
  State<CombinationsWidget> createState() => _CombinationsWidgetState();
}

class _CombinationsWidgetState extends State<CombinationsWidget> {
  late CombinationsModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CombinationsModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Combinations',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1900.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\nGiven two integers n and k, return all possible combinations of k numbers out of 1 2 3 ... n.\n\nMake sure the combinations are sorted.\n\nTo elaborate,\n\nWithin every entry, elements should be sorted. [1, 4] is a valid entry while [4, 1] is not.\nEntries should be sorted within themselves.\nExample :\n\nIf n = 4 and k = 2, a solution is:\n\n[\n  [1,2],\n  [1,3],\n  [1,4],\n  [2,3],\n  [2,4],\n  [3,4],\n]\nWarning : DO NOT USE LIBRARY FUNCTION FOR GENERATING COMBINATIONS.\n\nExample : itertools.combinations in python.\n\nIf you do, we will disqualify your submission retroactively and give you penalty points.\n\n\nAnswer :-\n/**\n * @input n : Integer\n * @input k : Integer\n * \n * @Output 2D int array. You need to malloc memory. Fill in len1 as row, len2 as columns \n */\n int NextNum(int * cur, int start,int pos,int count,int total, int ** out, int high);\nint ** combine(int n, int k, int *len1, int *len2) {\n    int ** out = (int **)(malloc(sizeof(int*)*1000));\n    int * cur = (int *)(malloc (sizeof(int)* k));\n    if(k==0){\n        *len1=0;\n        *len2=0;\n        return out;\n    }\n    int count = NextNum(cur,1,0,0,k,out,n);\n    //printf(\"returned in main with count :%d and k :%d\\n\",count,k);\n    *len1=count;\n    *len2=k;\n    //*len1=0;\n    //*len2=0;\n    return out;\n}\n\nint NextNum(int * cur, int start,int pos,int count,int total, int ** out, int high){\n    int i;\n    //printf(\"nextNum, start:%d, pos:%d, count:%d,total:%d\\n\",start,pos,count,total);\n    if(start > high)\n        return count;\n    if(high-start < total-1-pos)\n        return count;\n\n    if(pos==total || (pos==total-1 && start==high)){\n        out[count]=(int *)(malloc(sizeof(int)* total));\n       /* \n       if(out[count]==NULL)\n            printf(\"allocation failed\\n\");\n        else\n            printf(\"out[%d] allocated\\n\",count);\n        */\n        if(pos==total-1)\n            cur[pos]=high;\n        for(i=0;i<total;i++)\n           out[count][i]=cur[i];\n        //printf(\"count is now :%d\\n\",count +1);\n        count ++;\n        return count;\n    } \n    if(start)\n    cur[pos]=start;\n    count=NextNum(cur,start+1,pos+1,count,total,out,high);\n    count=NextNum(cur,start+1,pos,count,total,out,high);\n    return count;\n    \n}',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=D0wKuwRrBpg&pp=ygUZaW50ZXJ2aWV3Yml0IGNvbWJpbmF0aW9ucw%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
