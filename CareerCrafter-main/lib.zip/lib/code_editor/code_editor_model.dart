import '/flutter_flow/flutter_flow_util.dart';
import 'code_editor_widget.dart' show CodeEditorWidget;
import 'package:flutter/material.dart';

class CodeEditorModel extends FlutterFlowModel<CodeEditorWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
