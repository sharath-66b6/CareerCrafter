import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'clonegraph_model.dart';
export 'clonegraph_model.dart';

class ClonegraphWidget extends StatefulWidget {
  const ClonegraphWidget({super.key});

  @override
  State<ClonegraphWidget> createState() => _ClonegraphWidgetState();
}

class _ClonegraphWidgetState extends State<ClonegraphWidget> {
  late ClonegraphModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ClonegraphModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Clone Graph',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2200.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nClone an undirected graph. Each node in the graph contains a label and a list of its neighbors.\n\nNote: The test cases are generated in the following format (use the following format to use See Expected Output option):\n\nFirst integer N is the number of nodes.\n\nThen, N intgers follow denoting the label (or hash) of the N nodes.\n\nThen, N2 integers following denoting the adjacency matrix of a graph, where Adj[i][j] = 1 denotes presence of an undirected edge between the ith and jth node, O otherwise.\n\n\n\nProblem Constraints\n1 <= Number of nodes <= 105\n\n\n\nInput Format\nFirst and only argument is a node A denoting the root of the undirected graph.\n\n\n\nOutput Format\nReturn the node denoting the root of the new clone graph.\n\n\n\nExample Input\nInput 1:\n\n      1\n    / | \\\n   3  2  4\n        / \\\n       5   6\nInput 2:\n\n      1\n     / \\\n    3   4\n   /   /|\\\n  2   5 7 6\n\n\nExample Output\nOutput 1:\n\n Output will the same graph but with new pointers:\n      1\n    / | \\\n   3  2  4\n        / \\\n       5   6\nOutput 2:\n\n      1\n     / \\\n    3   4\n   /   /|\\\n  2   5 7 6\n\n\nExample Explanation\nExplanation 1:\n\n We need to return the same graph, but the pointers to the node should be different.\n\n\n\nAnswer :-\n# Definition for a undirected graph node\n# class UndirectedGraphNode:\n#     def __init__(self, x):\n#         self.label = x\n#         self.neighbors = []\n\nclass Solution:\n    # @param node, a undirected graph node\n    # @return a undirected graph node\n    def cloneGraph(self, node):\n        from collections import deque\n        q = deque()\n        h = {}\n        q.append(node)\n        cnode = UndirectedGraphNode(node.label)\n        h[node] = cnode\n        while(len(q) > 0):\n            t = q[0]\n            q.popleft()\n            for i in t.neighbors:\n                if i not in h:\n                    copy = UndirectedGraphNode(i.label)\n                    h[i] = copy\n                    q.append(i)\n                h[t].neighbors.append(h[i])\n                    \n        return cnode\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=f2EfGComRKM&pp=ygUYaW50ZXJ2aWV3Yml0IGNsb25lIGdyYXBo',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
