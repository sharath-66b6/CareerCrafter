import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'cousinsinbinarytree_model.dart';
export 'cousinsinbinarytree_model.dart';

class CousinsinbinarytreeWidget extends StatefulWidget {
  const CousinsinbinarytreeWidget({super.key});

  @override
  State<CousinsinbinarytreeWidget> createState() =>
      _CousinsinbinarytreeWidgetState();
}

class _CousinsinbinarytreeWidgetState extends State<CousinsinbinarytreeWidget> {
  late CousinsinbinarytreeModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CousinsinbinarytreeModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Cousins in Binary Tree',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 3100.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nGiven a Binary Tree A consisting of N nodes.\n\nYou need to find all the cousins of node B.\n\nNOTE:\n\nSiblings should not be considered as cousins.\nTry to do it in single traversal.\nYou can assume that Node B is there in the tree A.\nOrder doesn\'t matter in the output.\n\n\nProblem Constraints\n 1 <= N <= 105 \n\n 1 <= B <= N\n\n\n\nInput Format\nFirst Argument represents the root of binary tree A.\n\nSecond Argument is an integer B denoting the node number.\n\n\n\nOutput Format\nReturn an integer array denoting the cousins of node B.\n\nNOTE: Order doesn\'t matter.\n\n\n\nExample Input\nInput 1:\n\n A =\n\n           1\n         /   \\\n        2     3\n       / \\   / \\\n      4   5 6   7 \n\n\nB = 5\n\nInput 2:\n\n A = \n            1\n          /   \\\n         2     3\n        / \\ .   \\\n       4   5 .   6\n\n\nB = 1\n\n\n\n\nExample Output\nOutput 1:\n\n [6, 7]\nOutput 2:\n\n []\n\n\nExample Explanation\nExplanation 1:\n\n Cousins of Node 5 are Node 6 and 7 so we will return [6, 7]\n Remember Node 4 is sibling of Node 5 and do not need to return this.\nExplanation 2:\n\n Since Node 1 is the root so it doesn\'t have any cousin so we will return an empty array.\n\n\nAnswer :-\n/**\n * Definition for binary tree\n * struct TreeNode {\n *     int val;\n *     struct TreeNode *left;\n *     struct TreeNode *right;\n * };\n * \n * typedef struct TreeNode treenode;\n * \n * treenode* treenode_new(int val) {\n *     treenode* node = (treenode *) malloc(sizeof(treenode));\n *     node->val = val;\n *     node->left = NULL;\n *     node->right = NULL;\n *     return node;\n * }\n */\n/**\n * @input A : Root pointer of the tree \n * @input B : Integer\n * \n * @Output Integer array. You need to malloc memory, and fill the length in len1\n */\nint knowlevel(struct TreeNode* root, int x, int level){\n    if(root==NULL){\n        return 0;\n    }\n    else if(root->val==x){\n        return level;\n    }\n    else if(knowlevel(root->left,x,level+1)){\n        return knowlevel(root->left,x,level+1);\n    }\n    else{\n        return knowlevel(root->right,x,level+1);\n    }\n}\n\nint knowparent(struct TreeNode* root, int x,int parent){\n    if(root==NULL){\n        return 0;\n    }\n    else if(root->val==x){\n        return parent;\n    }\n    return knowparent(root->left,x,root->val)?knowparent(root->left,x,root->val):knowparent(root->right,x,root->val);\n    \n}\n\nvoid getcousins(treenode* A, int level, int parent, int curl, int curp, int* arr, int *len1){\n    if(A==NULL){\n        return;\n    }\n    else if(curl==level && curp!=parent){\n        arr[*len1]=A->val;\n        *len1+=1;\n        return;\n    }\n    getcousins(A->left,level,parent,curl+1,A->val,arr,len1);\n    getcousins(A->right,level,parent,curl+1,A->val,arr,len1);\n}\n\n\nint* solve(treenode* A, int B, int *len1) {\n    int level=knowlevel(A,B,0);\n    int parent=knowparent(A,B,A->val);\n    int* arr=(int*)malloc(sizeof(int)*100000);\n    *len1=0;\n    getcousins(A,level,parent,0,A->val,arr,len1);\n    return arr;\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=SWo2WtWOBrI&pp=ygUjaW50ZXJ2aWV3Yml0IGNvdXNpbnMgaW4gYmluYXJ5IHRyZWU%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
