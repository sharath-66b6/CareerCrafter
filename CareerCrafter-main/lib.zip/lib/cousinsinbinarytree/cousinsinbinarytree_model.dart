import '/flutter_flow/flutter_flow_util.dart';
import 'cousinsinbinarytree_widget.dart' show CousinsinbinarytreeWidget;
import 'package:flutter/material.dart';

class CousinsinbinarytreeModel
    extends FlutterFlowModel<CousinsinbinarytreeWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
