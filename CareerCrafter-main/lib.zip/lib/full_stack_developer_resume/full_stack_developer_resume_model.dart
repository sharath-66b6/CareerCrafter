import '/flutter_flow/flutter_flow_util.dart';
import 'full_stack_developer_resume_widget.dart'
    show FullStackDeveloperResumeWidget;
import 'package:flutter/material.dart';

class FullStackDeveloperResumeModel
    extends FlutterFlowModel<FullStackDeveloperResumeWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
