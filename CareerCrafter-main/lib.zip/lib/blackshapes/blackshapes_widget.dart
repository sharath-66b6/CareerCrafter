import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'blackshapes_model.dart';
export 'blackshapes_model.dart';

class BlackshapesWidget extends StatefulWidget {
  const BlackshapesWidget({super.key});

  @override
  State<BlackshapesWidget> createState() => _BlackshapesWidgetState();
}

class _BlackshapesWidgetState extends State<BlackshapesWidget> {
  late BlackshapesModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => BlackshapesModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).primary,
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30.0,
            borderWidth: 1.0,
            buttonSize: 60.0,
            icon: const Icon(
              Icons.arrow_back_rounded,
              color: Colors.white,
              size: 30.0,
            ),
            onPressed: () async {
              context.pop();
            },
          ),
          title: Text(
            'Black Shapes',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: 'Outfit',
                  color: Colors.white,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                ),
          ),
          actions: const [],
          centerTitle: true,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: ListView(
            padding: const EdgeInsets.symmetric(vertical: 12.0),
            scrollDirection: Axis.vertical,
            children: [
              Container(
                width: 100.0,
                height: 1700.0,
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryBackground,
                ),
                child: Align(
                  alignment: const AlignmentDirectional(0.0, -1.0),
                  child: Text(
                    'Problem Description\n \n \n\nGiven N x M character matrix A of O\'s and X\'s, where O = white, X = black.\n\n\nReturn the number of black shapes. A black shape consists of one or more adjacent X\'s (diagonals not included)\n\n\n\n\nInput Format:\n\n    The First and only argument is a N x M character matrix.\nOutput Format:\n\n    Return a single integer denoting number of black shapes.\nConstraints:\n\n    1 <= N,M <= 1000\n    A[i][j] = \'X\' or \'O\'\nExample:\n\nInput 1:\n    A = [ OOOXOOO\n          OOXXOXO\n          OXOOOXO  ]\nOutput 1:\n    3\nExplanation:\n    3 shapes are  :\n    (i)    X\n         X X\n    (ii)\n          X\n    (iii)\n          X\n          X\nNote: we are looking for connected shapes here.\n\nXXX\nXXX\nXXX\nis just one single connected black shape.\n\n\n\n\nAnswer :-\n/**\n * @input A : array of strings termination by \'\\0\'\n * @input n1 : number of strings in array A\n * \n * @Output Integer\n */\nvoid eat(char** A, int n, int m, int i, int j) {\n    if(i>=n||i<0||j>=m||j<0) return;\n    if(A[i][j]==\'O\') return ;\n    A[i][j]=\'O\';\n    eat(A,n,m,i+1,j);\n    eat(A,n,m,i-1,j);\n    eat(A,n,m,i,j+1);\n    eat(A,n,m,i,j-1);\n    \n}\nint black(char** A, int n1) {\n    if(n1==0)return 0;\n    int m=0;for(m=0;A[0][m]!=\'\\0\';m++);\n    int cnt=0;\n    int i,j;\n    for(i=0;i<n1;i++) {\n        for(j=0;j<m;j++) {\n            if(A[i][j]==\'X\') {\n                eat(A,n1,m,i,j);\n                cnt++;\n            }\n        }\n    }\n    return cnt;\n}\n',
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Readex Pro',
                          letterSpacing: 0.0,
                        ),
                  ),
                ),
              ),
            ].divide(const SizedBox(height: 12.0)),
          ),
        ),
      ),
    );
  }
}
