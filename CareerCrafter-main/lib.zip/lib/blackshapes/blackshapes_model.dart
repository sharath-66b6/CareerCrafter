import '/flutter_flow/flutter_flow_util.dart';
import 'blackshapes_widget.dart' show BlackshapesWidget;
import 'package:flutter/material.dart';

class BlackshapesModel extends FlutterFlowModel<BlackshapesWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
