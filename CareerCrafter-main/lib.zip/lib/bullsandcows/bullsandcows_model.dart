import '/flutter_flow/flutter_flow_util.dart';
import 'bullsandcows_widget.dart' show BullsandcowsWidget;
import 'package:flutter/material.dart';

class BullsandcowsModel extends FlutterFlowModel<BullsandcowsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
