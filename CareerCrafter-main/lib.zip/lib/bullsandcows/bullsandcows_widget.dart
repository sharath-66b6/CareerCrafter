import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'bullsandcows_model.dart';
export 'bullsandcows_model.dart';

class BullsandcowsWidget extends StatefulWidget {
  const BullsandcowsWidget({super.key});

  @override
  State<BullsandcowsWidget> createState() => _BullsandcowsWidgetState();
}

class _BullsandcowsWidgetState extends State<BullsandcowsWidget> {
  late BullsandcowsModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => BullsandcowsModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Bulls and Cows',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 3700.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      ' You are playing the Bulls and Cows game with your friend.\n\nYou write down a secret number and ask your friend to guess what the number is. When your friend makes a guess, you provide a hint with the following info:\n\nThe number of \"bulls\", which are digits in the guess that are in the correct position.\nThe number of \"cows\", which are digits in the guess that are in your secret number but are located in the wrong position. \nSpecifically, the non-bull digits in the guess that could be rearranged such that they become bulls. \nGiven the secret number secret and your friend\'s guess guess, return the hint for your friend\'s guess.\n\nThe hint should be formatted as \"xAyB\", where x is the number of bulls and y is the number of cows. Note that both secret and guess may contain duplicate digits.\n\n\n\nProblem Constraints\n1 <= secret.length, guess.length <= 100000\nsecret.length == guess.length\nsecret and guess consist of digits only.\n\n\nInput Format\nFirst argument is string denoting secret string \n\n\nSecond argument is string denoting guess string \n\n\n\nOutput Format\nReturn the hint for you friend\'s guess.\n\n\nExample Input\nInput 1:\nsecret = \"1807\", guess = \"7810\"\nInput 2:\n\nsecret = \"1123\", guess = \"0111\"\n\n\nExample Output\nOuput 1:\n\"1A3B\"\nOuput 2:\n\n\"1A1B\"\n\n\nExample Explanation\nExplanation 1:\nBulls are connected with a \'|\':\n\"1807\"\n  |\n\"7810\"\nExplanation 2:\n\nBulls are connected with a \'|\' \n\"1123\"        \"1123\"\n  |      or     |\n\"0111\"        \"0111\"\nNote that only one of the two unmatched 1s is counted as a cow since \nthe non-bull digits can only be rearranged to allow one 1 to be a bull.\n\n\nAnswer :-\n/* A utility function to reverse a string  */\nvoid reverse(char *str, int length)\n{\n    int start = 0;\n    int end = length -1;\n    while (start < end)\n    {\n        char tmp = str[start];\n        str[start] = str[end];\n        str[end] = tmp;\n\n        start++;\n        end--;\n    }\n}\n \n// Implementation of itoa()\nchar* itoa(int num, char* str, int base)\n{\n    int i = 0;\n    int isNegative = 0;\n \n    /* Handle 0 explicitly, otherwise empty string is printed for 0 */\n    if (num == 0)\n    {\n        str[i++] = \'0\';\n        str[i] = \'\\0\';\n        return str;\n    }\n \n    // In standard itoa(), negative numbers are handled only with\n    // base 10. Otherwise numbers are considered unsigned.\n    if (num < 0 && base == 10)\n    {\n        isNegative = 1;\n        num = -num;\n    }\n \n    // Process individual digits\n    while (num != 0)\n    {\n        int rem = num % base;\n        str[i++] = (rem > 9)? (rem-10) + \'a\' : rem + \'0\';\n        num = num/base;\n    }\n \n    // If number is negative, append \'-\'\n    if (isNegative)\n        str[i++] = \'-\';\n \n    str[i] = \'\\0\'; // Append string terminator\n \n    // Reverse the string\n    reverse(str, i);\n \n    return str;\n}\n\n/**\n * @input A : String termination by \'\\0\'\n * @input B : String termination by \'\\0\'\n * \n * @Output string. Make sure the string ends with null character\n */\nchar* solve(char* A, char* B) {\n    int bulls = 0, cows = 0;\n    int len = strlen(A), i = 0;\n    char b[100000] = {0}, c[100000] = {0};\n\n    int freq[10] = {0};\n\n    for(i = 0; i < len; i++)\n    {\n        freq[A[i] - \'0\']++;\n    }\n\n    i = 0;\n    while(i < len)\n    {\n        if(A[i] == B[i])\n        {\n            bulls++;\n            freq[A[i] - \'0\']--;\n        }\n\n        i++;\n    }\n\n    i = 0;\n    while(i < len)\n    {\n        if(A[i] != B[i])\n        {\n            if((strchr(A, B[i]) != NULL) && freq[B[i] - \'0\'])\n            {\n                cows++;\n                freq[B[i] - \'0\']--;\n            }\n        }\n\n        i++;\n    }\n\n    itoa(bulls, b, 10);\n    itoa(cows, c, 10);\n\n    char *ans = (char *) malloc(strlen(b) + strlen(c) + 3);\n    strcpy(ans, b);\n    strcat(ans, \"A\");\n    strcat(ans, c);\n    strcat(ans, \"B\");\n\n    ans[strlen(b) + strlen(c) + 2] = \'\\0\';\n\n    return ans;\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=aDcwaNaz7yg&pp=ygUZaW50ZXJ2aWV3Yml0IGJ1bGxzYW5kY293cw%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
