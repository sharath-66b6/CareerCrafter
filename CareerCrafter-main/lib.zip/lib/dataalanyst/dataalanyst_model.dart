import '/flutter_flow/flutter_flow_util.dart';
import 'dataalanyst_widget.dart' show DataalanystWidget;
import 'package:flutter/material.dart';

class DataalanystModel extends FlutterFlowModel<DataalanystWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
