import '/flutter_flow/flutter_flow_util.dart';
import 'addtwonumbersaslists_widget.dart' show AddtwonumbersaslistsWidget;
import 'package:flutter/material.dart';

class AddtwonumbersaslistsModel
    extends FlutterFlowModel<AddtwonumbersaslistsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
