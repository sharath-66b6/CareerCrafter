import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'addtwonumbersaslists_model.dart';
export 'addtwonumbersaslists_model.dart';

class AddtwonumbersaslistsWidget extends StatefulWidget {
  const AddtwonumbersaslistsWidget({super.key});

  @override
  State<AddtwonumbersaslistsWidget> createState() =>
      _AddtwonumbersaslistsWidgetState();
}

class _AddtwonumbersaslistsWidgetState
    extends State<AddtwonumbersaslistsWidget> {
  late AddtwonumbersaslistsModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => AddtwonumbersaslistsModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Add Two Numbers as Lists',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1200.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \nYou are given two linked lists representing two non-negative numbers. The digits are stored in reverse order and each of their nodes contain a single digit. Add the two numbers and return it as a linked list.\n\nInput: (2 -> 4 -> 3) + (5 -> 6 -> 4)\n\nOutput: 7 -> 0 -> 8\n\n    342 + 465 = 807\nMake sure there are no trailing zeros in the output list\n\nSo, 7 -> 0 -> 8 -> 0 is not a valid response even though the value is still 807.\n\n\n\n\nAnswer :-\n/**\n * @input A : Head pointer of linked list \n * @input B : Head pointer of linked list \n * \n * @Output head pointer of list.\n */\nlistnode* addTwoNumbers(listnode* A, listnode* B) {\n    listnode *prev = NULL, *node = NULL, *head = NULL;\n    int c = 0;\n    int C = 0;\n    while(A != NULL || B != NULL || c > 0) {\n        if(A != NULL) \n            C += A->val;\n        if(B != NULL)\n            C += B->val;\n        C += c;\n        c = (C/10)%10;\n        C = C%10;\n        //printf(\"\\n C val %d and c %d\",C,c);\n        node = listnode_new(C);\n        if(prev == NULL) {\n            head = node;\n            prev = node;\n        }\n        else {\n            prev->next = node;\n            prev = node;\n        }\n        if(A!=NULL)\n            A = A->next;\n        if(B!=NULL)\n            B = B->next;\n        C = 0;\n    }\n    return head;\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=fThpzrA0vGc&pp=ygUlaW50ZXJ2aWV3Yml0IGFkZCB0d28gbnVtYmVycyBhcyBsaXN0cw%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
