import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'captureregionsonboard_model.dart';
export 'captureregionsonboard_model.dart';

class CaptureregionsonboardWidget extends StatefulWidget {
  const CaptureregionsonboardWidget({super.key});

  @override
  State<CaptureregionsonboardWidget> createState() =>
      _CaptureregionsonboardWidgetState();
}

class _CaptureregionsonboardWidgetState
    extends State<CaptureregionsonboardWidget> {
  late CaptureregionsonboardModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CaptureregionsonboardModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Capture Regions on Board',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2200.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nGiven a 2D character matrix A of size N x M, containing \'X\' and \'O\', capture all regions surrounded by \'X\'.\n\nA region is captured by flipping all \'O\'s into \'X\'s in that surrounded region.\n\n\n\nProblem Constraints\n1 <= N, M <= 103\n\n\n\nInput Format\nFirst and only argument 2D character matrix A of size N X M.\n\n\n\nOutput Format\nMake changes to the the input only as matrix is passed by reference.\n\n\n\nExample Input\nInput 1:\n\n A = [  [X, X, X, X],\n        [X, O, O, X],\n        [X, X, O, X],\n        [X, O, X, X]\n     ]\n\n\nExample Output\nOutput 1:\n\n A = [  [X, X, X, X],\n        [X, X, X, X],\n        [X, X, X, X],\n        [X, O, X, X]\n     ]\n\n\nExample Explanation\nExplanation 1:\n\n \'O\' in (4,2) is not surrounded by X from below.\n\n\n\nAnswer :-\n/**\n * @input A : 2D char array \n * @input n11 : char array\'s ( A ) rows\n * @input n12 : char array\'s ( A ) columns\n * \n * @Output Void. Just modifies the args passed by reference \n */\nvoid mark( char** A,int i,int j,int n,int m){\n    if( i < 0 || j < 0 || i >= n || j >= m ){\n        return;\n    }\n    if( A[i][j] != \'p\'){\n        return;\n    }\n    A[i][j] = \'O\';\n    mark(A,i+1,j,n,m);\n    mark(A,i,j+1,n,m);\n    mark(A,i-1,j,n,m);\n    mark(A,i,j-1,n,m);\n}\nvoid solve(char** A, int n, int m) {\n    int i,j;\n    for( i = 0 ; i < n;i++){\n        for( j = 0; j < m ;j++){\n            if( A[i][j] == \'O\'){\n                A[i][j]  = \'p\';\n               // printf( \"%d %d %c\\n\",i,j,A[i][j]);\n            }\n        }\n    }\n    for( i = 0; i < n;i++){\n        if( A[i][0] == \'p\'){\n            mark ( A,i,0,n,m);\n        }\n    }\n    for( i = 0; i < n;i++){\n        if( A[i][m-1] == \'p\'){\n            mark ( A,i,m-1,n,m);\n        }\n    }\n    for( i = 0; i < m;i++){\n        if( A[0][i] == \'p\'){\n            mark ( A,0,i,n,m);\n        }\n    }\n    for( i = 0; i < m;i++){\n        if( A[n-1][i] == \'p\'){\n             mark ( A,n-1,i,n,m);\n        }\n    }\n    for(i=1;i< n-1;i++){\n        for( j = 1;j<m-1;j++){\n            if( A[i][j] == \'p\'){\n                A[i][j] = \'X\';\n                // printf( \"%d %d %c\\n\",i,j,A[i][j]);\n            }\n        }\n    }\n    \n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=qr8q5Jstqx0&pp=ygUlaW50ZXJ2aWV3Yml0IGNhcHR1cmUgcmVnaW9ucyBvbiBib2FyZA%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
