import '/flutter_flow/flutter_flow_util.dart';
import 'captureregionsonboard_widget.dart' show CaptureregionsonboardWidget;
import 'package:flutter/material.dart';

class CaptureregionsonboardModel
    extends FlutterFlowModel<CaptureregionsonboardWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
