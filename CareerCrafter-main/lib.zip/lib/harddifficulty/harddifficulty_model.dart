import '/flutter_flow/flutter_flow_util.dart';
import 'harddifficulty_widget.dart' show HarddifficultyWidget;
import 'package:flutter/material.dart';

class HarddifficultyModel extends FlutterFlowModel<HarddifficultyWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
