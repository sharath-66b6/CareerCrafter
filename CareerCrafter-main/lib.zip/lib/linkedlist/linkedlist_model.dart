import '/flutter_flow/flutter_flow_util.dart';
import 'linkedlist_widget.dart' show LinkedlistWidget;
import 'package:flutter/material.dart';

class LinkedlistModel extends FlutterFlowModel<LinkedlistWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
