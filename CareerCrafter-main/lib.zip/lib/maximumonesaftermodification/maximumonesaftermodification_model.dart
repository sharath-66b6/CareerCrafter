import '/flutter_flow/flutter_flow_util.dart';
import 'maximumonesaftermodification_widget.dart'
    show MaximumonesaftermodificationWidget;
import 'package:flutter/material.dart';

class MaximumonesaftermodificationModel
    extends FlutterFlowModel<MaximumonesaftermodificationWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
