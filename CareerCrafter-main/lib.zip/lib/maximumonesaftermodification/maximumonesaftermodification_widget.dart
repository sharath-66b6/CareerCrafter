import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'maximumonesaftermodification_model.dart';
export 'maximumonesaftermodification_model.dart';

class MaximumonesaftermodificationWidget extends StatefulWidget {
  const MaximumonesaftermodificationWidget({super.key});

  @override
  State<MaximumonesaftermodificationWidget> createState() =>
      _MaximumonesaftermodificationWidgetState();
}

class _MaximumonesaftermodificationWidgetState
    extends State<MaximumonesaftermodificationWidget> {
  late MaximumonesaftermodificationModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MaximumonesaftermodificationModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Maximum Ones After Modification',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1700.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nGiven a binary array A and a number B, we need to find length of the longest subsegment of ‘1’s possible by changing at most B ‘0’s.\n\n\n\nProblem Constraints\n 1 <= N, B <= 105\n\n A[i]=0 or A[i]=1\n\n\n\nInput Format\nFirst argument is an binary array A.\n\nSecond argument is an integer B.\n\n\n\nOutput Format\nReturn a single integer denoting the length of the longest subsegment of ‘1’s possible by changing at most B ‘0’s.\n\n\n\nExample Input\nInput 1:\n\n A = [1, 0, 0, 1, 1, 0, 1]\n B = 1\nInput 2:\n\n A = [1, 0, 0, 1, 0, 1, 0, 1, 0, 1]\n B = 2\n\n\nExample Output\nOutput 1:\n\n 4\nOutput 2:\n\n 5\n\n\nExample Explanation\nExplanation 1:\n\n Here, we should only change 1 zero(0). Maximum possible length we can get is by changing the 3rd zero in the array,\n we get a[] = {1, 0, 0, 1, 1, 1, 1}\nExplanation 2:\n\n Here, we can change only 2 zeros. Maximum possible length we can get is by changing the 3rd and 4th (or) 4th and 5th zeros.\n\n\n\n\n\nAnswer :-\n/**\n * @input A : Integer array\n * @input n1 : Integer array\'s ( A ) length\n * @input B : Integer\n * \n * @Output Integer\n */\nint solve(int* A, int n1, int B) {\n    int n=n1;\n    int l=0, i=0, count=0;\n    int ans=INT_MIN;\n    for(i=0;i<n;i++){\n        if(A[i]==0){\n            count++;\n        }\n        while(count>B){\n            if(A[l]==0)count--;\n            l++;\n        }\n        ans=ans>i-l+1?ans:i-l+1;\n    }\n    return ans;\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=hzueK-imcXg&pp=ygUsaW50ZXJ2aWV3Yml0IG1heGltdW0gb25lcyBhZnRlciBtb2RpZmljYXRpb24%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
