import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'evaluateexpression_model.dart';
export 'evaluateexpression_model.dart';

class EvaluateexpressionWidget extends StatefulWidget {
  const EvaluateexpressionWidget({super.key});

  @override
  State<EvaluateexpressionWidget> createState() =>
      _EvaluateexpressionWidgetState();
}

class _EvaluateexpressionWidgetState extends State<EvaluateexpressionWidget> {
  late EvaluateexpressionModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => EvaluateexpressionModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Evaluate Expression',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1900.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nAn arithmetic expression is given by a string array A of size N. Evaluate the value of an arithmetic expression in Reverse Polish Notation.\n\nValid operators are +, -, *, /. Each string may be an integer or an operator.\n\n\n\nProblem Constraints\n1 <= N <= 105\n\n\n\nInput Format\nThe only argument given is string array A.\n\n\n\nOutput Format\nReturn the value of arithmetic expression formed using reverse Polish Notation.\n\n\n\nExample Input\nInput 1:\n    A =   [\"2\", \"1\", \"+\", \"3\", \"*\"]\nInput 2:\n    A = [\"4\", \"13\", \"5\", \"/\", \"+\"]\n\n\nExample Output\nOutput 1:\n    9\nOutput 2:\n    6\n\n\nExample Explanation\nExplaination 1:\n    starting from backside:\n    * : () * ()\n    3 : () * (3)\n    + : (() + ()) * (3)\n    1 : (() + (1)) * (3)\n    2 : ((2) + (1)) * (3)\n    ((2) + (1)) * (3) = 9\nExplaination 2:\n    + : () + ()\n    / : () + (() / ())\n    5 : () + (() / (5))\n    13 : () + ((13) / (5))\n    4 : (4) + ((13) / (5))\n    (4) + ((13) / (5)) = 6\n\n\nAnswer :-\n/**\n * @input A : array of strings termination by \'\\0\'\n * @input n1 : number of strings in array A\n * \n * @Output Integer\n */\nint evalRPN(char** A, int n1) {\n    \n    int* mystack = (int*)malloc(sizeof(int)*n1);\n    \n    int i=0,size=0,a,b;\n    while(i<n1)\n    {\n        char c=A[i][0];\n        if(c==\'+\'||c==\'*\'||c==\'/\'||c==\'-\' && !A[i][1])\n        {\n            b=mystack[size-1];\n            size--;\n            a=mystack[size-1];\n            size--;\n            if(c==\'+\') mystack[size++]=a+b;\n            if(c==\'-\') mystack[size++]=a-b;\n            if(c==\'*\') mystack[size++]=a*b;\n            if(c==\'/\') mystack[size++]=a/b;\n            \n        }\n        else\n        {\n            mystack[size++]=atoi(A[i]);\n        }\n        i++;\n    }\n    return mystack[0];\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=q6tj7yplRck&pp=ygUfaW50ZXJ2aWV3Yml0IGV2YWx1dGUgZXhwcmVzc2lvbg%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
