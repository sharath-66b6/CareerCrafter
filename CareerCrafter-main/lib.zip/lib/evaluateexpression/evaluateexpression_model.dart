import '/flutter_flow/flutter_flow_util.dart';
import 'evaluateexpression_widget.dart' show EvaluateexpressionWidget;
import 'package:flutter/material.dart';

class EvaluateexpressionModel
    extends FlutterFlowModel<EvaluateexpressionWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
