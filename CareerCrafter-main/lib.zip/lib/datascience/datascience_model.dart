import '/flutter_flow/flutter_flow_util.dart';
import 'datascience_widget.dart' show DatascienceWidget;
import 'package:flutter/material.dart';

class DatascienceModel extends FlutterFlowModel<DatascienceWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
