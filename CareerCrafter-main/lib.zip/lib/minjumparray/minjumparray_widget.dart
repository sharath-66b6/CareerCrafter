import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'minjumparray_model.dart';
export 'minjumparray_model.dart';

class MinjumparrayWidget extends StatefulWidget {
  const MinjumparrayWidget({super.key});

  @override
  State<MinjumparrayWidget> createState() => _MinjumparrayWidgetState();
}

class _MinjumparrayWidgetState extends State<MinjumparrayWidget> {
  late MinjumparrayModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MinjumparrayModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Min Jumps Array',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1600.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven an array of non-negative integers, A, of length N, you are initially positioned at the first index of the array.\nEach element in the array represents your maximum jump length at that position.\nReturn the minimum number of jumps required to reach the last index.\nIf it is not possible to reach the last index, return -1.\n\n\nProblem Constraints\n1 <= N <= 106\n0 <= A[i] <= 50000\n\n\nInput Format\nThe first and the only argument contains an integer array, A.\n\n\nOutput Format\nReturn an integer, representing the answer as described in the problem statement.\n\n\nExample Input\nInput 1:\nA = [2, 1, 1]\nInput 2:\nA = [2, 3, 1, 1, 4]\n\n\nExample Output\nOutput 1:\n1\nOutput 1:\n2\n\n\nExample Explanation\nExplanation 1:\nThe shortest way to reach index 2 is\n    Index 0 -> Index 2\nthat requires only 1 jump.\nExplanation 2:\nThe shortest way to reach index 4 is\n    Index 0 -> Index 1 -> Index 4\nthat requires 2 jumps.\n\n\n\nAnswer :-\n/**\n * @input A : Integer array\n * @input n1 : Integer array\'s ( A ) length\n * \n * @Output Integer\n */\nint jump(int* A, int n1) {\n    int steps = 0;\n    int i, max, next;\n    \n    if (n1==1 && A[0] == 0)\n        return 0;\n    \n    for (i=0, max=0, next=0; i<n1-1 && next<n1-1; ++i) {  \n        if (max < i+A[i])\n            max = i+A[i];\n//  max = Math.max(max, i+A[i]);  \n        if (i == next) {  // ready to jump  \n            if (max == next) return -1; // unreachable  \n                next = max;  \n       ++steps;  \n     }  \n   }  \n   return steps;  \n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=CqgK_qi4SKQ&pp=ygUbaW50ZXJ2aWV3Yml0IG1pbiBqdW1wIGFycmF5',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
