import '/flutter_flow/flutter_flow_util.dart';
import 'minjumparray_widget.dart' show MinjumparrayWidget;
import 'package:flutter/material.dart';

class MinjumparrayModel extends FlutterFlowModel<MinjumparrayWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
