import '/flutter_flow/flutter_flow_util.dart';
import 'convertsortedlisttobinarysearchtree_widget.dart'
    show ConvertsortedlisttobinarysearchtreeWidget;
import 'package:flutter/material.dart';

class ConvertsortedlisttobinarysearchtreeModel
    extends FlutterFlowModel<ConvertsortedlisttobinarysearchtreeWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
