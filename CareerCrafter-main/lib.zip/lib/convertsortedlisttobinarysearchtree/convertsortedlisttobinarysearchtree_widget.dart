import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'convertsortedlisttobinarysearchtree_model.dart';
export 'convertsortedlisttobinarysearchtree_model.dart';

class ConvertsortedlisttobinarysearchtreeWidget extends StatefulWidget {
  const ConvertsortedlisttobinarysearchtreeWidget({super.key});

  @override
  State<ConvertsortedlisttobinarysearchtreeWidget> createState() =>
      _ConvertsortedlisttobinarysearchtreeWidgetState();
}

class _ConvertsortedlisttobinarysearchtreeWidgetState
    extends State<ConvertsortedlisttobinarysearchtreeWidget> {
  late ConvertsortedlisttobinarysearchtreeModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model =
        createModel(context, () => ConvertsortedlisttobinarysearchtreeModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Convert Sorted List to Binary Search Tree',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1900.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven a singly linked list where elements are sorted in ascending order, convert it to a height balanced BST.\n\nA height balanced BST : a height-balanced binary tree is defined as a binary tree in which the depth of the two subtrees of every node never differ by more than 1.\n\nExample :\n\n\nGiven A : 1 -> 2 -> 3\nA height balanced BST  :\n\n      2\n    /   \\\n   1     3\n\n\n\nAnswer :-\n/**\n * Definition for binary tree\n * struct TreeNode {\n *     int val;\n *     struct TreeNode *left;\n *     struct TreeNode *right;\n * };\n * \n * typedef struct TreeNode treenode;\n * \n * treenode* treenode_new(int val) {\n *     treenode* node = (treenode *) malloc(sizeof(treenode));\n *     node->val = val;\n *     node->left = NULL;\n *     node->right = NULL;\n *     return node;\n * }\n */\n/**\n * Definition for singly-linked list.\n * struct ListNode {\n *     int val;\n *     struct ListNode *next;\n * };\n * \n * typedef struct ListNode listnode;\n * \n * listnode* listnode_new(int val) {\n *     listnode* node = (listnode *) malloc(sizeof(listnode));\n *     node->val = val;\n *     node->next = NULL;\n *     return node;\n * }\n */\n/**\n * @input A : Head pointer of linked list \n * \n * @Output root pointer of tree.\n */\nint count(listnode *head)\n{\n    int c=0;\n    while(head!=NULL)\n    {\n        head=head->next;\n        c++;\n    }\n    return c;\n}\n\n\ntreenode *sorted(listnode **head,int n)\n{\n    if(n<=0)\n    {\n        return NULL;\n    }\n    \n    treenode *left=sorted(head,n/2);\n    int c=(*head)->val;\n    treenode *root=treenode_new(c);\n    root->left=left;\n    (*head)=(*head)->next;\n    root->right=sorted(head,n-n/2-1);\n    return root;\n}\ntreenode* sortedListToBST(listnode* A)\n{\n    int n=count(A);\n    return sorted(&A,n);\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=4zvmruet_H0&pp=ygU1aW50ZXJ2aWV3Yml0IGNvbnZlcnQgc29ydGVkIGxpc3QgdG8gYmluYXJ5IHNhcmNoIHRyZWU%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
