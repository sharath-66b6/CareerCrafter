import '/flutter_flow/flutter_flow_util.dart';
import 'frontend_widget.dart' show FrontendWidget;
import 'package:flutter/material.dart';

class FrontendModel extends FlutterFlowModel<FrontendWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
