import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'converttheamountinumberstowords_model.dart';
export 'converttheamountinumberstowords_model.dart';

class ConverttheamountinumberstowordsWidget extends StatefulWidget {
  const ConverttheamountinumberstowordsWidget({super.key});

  @override
  State<ConverttheamountinumberstowordsWidget> createState() =>
      _ConverttheamountinumberstowordsWidgetState();
}

class _ConverttheamountinumberstowordsWidgetState
    extends State<ConverttheamountinumberstowordsWidget> {
  late ConverttheamountinumberstowordsModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ConverttheamountinumberstowordsModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Convert the amount in number to words',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2500.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nOur company wants to create a data entry verification system. Given an amount in words and an amount indicated by data entry person in numbers, you have to detect whether the amounts are the same or not.\n\nNote:\nThere are a lot of corner cases to be considered. The interviewer expects you to take care of them.\nEvery word needs to be separated using \"-\" rather than a space character https://en.wikipedia.org/wiki/Indian_numbering_system\n\"Use Expected Output option\" to clear further doubts.\n\n\nProblem Constraints\n1 <= |A| <= 9\n1 <= |B| <= 100\n\n\nInput Format\nString num: Amount written in digits as a string. This string will be an integer number without having any commas in between the digits.\nString words: Amount written in words according to Indian Numbering System.\n\n\nOutput Format\nAn integer\n1: Values match\n0: Otherwise\n\n\nExample Input\nString num = \"1234\"\nString words = \"one-thousand-two-hundred-and-thirty-four\"\n\n\nExample Output\n1\n\n\n\nAnswer ;-\nclass Solution:\n    # @param A : string\n    # @param B : string\n    # @return an integer\n    \n    \n    # strings at index 0 is not used\n    # to make indexing simple\n    # Please note we will add space after every word\n    one =  [\"\", \"one-\", \"two-\", \"three-\", \"four-\",\n                 \"five-\", \"six-\", \"seven-\", \"eight-\",\n                 \"nine-\", \"ten-\", \"eleven-\", \"twelve-\",\n                 \"thirteen-\", \"fourteen-\", \"fifteen-\",\n                 \"sixteen-\", \"seventeen-\", \"eighteen-\",\n                 \"nineteen-\"\n               ]\n \n    # strings at index 0 and 1 are not used to make array indexing simple\n    ten =[ \"\", \"\", \"twenty-\", \"thirty-\", \"forty-\",\n                     \"fifty-\", \"sixty-\", \"seventy-\", \"eighty-\",\n                     \"ninety-\"\n                   ]\n \n    # n is 1- or 2-digit number\n    def numToWords(self, n, s):\n        res = \"\"\n        # if n is more than 19, divide it\n        if (n > 19):\n            res = res + Solution.ten[n / 10] + Solution.one[n % 10]\n        else:\n            res = res + Solution.one[n]\n     \n        # if n is non-zero\n        if (n):\n            res = res + s\n     \n        return res\n        \n    # Function to print a given number in words\n    def convertToWords(self, n):\n        # stores word representation of given number n\n        out = \"\"\n     \n        # handles digits at ten crore and crore places (if any)\n        out += self.numToWords((n / 10000000), \"crore-\")\n     \n        # handles digits at ten lakh and lakh places (if any)\n        out += self.numToWords(((n / 100000) % 100), \"lakh-\")\n     \n        # handles digits at thousands and tens thousands places (if any)\n        out += self.numToWords(((n / 1000) % 100), \"thousand-\")\n     \n        # handles digit at hundreds places (if any)\n        out += self.numToWords(((n / 100) % 10), \"hundred-\")\n     \n        # we need to add \"and\" if the number is more than hundred and contains digit at ten\'s or one\'s place\n        if (n > 100 and n % 100):\n            out += \"and-\"\n     \n        # handles digits at ones and tens places (if any)\n        out += self.numToWords((n % 100), \"\")\n        out = out[:-1] # to remove the last trailing \"-\"\n        return out\n    \n    def solve(self, A, B):\n        n = (int)(A)\n        y = self.convertToWords(n)\n        \n        if(y == B):\n            return 1\n            \n        return 0   \n        \n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=JEz9jXxWavo&pp=ygU0aW50ZXJ2aWV3Yml0IGNvbnZlcnQgdGhlIGFtb3VudHMgaW4gIG51bWJlciB0byB3b3Jkcw%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
