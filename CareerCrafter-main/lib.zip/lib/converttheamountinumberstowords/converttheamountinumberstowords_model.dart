import '/flutter_flow/flutter_flow_util.dart';
import 'converttheamountinumberstowords_widget.dart'
    show ConverttheamountinumberstowordsWidget;
import 'package:flutter/material.dart';

class ConverttheamountinumberstowordsModel
    extends FlutterFlowModel<ConverttheamountinumberstowordsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
