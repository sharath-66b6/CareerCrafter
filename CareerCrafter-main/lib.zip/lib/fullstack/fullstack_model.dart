import '/flutter_flow/flutter_flow_util.dart';
import 'fullstack_widget.dart' show FullstackWidget;
import 'package:flutter/material.dart';

class FullstackModel extends FlutterFlowModel<FullstackWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
