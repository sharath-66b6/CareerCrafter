import '/flutter_flow/flutter_flow_util.dart';
import 'maths_widget.dart' show MathsWidget;
import 'package:flutter/material.dart';

class MathsModel extends FlutterFlowModel<MathsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
