import '/flutter_flow/flutter_flow_util.dart';
import 'interleavingstrings_widget.dart' show InterleavingstringsWidget;
import 'package:flutter/material.dart';

class InterleavingstringsModel
    extends FlutterFlowModel<InterleavingstringsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
