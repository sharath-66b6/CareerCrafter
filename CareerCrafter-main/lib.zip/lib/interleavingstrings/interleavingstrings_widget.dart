import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'interleavingstrings_model.dart';
export 'interleavingstrings_model.dart';

class InterleavingstringsWidget extends StatefulWidget {
  const InterleavingstringsWidget({super.key});

  @override
  State<InterleavingstringsWidget> createState() =>
      _InterleavingstringsWidgetState();
}

class _InterleavingstringsWidgetState extends State<InterleavingstringsWidget> {
  late InterleavingstringsModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InterleavingstringsModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Interleaving Strings',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2200.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \nGiven A, B, C, find whether C is formed by the interleaving of A and B.\n\nInput Format:*\n\nThe first argument of input contains a string, A.\nThe second argument of input contains a string, B.\nThe third argument of input contains a string, C.\nOutput Format:\n\nReturn an integer, 0 or 1:\n    => 0 : False\n    => 1 : True\nConstraints:\n\n1 <= length(A), length(B), length(C) <= 150\nExamples:\n\nInput 1:\n    A = \"aabcc\"\n    B = \"dbbca\"\n    C = \"aadbbcbcac\"\n\nOutput 1:\n    1\n    \nExplanation 1:\n    \"aa\" (from A) + \"dbbc\" (from B) + \"bc\" (from A) + \"a\" (from B) + \"c\" (from A)\n\nInput 2:\n    A = \"aabcc\"\n    B = \"dbbca\"\n    C = \"aadbbbaccc\"\n\nOutput 2:\n    0\n\nExplanation 2:\n    It is not possible to get C by interleaving A and B.\n\n\n\n\n\n\nAnswer :-\n/**\n * @input A : String termination by \' * @input B : String termination by \' * @input C : String termination by \' * \n * @Output Integer\n */\nint isInterleave(char* A, char* B, char* C) {\n    // Find lengths of the two strings\n    int M = strlen(A), N = strlen(B);\n \n    // Let us create a 2D table to store solutions of\n    // subproblems.  C[i][j] will be true if C[0..i+j-1]\n    // is an interleaving of A[0..i-1] and B[0..j-1].\n    int IL[M+1][N+1];\n \n    memset(IL, 0, sizeof(IL)); // Initialize all values as false.\n \n    // C can be an interleaving of A and B only of sum\n    // of lengths of A & B is equal to length of C.\n    if ((M+N) != strlen(C))\n       return 0;\n    int i, j;\n    // Process all characters of A and B\n    for (i=0; i<=M; ++i)\n    {\n        for (j=0; j<=N; ++j)\n        {\n            // two empty strings have an empty string\n            // as interleaving\n            if (i==0 && j==0)\n                IL[i][j] = 1;\n \n            // A is empty\n            else if (i==0 && B[j-1]==C[j-1])\n                IL[i][j] = IL[i][j-1];\n \n            // B is empty\n            else if (j==0 && A[i-1]==C[i-1])\n                IL[i][j] = IL[i-1][j];\n \n            // Current character of C matches with current character of A,\n            // but doesn\'t match with current character of B\n            else if(A[i-1]==C[i+j-1] && B[j-1]!=C[i+j-1])\n                IL[i][j] = IL[i-1][j];\n \n            // Current character of C matches with current character of B,\n            // but doesn\'t match with current character of A\n            else if (A[i-1]!=C[i+j-1] && B[j-1]==C[i+j-1])\n                IL[i][j] = IL[i][j-1];\n \n            // Current character of C matches with that of both A and B\n            else if (A[i-1]==C[i+j-1] && B[j-1]==C[i+j-1])\n                IL[i][j]=(IL[i-1][j] || IL[i][j-1]) ;\n        }\n    }\n \n    return IL[M][N];\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=EzQ_YEmR598&pp=ygUhaW50ZXJ2aWV3Yml0IGludGVybGVhdmluZyBzdHJpbmdz',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
