import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'kthpermutation_model.dart';
export 'kthpermutation_model.dart';

class KthpermutationWidget extends StatefulWidget {
  const KthpermutationWidget({super.key});

  @override
  State<KthpermutationWidget> createState() => _KthpermutationWidgetState();
}

class _KthpermutationWidgetState extends State<KthpermutationWidget> {
  late KthpermutationModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => KthpermutationModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'K-th Permutation',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 3300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nYou are given an integer A which represents the length of a permutation.\n A permutation is an array of length A where all the elements occur exactly once and in any order.\n For example, [3, 4, 1, 2], [1, 2, 3] are examples of valid permutations while [1, 2, 2], [2] are not.\n\nYou are also given an integer B.\n If all the permutation of length A are sorted lexicographically, return the Bth permutation.\n\n\n\nProblem Constraints\n\n1 <= A <= 105\n1 <= B <= min(1018, A!), where A! denotes the factorial of A.\n\n\nInput Format\n\nThe first argument is the integer A.\nThe second argument is the long integer B.\n\n\nOutput Format\n\nReturn an array denoting the Bth permutation of length A.\n\n\nExample Input\n\nInput 1:\n \n\n \n\nA = 3\nB = 3\nInput 2:\n\nA = 1\nB = 1\n \n\n \n\n\n\nExample Output\n\nOutput 1:\n \n\n \n\n[2, 1, 3]\nOutput 2:\n\n[1]\n \n\n \n\n\n\nExample Explanation\n\nExplanation 1:\n \n\n \n\nAll the permutations of length 3 sorted in lexicographical order are:\n[1, 2, 3], [1, 3, 2], [2, 1, 3], [2, 3, 1], [3, 1, 2], [3, 2, 1].\nTherefore, the third permutation is [2, 1, 3].\nExplanation 2:\n\nThere is only one possible permutation -> [1].\n\n\n\nAnswer :- \n/**\n * @input A : Integer\n * @input B : Long\n * \n * @Output Integer array. You need to malloc memory, and fill the length in len1\n */\n\nlong long fact(int A)\n{\n    if(A == 1 || A == 0)\n    {\n        return 1;\n    }\n    long long res = 1;\n    int i;\n    for(i = 2; i <= A; i++)\n    {\n        res = res * i;\n        if(res > 1000000000000000000)\n        {\n            return -1;\n        }\n    }\n    return res;\n}\nint* findPerm(int A, long long B, int *len1) \n{\n    int* result = (int*)malloc(A * sizeof(int));\n    int* used = (int*)malloc(A * sizeof(int));\n    int i, j;\n    for(i = 0; i < A; i++)\n    {\n        used[i] = 0;\n    }\n    long long left_rank = B;\n    int first_remaining = 0;\n    for(i = 0; i < (A - 1); i++)\n    {\n        long long remaining_fact = fact(A - i - 1);\n        int to_skip = left_rank / remaining_fact;\n        if (left_rank == 0)\n        {\n            to_skip = 0;\n        }\n        else if(left_rank % remaining_fact == 0)\n        {\n            to_skip--;\n        }\n        if(remaining_fact == -1 || to_skip == 0)\n        {\n            used[first_remaining] = 1;\n            result[i] = first_remaining+1;\n            j = first_remaining;\n            while(used[j] != 0)\n            {\n                j++;\n            }\n            first_remaining = j;\n        }\n        else\n        {\n            int skipped = 0;\n            j = 0;\n            while(skipped != to_skip)\n            {\n                if(used[j] == 0)\n                {\n                    skipped = skipped + 1;\n                }\n                j++;\n            }\n            while(used[j] != 0)\n            {\n                j++;\n            }\n            result[i] = j + 1;\n            used[j] = 1;\n            left_rank = left_rank - (to_skip) * remaining_fact;\n        }\n    }\n    j = 0;\n    while(used[j] != 0)\n    {\n        j++;\n    }\n    result[A-1] = j+1;\n    *len1 = A;\n    return result;\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=wT7gcXLYoao&pp=ygUcaW50ZXJ2aWV3Yml0IGt0aCBwZXJtdXRhdGlvbg%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
