import '/flutter_flow/flutter_flow_util.dart';
import 'kthpermutation_widget.dart' show KthpermutationWidget;
import 'package:flutter/material.dart';

class KthpermutationModel extends FlutterFlowModel<KthpermutationWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
