import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'leastcommonancestor_model.dart';
export 'leastcommonancestor_model.dart';

class LeastcommonancestorWidget extends StatefulWidget {
  const LeastcommonancestorWidget({super.key});

  @override
  State<LeastcommonancestorWidget> createState() =>
      _LeastcommonancestorWidgetState();
}

class _LeastcommonancestorWidgetState extends State<LeastcommonancestorWidget> {
  late LeastcommonancestorModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => LeastcommonancestorModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Least Common Ancestor',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2100.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nFind the lowest common ancestor in an unordered binary tree given two values in the tree.\n\nLowest common ancestor: the lowest common ancestor (LCA) of two nodes v and w in a tree or directed acyclic graph (DAG) is the lowest (i.e. deepest) node that has both v and w as descendants.\n\nNote:\nYou are given 2 values. Find the lowest common ancestor of the two nodes represented by val1 and val2\nNo guarantee that val1 and val2 exist in the tree. If one value doesn\'t exist in the tree then return -1.\nThere are no duplicate values.\nYou can use extra memory, and helper functions, and can modify the node struct but, you can\'t add a parent pointer.\n\n\nInput Format\nThe first argument is a TreeNode A, pointing to the root of the binary tree.\nThe second argument is an integer B.\nThe third argument is an integer C.\n\n\nOutput Format\nReturn an integer, equal to the value of the LCA of B and C.\n\n\nExample Input\n\n\n        _______3______\n       /              \\\n    ___5__          ___1__\n   /      \\        /      \\\n   6      _2_     0        8\n         /   \\\n         7    4\n\n\nB = 5\nC = 1\n\n\n\nExample Output\n3\n\n\nExample Explanation\n\n\n        _______3______\n       /              \\\n    ___5__          ___1__\n   /      \\        /      \\\n   6      _2_     0        8\n         /   \\\n         7    4\n\nFor the above tree, the LCA of nodes 5 and 1 is 3.\nPlease note that LCA for nodes 5 and 4 is 5.\n\n\n\n\nAnswer :-\ntreenode* inorder(treenode *A,int x)\n{\n\tif(!A)return NULL;\n\tif(A->val == x)\n\t\treturn A;\n\ttreenode *t = inorder(A->left,x);\n\t    if(t)\n\t        return t;\n\t   return  inorder(A->right,x);\t\n}\n\ntreenode* lowestCommonAncestor(treenode* root, treenode* p, treenode* q) {\n    \n\tif(!root){\n\treturn\tNULL;\n\t}\n    treenode *x = lowestCommonAncestor(root->left,p,q);\n\ttreenode *y = lowestCommonAncestor(root->right,p,q);\n\tif(x&&y)\n\t\treturn root;\n\tif(root->val == p->val || root->val == q->val){\n\t\treturn root;\t\n\t}\n\treturn x?x:y;\n}\nint lca(treenode* A, int val1, int val2) {\n\ttreenode *p = inorder(A,val1);\n\ttreenode *q = inorder(A,val2);\n\t\n\tif(!p||!q)return -1;\n//\tprintf(\"%d  %d\",p->val,q->val);\n\t//if(p==q)\n\t  //  return p->val;\n\tif(p = lowestCommonAncestor(A,p,q))return p->val;\n\t//return ;\n}',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=T6Jr-Q6bvSU&pp=ygUiaW50ZXJ2aWV3Yml0IGxlYXN0IGNvbW1vbiBhbmNlc3Rvcg%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
