import '/flutter_flow/flutter_flow_util.dart';
import 'flatenbinarytreetobinarytree_widget.dart'
    show FlatenbinarytreetobinarytreeWidget;
import 'package:flutter/material.dart';

class FlatenbinarytreetobinarytreeModel
    extends FlutterFlowModel<FlatenbinarytreetobinarytreeWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
