import '/flutter_flow/flutter_flow_util.dart';
import 'infosesquestions_widget.dart' show InfosesquestionsWidget;
import 'package:flutter/material.dart';

class InfosesquestionsModel extends FlutterFlowModel<InfosesquestionsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
