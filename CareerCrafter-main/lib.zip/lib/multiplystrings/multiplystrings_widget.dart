import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'multiplystrings_model.dart';
export 'multiplystrings_model.dart';

class MultiplystringsWidget extends StatefulWidget {
  const MultiplystringsWidget({super.key});

  @override
  State<MultiplystringsWidget> createState() => _MultiplystringsWidgetState();
}

class _MultiplystringsWidgetState extends State<MultiplystringsWidget> {
  late MultiplystringsModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MultiplystringsModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Multiply Strings',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1700.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven two numbers represented as strings, return the multiplication of the numbers as a string.\nNote: \nThe numbers can be arbitrarily large and are non-negative.\nYour answer should not have leading zeroes. For example, 00 is not a valid answer.\nDO NOT USE BIG INTEGER LIBRARIES ( WHICH ARE AVAILABLE IN JAVA / PYTHON ). We will retroactively disqualify such submissions and the submissions will incur penalties.\n\n\nProblem Constraints\n1 <= |A|, |B| <= 104\n1 <= |A| * |B| <= 106\n\n\nInput Format\nThe first argument is a string A, representing the first number.\nThe second argument is a string B, representing the second number.\n\n\nOutput Format\nReturn a string, equal to the product of A and B.\n\n\nExample Input\nA = \"10\"\nB = \"12\"\n\n\nExample Output\n\"120\"\n\n\nExample Explanation\nA = 10 and B = 12, A * B is 120, return it in the string without leading zeroes.\n\nAnswer :-\n/**\n * @input A : String termination by \'\\0\'\n * @input B : String termination by \'\\0\'\n * \n * @Output string. Make sure the string ends with null character\n */\nchar* multiply(char* A, char* B) \n{\n    int la = strlen(A);\n    int lb = strlen(B);\n    \n    char *res = malloc(sizeof(char) * (la + lb + 1));\n    int i, j, k, start = 0, carry;\n    \n    for(i = 0; i < ( la + lb + 1); ++i)\n        res[i] = \'0\';\n        \n    for(j = lb - 1; j >= 0; --j)\n    {   \n        carry = 0;\n        k = start++;\n        for(i = la - 1; i >= 0; --i)\n            {\n                int prod = (B[j]-\'0\') * (A[i]-\'0\');\n                int prev = res[k] - \'0\';\n                res[k++] = (prev + prod + carry) % 10 + \'0\';\n                carry = (prev + prod + carry) / 10;\n            }\n        res[k++] = carry + \'0\';\n    }\n    \n    while(k > 0 && res[k] == \'0\') k--;\n    res[k + 1] = \'\\0\';\n    for(i = 0; i < (k + 1)/2; ++i)\n    {\n        char t = res[i];\n        res[i] = res[k - i];\n        res[k - i] = t;\n    }\n    \n    return res;\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=HhwZ1O6TNLE&pp=ygUcaW50ZXJ2aWV3Yml0IG11bHRpcGx5IHN0cmluZw%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
