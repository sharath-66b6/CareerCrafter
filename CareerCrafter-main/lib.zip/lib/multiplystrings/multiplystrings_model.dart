import '/flutter_flow/flutter_flow_util.dart';
import 'multiplystrings_widget.dart' show MultiplystringsWidget;
import 'package:flutter/material.dart';

class MultiplystringsModel extends FlutterFlowModel<MultiplystringsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
