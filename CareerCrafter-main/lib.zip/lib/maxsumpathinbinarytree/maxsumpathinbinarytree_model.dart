import '/flutter_flow/flutter_flow_util.dart';
import 'maxsumpathinbinarytree_widget.dart' show MaxsumpathinbinarytreeWidget;
import 'package:flutter/material.dart';

class MaxsumpathinbinarytreeModel
    extends FlutterFlowModel<MaxsumpathinbinarytreeWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
