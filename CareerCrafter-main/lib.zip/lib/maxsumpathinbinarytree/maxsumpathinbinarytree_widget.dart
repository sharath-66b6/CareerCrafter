import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'maxsumpathinbinarytree_model.dart';
export 'maxsumpathinbinarytree_model.dart';

class MaxsumpathinbinarytreeWidget extends StatefulWidget {
  const MaxsumpathinbinarytreeWidget({super.key});

  @override
  State<MaxsumpathinbinarytreeWidget> createState() =>
      _MaxsumpathinbinarytreeWidgetState();
}

class _MaxsumpathinbinarytreeWidgetState
    extends State<MaxsumpathinbinarytreeWidget> {
  late MaxsumpathinbinarytreeModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MaxsumpathinbinarytreeModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Max Sum Path in Binary Tree',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2500.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven a binary tree T, find the maximum path sum.\n\nThe path may start and end at any node in the tree.\n\n\n\nProblem Constraints\n1 <= Number of Nodes <= 7e4\n\n-1000 <= Value of Node in T <= 1000\n\n\n\nInput Format\n The first and the only argument contains a pointer to the root of T, A.\n\n\n\nOutput Format\nReturn an integer representing the maximum sum path.\n\n\n\nExample Input\nInput 1:\n\n    1\n   / \\\n  2   3\nInput 2:\n\n       20\n      /  \\\n   -10   20\n        /  \\\n      -10  -50\n\n\nExample Output\nOutput 1:\n\n 6\nOutput 2:\n\n 40\n\n\nExample Explanation\nExplanation 1:\n\n     The path with maximum sum is: 2 -> 1 -> 3\nExplanation 2:\n\n     The path with maximum sum is: 20 -> 20\n\n\n\n\nAnswer :-\n/**\n * Definition for binary tree\n * struct TreeNode {\n *     int val;\n *     struct TreeNode *left;\n *     struct TreeNode *right;\n * };\n * \n * typedef struct TreeNode treenode;\n * \n * treenode* treenode_new(int val) {\n *     treenode* node = (treenode *) malloc(sizeof(treenode));\n *     node->val = val;\n *     node->left = NULL;\n *     node->right = NULL;\n *     return node;\n * }\n */\n/**\n * @input A : Root pointer of the tree \n * \n * @Output Integer\n */\n\nint maximum(int a,int b){\n    return (a<=b)?b:a;\n}\n\nvoid traverse(treenode *node,int *maxPath,int *maxDist){\n    if(node==NULL){\n        *maxPath = 0;\n        *maxDist = 0;\n        return;\n    }\n    if(node->left==NULL && node->right==NULL){\n        *maxPath = node->val;\n        *maxDist = node->val;\n        return;\n    }\n    int lpath,rpath,ldist,rdist;\n    traverse(node->left,&lpath,&ldist);\n    traverse(node->right,&rpath,&rdist);\n    *maxPath = maximum(maximum(lpath,rpath),node->val+ldist+rdist);\n    *maxDist = maximum(maximum(ldist,rdist)+node->val,node->val);\n}\n\nint maxVal(treenode *node){\n    if(!node)\n        return INT_MIN;\n    int lval,rval;\n    lval = maxVal(node->left);\n    rval = maxVal(node->right);\n    return maximum(maximum(lval,rval),node->val);\n}\n\nint maxPathSum(treenode* A) {\n    if(A==NULL)\n        return 0;\n    int maxPath,maxDist;\n    traverse(A,&maxPath,&maxDist);\n    if(maxPath==0)\n        return maxVal(A);\n    return maxPath;\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=JBYs5J4skZE&pp=ygUoaW50ZXJ2aWV3Yml0IG1heCBzdW0gcGF0aCBpbiBiaW5hcnkgdHJlZQ%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
