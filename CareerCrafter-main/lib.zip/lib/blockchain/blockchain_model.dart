import '/flutter_flow/flutter_flow_util.dart';
import 'blockchain_widget.dart' show BlockchainWidget;
import 'package:flutter/material.dart';

class BlockchainModel extends FlutterFlowModel<BlockchainWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
