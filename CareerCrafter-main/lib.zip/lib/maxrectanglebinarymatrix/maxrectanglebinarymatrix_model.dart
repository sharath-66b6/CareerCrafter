import '/flutter_flow/flutter_flow_util.dart';
import 'maxrectanglebinarymatrix_widget.dart'
    show MaxrectanglebinarymatrixWidget;
import 'package:flutter/material.dart';

class MaxrectanglebinarymatrixModel
    extends FlutterFlowModel<MaxrectanglebinarymatrixWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
