import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'atoi_model.dart';
export 'atoi_model.dart';

class AtoiWidget extends StatefulWidget {
  const AtoiWidget({super.key});

  @override
  State<AtoiWidget> createState() => _AtoiWidgetState();
}

class _AtoiWidgetState extends State<AtoiWidget> {
  late AtoiModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => AtoiModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Atoi',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 3000.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nCompare two version numbers version1 and version2.\nIf version1 > version2 return 1,\nIf version1 < version2 return -1,\notherwise return 0.\nYou may assume that the version strings are non-empty and contain only digits and the . character.\nThe . character does not represent a decimal point and is used to separate number sequences. For instance, 2.5 is not \"two and a half\" or \"half way to version three\", it is the fifth second-level revision of the second first-level revision.\n\nNote: Here is an example of version numbers ordering:\n0.1 < 1.1 < 1.2 < 1.13 < 1.13.4\n\n\nProblem Constraints\n1 <= |A|, |B| <= 5000\n\n\nInput Format\nThe first argument is a string A representing version1.\nThe first argument is a string B representing version2.\n\n\nOutput Format\nReturn an integer.\n\n\nExample Input\nA = \"1.13\"\n\nB = \"1.13.4\"\n\n\n\nExample Output\n-1\n\n\nExample Explanation\nVersion1 = \"1.13\"\nVersion2 = \"1.13.4\"\nVersion1 < version2, hence return -1\n\n\nAnswer :-\n/**\n * @input A : String termination by \'\\0\'\n * @input B : String termination by \'\\0\'\n * \n * @Output Integer\n */\nint compareVersion(char* A, char* B) {\n    \n    int lenA = strlen(A);\n    int lenB = strlen(B);\n    char *ver1 = (char*) malloc (sizeof(char) * lenA);\n    char *ver2 = (char*) malloc (sizeof(char) * lenB);\n    unsigned long long int version1=0, version2=0;\n    int i=0,j=0,k=0,Aperiod=0,Bperiod=0;\n    //ver1[0]=\'0\';ver2[0]=\'0\';\n    while(Aperiod<lenA || Bperiod<lenB)\n    {\n                       //printf(\"here in while\\n\");\n        i=Aperiod;k=0;\n        while(i<lenA && A[i]==\'0\') i++;\n        while(i<lenA && A[i]!=\'.\') {ver1[k++]=A[i++];version1=10*version1+ A[i-1]-48;}\n        ver1[k]=\'\\0\';\n        Aperiod=i+1;\n        j=Bperiod;k=0;\n        while(j<lenB && B[j]==\'0\' ) j++;\n        while(j<lenB && B[j]!=\'.\') {ver2[k++]=B[j++];version2=10*version2 + B[j-1]-48;}\n        ver2[k]=\'\\0\';\n        Bperiod=j+1;\n        //printf(\"ver1 = %s\\n ver2 = %s\\n\",ver1,ver2);\n        //int val= strcmp(ver1,ver2);\n       // if(val>0) return 1;\n        //else if(val<0) return -1;\n        if(version1>version2) return 1;\n        else if(version2>version1) return -1;\n        else\n        {\n            version1=0;\n            version2=0;\n        }\n        //else if(Aperiod>=lenA && Bperiod<lenB) return -1;\n        //else if(Aperiod<lenA && Bperiod>=lenB) return 1;\n    }\n    return 0;\n}\nThere are certain questions where the interviewer would intentionally frame the question vague.\n\nThe expectation is that you will ask the correct set of clarifications or state your assumptions before you jump into coding.\n\nImplement atoi to convert a string to an integer.\n\nExample :\n\nInput : \"9 2704\"\nOutput : 9\nNote: There might be multiple corner cases here. Clarify all your doubts using “See Expected Output”.\n\nQuestions:\n\nQ1. Does string contain whitespace characters before the number?\n\nA. Yes\n\nQ2. Can the string have garbage characters after the number?\n\nA. Yes. Ignore it.\n\nQ3. If no numeric character is found before encountering garbage characters, what should I do?\n\nA. Return 0.\n\nQ4. What if the integer overflows?\n\nA. Return INT_MAX if the number is positive, INT_MIN otherwise.\n\n\n\nAnswer :-\n/**\n * @input A : Read only ( DON\'T MODIFY ) String termination by \'\\0\'\n * \n * @Output Integer\n */\nint matoi(const char* A) {\n    int sign = 1, base = 0, i = 0;\n            while (A[i] == \' \') { i++; }\n            if (A[i] == \'-\' || A[i] == \'+\') {\n                sign = (A[i++] == \'-\') ? -1 : 1; \n            }\n            while (A[i] >= \'0\' && A[i] <= \'9\') {\n                if (base >  INT_MAX / 10 || (base == INT_MAX / 10 && A[i] - \'0\' > 7)) {\n                    if (sign == 1) return INT_MAX;\n                    else return INT_MIN;\n                }\n                base  = 10 * base + (A[i++] - \'0\');\n            }\n            return base * sign;\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=2I9XO8jwZCA&pp=ygURaW50ZXJ2aWV3Yml0IGF0b2k%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
