import '/flutter_flow/flutter_flow_util.dart';
import 'atoi_widget.dart' show AtoiWidget;
import 'package:flutter/material.dart';

class AtoiModel extends FlutterFlowModel<AtoiWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
