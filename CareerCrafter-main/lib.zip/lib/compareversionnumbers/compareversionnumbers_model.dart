import '/flutter_flow/flutter_flow_util.dart';
import 'compareversionnumbers_widget.dart' show CompareversionnumbersWidget;
import 'package:flutter/material.dart';

class CompareversionnumbersModel
    extends FlutterFlowModel<CompareversionnumbersWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
