import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'jumpgamearray_model.dart';
export 'jumpgamearray_model.dart';

class JumpgamearrayWidget extends StatefulWidget {
  const JumpgamearrayWidget({super.key});

  @override
  State<JumpgamearrayWidget> createState() => _JumpgamearrayWidgetState();
}

class _JumpgamearrayWidgetState extends State<JumpgamearrayWidget> {
  late JumpgamearrayModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => JumpgamearrayModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Jump Game Array',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1500.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \nGiven an array of non-negative integers, A, you are initially positioned at the 0th index of the array.\n\nEach element in the array represents your maximum jump length at that position.\n\nDetermine if you are able to reach the last index.\n\n\n\nInput Format:\n\nThe first and the only argument of input will be an integer array A.\nOutput Format:\n\nReturn an integer, representing the answer as described in the problem statement.\n    => 0 : If you cannot reach the last index.\n    => 1 : If you can reach the last index.\nConstraints:\n\n    1 <= len(A) <= 106\n\n\n    0 <= A[i] <= 30\n\nExamples:\n\nInput 1:\n    A = [2,3,1,1,4]\n\nOutput 1:\n    1\n\nExplanation 1:\n    Index 0 -> Index 2 -> Index 3 -> Index 4\n\nInput 2:\n    A = [3,2,1,0,4]\n\nOutput 2:\n    0\n\nExplanation 2:\n    There is no possible path to reach the last index.\n\n\n\n\n\n\n\nAnswer :-\nint canJump(int* a, int n) {\n    int i=n-2;\n    int j=n;\n    if(n==1)\n     return 1;\n    for(;i>=0;i--)\n    {\n        if((a[i]+i>=n-1)||(a[i]+i>=j))\n          j=i;\n    }\n    if(j==0)\n     return 1;\n     return 0;\n    \n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=muDPTDrpS28&pp=ygUcaW50ZXJ2aWV3Yml0IGp1bXAgZ2FtZSBhcnJheQ%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
