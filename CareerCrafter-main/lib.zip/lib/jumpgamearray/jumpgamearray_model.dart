import '/flutter_flow/flutter_flow_util.dart';
import 'jumpgamearray_widget.dart' show JumpgamearrayWidget;
import 'package:flutter/material.dart';

class JumpgamearrayModel extends FlutterFlowModel<JumpgamearrayWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
