import '/flutter_flow/flutter_flow_util.dart';
import 'longestvalidparentheses_widget.dart' show LongestvalidparenthesesWidget;
import 'package:flutter/material.dart';

class LongestvalidparenthesesModel
    extends FlutterFlowModel<LongestvalidparenthesesWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
