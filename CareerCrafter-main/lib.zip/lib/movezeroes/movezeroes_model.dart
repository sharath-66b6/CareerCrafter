import '/flutter_flow/flutter_flow_util.dart';
import 'movezeroes_widget.dart' show MovezeroesWidget;
import 'package:flutter/material.dart';

class MovezeroesModel extends FlutterFlowModel<MovezeroesWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
