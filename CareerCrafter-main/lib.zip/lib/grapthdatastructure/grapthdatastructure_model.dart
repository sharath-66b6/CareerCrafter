import '/flutter_flow/flutter_flow_util.dart';
import 'grapthdatastructure_widget.dart' show GrapthdatastructureWidget;
import 'package:flutter/material.dart';

class GrapthdatastructureModel
    extends FlutterFlowModel<GrapthdatastructureWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
