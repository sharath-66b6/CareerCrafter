import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'arrange2_model.dart';
export 'arrange2_model.dart';

class Arrange2Widget extends StatefulWidget {
  const Arrange2Widget({super.key});

  @override
  State<Arrange2Widget> createState() => _Arrange2WidgetState();
}

class _Arrange2WidgetState extends State<Arrange2Widget> {
  late Arrange2Model _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => Arrange2Model());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).primary,
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30.0,
            borderWidth: 1.0,
            buttonSize: 60.0,
            icon: const Icon(
              Icons.arrow_back_rounded,
              color: Colors.white,
              size: 30.0,
            ),
            onPressed: () async {
              context.pop();
            },
          ),
          title: Text(
            'Arrange II',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: 'Outfit',
                  color: Colors.white,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                ),
          ),
          actions: const [],
          centerTitle: true,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: ListView(
            padding: const EdgeInsets.symmetric(vertical: 12.0),
            scrollDirection: Axis.vertical,
            children: [
              Container(
                width: 100.0,
                height: 1700.0,
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryBackground,
                ),
                child: Align(
                  alignment: const AlignmentDirectional(0.0, -1.0),
                  child: Text(
                    'Problem Description\n\nYou are given a sequence of black and white horses, and a set of K stables numbered 1 to K. You have to accommodate the horses into the stables in such a way that the following conditions are satisfied:\n\nYou fill the horses into the stables preserving the relative order of horses. For instance, you cannot put horse 1 into stable 2 and horse 2 into stable 1. You have to preserve the ordering of the horses.\nNo stable should be empty and no horse should be left unaccommodated.\nTake the product (number of white horses * number of black horses) for each stable and take the sum of all these products. This value should be the minimum among all possible accommodation arrangements\nExample:\n\n\nInput: {WWWB} , K = 2\nOutput: 0\n\nExplanation:\nWe have 3 choices {W, WWB}, {WW, WB}, {WWW, B}\nfor first choice we will get 1*0 + 2*1 = 2.\nfor second choice we will get 2*0 + 1*1 = 1.\nfor third choice we will get 3*0 + 0*1 = 0.\n\nOf the 3 choices, the third choice is the best option. \n\nIf a solution is not possible, then return -1\n\n\n\n\nAnswer :-\n/**\n * @input A : String termination by \'\\0\'\n * @input B : Integer\n * \n * @Output Integer\n */\n #define MIN(x,y) (x>y?y:x)\nint result[1000][1000];\nint arrange(char* A, int B)\n{\nint len=strlen(A),w=0,b=0,i,j,l;\nif(len<B)\n    return -1;\n//complete first and second row \nfor(i=0;i<len;i++)\n{\n    result[0][i]=INT_MAX;\n    if(A[i]==\'W\')\n        w++;\n    else\n        b++;\n    result[1][i]=w*b;\n}\n//complete the rest of the result\nfor(i=2;i<=B;i++)\n{\n    //w=0,b=0;\n    for(j=i-1;j<len;j++)\n    {\n        w=0,b=0;\n       result[i][j]=INT_MAX;\n        for(l=j;l>=i-1;l--)\n        {\n             if(A[l]==\'W\')\n                     w++;\n                else\n                    b++;\n            result[i][j]=MIN(result[i][j],result[i-1][l-1]+(w*b));\n        }\n    }\n    \n}\nreturn result[B][len-1];    \n}\n\n',
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Readex Pro',
                          letterSpacing: 0.0,
                        ),
                  ),
                ),
              ),
            ].divide(const SizedBox(height: 12.0)),
          ),
        ),
      ),
    );
  }
}
