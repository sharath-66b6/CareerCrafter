import '/flutter_flow/flutter_flow_util.dart';
import 'arrange2_widget.dart' show Arrange2Widget;
import 'package:flutter/material.dart';

class Arrange2Model extends FlutterFlowModel<Arrange2Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
