import '/flutter_flow/flutter_flow_util.dart';
import 'compnaywisequestion_widget.dart' show CompnaywisequestionWidget;
import 'package:flutter/material.dart';

class CompnaywisequestionModel
    extends FlutterFlowModel<CompnaywisequestionWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
