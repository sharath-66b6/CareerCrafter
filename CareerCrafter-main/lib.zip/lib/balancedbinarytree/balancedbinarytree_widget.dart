import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'balancedbinarytree_model.dart';
export 'balancedbinarytree_model.dart';

class BalancedbinarytreeWidget extends StatefulWidget {
  const BalancedbinarytreeWidget({super.key});

  @override
  State<BalancedbinarytreeWidget> createState() =>
      _BalancedbinarytreeWidgetState();
}

class _BalancedbinarytreeWidgetState extends State<BalancedbinarytreeWidget> {
  late BalancedbinarytreeModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => BalancedbinarytreeModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Balanced Binary Tree',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2100.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven a root of binary tree A, determine if it is height-balanced.\n\nA height-balanced binary tree is defined as a binary tree in which the depth of the two subtrees of every node never differ by more than 1.\n\n\n\nProblem Constraints\n1 <= size of tree <= 100000\n\n\n\nInput Format\nFirst and only  argument is the root of the tree A.\n\n\n\nOutput Format\nReturn 0 / 1 ( 0 for false, 1 for true ) for this problem.\n\n\n\nExample Input\nInput 1:\n\n    1\n   / \\\n  2   3\nInput 2:\n\n \n       1\n      /\n     2\n    /\n   3\n\n\nExample Output\nOutput 1:\n\n1\nOutput 2:\n\n0\n\n\nExample Explanation\nExplanation 1:\n\nIt is a complete binary tree.\nExplanation 2:\n\nBecause for the root node, left subtree has depth 2 and right subtree has depth 0. \nDifference = 2 > 1. \n\n\n\nAnswer :- \n/**\n * Definition for binary tree\n * struct TreeNode {\n *     int val;\n *     struct TreeNode *left;\n *     struct TreeNode *right;\n * };\n * \n * typedef struct TreeNode treenode;\n * \n * treenode* treenode_new(int val) {\n *     treenode* node = (treenode *) malloc(sizeof(treenode));\n *     node->val = val;\n *     node->left = NULL;\n *     node->right = NULL;\n *     return node;\n * }\n */\n/**\n * @input A : Root pointer of the tree \n * \n * @Output Integer\n */\n int max(int a ,int b){if(a<b)return b;else return a;}\n int Aux_isbalanced(treenode *A, int *isit){\n     if(!A){*isit = 1;return 0;}\n    int  x = Aux_isbalanced(A->left, isit);\n     if(*isit){\n      int   y = Aux_isbalanced(A->right, isit);\n      if(*isit){\n      if(x-y > 1 || x-y < -1){ *isit = 0;return 0;}\n        return max(x,y)+1;\n      }    \n     }    \n     return 0;\n }\nint isBalanced(treenode* A) {\n    int isit = 0;\n    Aux_isbalanced(A,&isit);\n    return isit;\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=hmasyzjIESM&pp=ygUhaW50ZXJ2aWV3Yml0IGJhbGFuY2VkIGJpbmFyeSB0cmVl',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
