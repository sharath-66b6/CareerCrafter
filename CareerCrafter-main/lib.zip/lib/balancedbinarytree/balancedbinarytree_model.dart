import '/flutter_flow/flutter_flow_util.dart';
import 'balancedbinarytree_widget.dart' show BalancedbinarytreeWidget;
import 'package:flutter/material.dart';

class BalancedbinarytreeModel
    extends FlutterFlowModel<BalancedbinarytreeWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
