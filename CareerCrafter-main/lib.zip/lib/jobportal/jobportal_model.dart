import '/flutter_flow/flutter_flow_util.dart';
import 'jobportal_widget.dart' show JobportalWidget;
import 'package:flutter/material.dart';

class JobportalModel extends FlutterFlowModel<JobportalWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
