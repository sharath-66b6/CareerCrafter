import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'combinationsum_model.dart';
export 'combinationsum_model.dart';

class CombinationsumWidget extends StatefulWidget {
  const CombinationsumWidget({super.key});

  @override
  State<CombinationsumWidget> createState() => _CombinationsumWidgetState();
}

class _CombinationsumWidgetState extends State<CombinationsumWidget> {
  late CombinationsumModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CombinationsumModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Combination Sum',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2900.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven an array of candidate numbers A and a target number B, find all unique combinations in A where the candidate numbers sums to B.\n\nThe same repeated number may be chosen from A unlimited number of times.\n\nNote:\n\n1) All numbers (including target) will be positive integers.\n\n2) Elements in a combination (a1, a2, … , ak) must be in non-descending order. (ie, a1 ≤ a2 ≤ … ≤ ak).\n\n3) The combinations themselves must be sorted in ascending order.\n\n4) CombinationA > CombinationB iff (a1 > b1) OR (a1 = b1 AND a2 > b2) OR ... (a1 = b1 AND a2 = b2 AND ... ai = bi AND ai+1 > bi+1)\n\n5) The solution set must not contain duplicate combinations.\n\n \n\n\n\nProblem Constraints\n1 <= |A| <= 20 \n\n1 <= A[i] <= 50\n\n1 <= B <= 500\n\n\n\nInput Format\nThe first argument is an integer array A.\n\nThe second argument is integer B.\n\n\n\nOutput Format\n Return a vector of all combinations that sum up to B.\n\n\n\nExample Input\nInput 1:\n\nA = [2, 3]\nB = 2\nInput 2:\n\nA = [2, 3, 6, 7]\nB = 7\n\n\nExample Output\nOutput 1:\n\n[ [2] ]\nOutput 2:\n\n[ [2, 2, 3] , [7] ]\n\n\nExample Explanation\nExplanation 1:\n\nAll possible combinations are listed.\nExplanation 2:\n\nAll possible combinations are listed.\n\n\n\n\nAnswer :-\n/**\n * @input A : Integer array\n * @input n1 : Integer array\'s ( A ) length\n * @input B : Integer\n * \n * @Output 2D int array. You need to malloc memory. Fill in len1 as row\n * For each row i, A[i][0] should indicate the number of columns in row i.\n * Then A[i][1] to A[i][col] should have the values in those columns.\n */\n int x;\n void init()\n {\n     x=0;\n }\nvoid answer(int **result,int *A,int *s,int i,int left,int right,int B)\n{\n    int m,n;\n    if (left < right && i<B) {\n    s[i] = A[left];\n    int k=0,sum=0;\n    for(k=0;k<=i;k++)\n    sum+=s[k];\n    if(sum>B)\n    return;\n    if(sum==B)\n    {\n    for(m = 0, n = 1; m <=i; m++)\n    {\n            result[x] = realloc(result[x], (n+1) * sizeof(int));\n            result[x][n++] = s[m];\n    }\n    result[x][0] = n - 1;\n    x++;\n    }\n    int f = left+1;\n    while(A[left]==A[f] && f<=right-1)\n    {\n        f++;\n    }\n    answer(result,A,s,i+1,left,right,B);\n    //answer(result,A,s,i+1,left+1,right,B);\n    answer(result,A,s,i,f,right,B); \n    }\n}\n\nint cmpfunc(const void *a, const void *b)\n{\n    return (*(int*)a - *(int*)b);\n}\nint ** combinationSum(int* A, int n1, int B, int *len1) {\n    init();\n    qsort(A,n1,sizeof(int),cmpfunc);\n    *len1=1000;\n    int **result = (int **)malloc(200*sizeof(int *));\n    int i;\n    for(i=0;i<200;i++)\n    {\n    result[i] = (int *)malloc(sizeof(int));\n    }\n    int s[B];\n    //result = (int **)realloc()\n    answer(result,A,s,0,0,n1,B);\n    *len1 = x;\n    return result;\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=xT6j7_REjIE&pp=ygUcaW50ZXJ2aWV3Yml0IGNvbWJpbmF0aW9uIHN1bQ%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
