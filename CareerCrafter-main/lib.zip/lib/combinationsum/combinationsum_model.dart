import '/flutter_flow/flutter_flow_util.dart';
import 'combinationsum_widget.dart' show CombinationsumWidget;
import 'package:flutter/material.dart';

class CombinationsumModel extends FlutterFlowModel<CombinationsumWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
