import '/flutter_flow/flutter_flow_util.dart';
import 'kreverselinkedlist_widget.dart' show KreverselinkedlistWidget;
import 'package:flutter/material.dart';

class KreverselinkedlistModel
    extends FlutterFlowModel<KreverselinkedlistWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
