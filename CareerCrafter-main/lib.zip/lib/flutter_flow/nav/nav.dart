import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '/index.dart';
import '/flutter_flow/flutter_flow_util.dart';

export 'package:go_router/go_router.dart';
export 'serialization_util.dart';

const kTransitionInfoKey = '__transition_info__';

class AppStateNotifier extends ChangeNotifier {
  AppStateNotifier._();

  static AppStateNotifier? _instance;
  static AppStateNotifier get instance => _instance ??= AppStateNotifier._();

  bool showSplashImage = true;

  void stopShowingSplashImage() {
    showSplashImage = false;
    notifyListeners();
  }
}

GoRouter createRouter(AppStateNotifier appStateNotifier) => GoRouter(
      initialLocation: '/',
      debugLogDiagnostics: true,
      refreshListenable: appStateNotifier,
      errorBuilder: (context, state) => appStateNotifier.showSplashImage
          ? Builder(
              builder: (context) => Container(
                color: Colors.transparent,
                child: Image.asset(
                  'assets/images/Designer.png',
                  fit: BoxFit.cover,
                ),
              ),
            )
          : const HomePageWidget(),
      routes: [
        FFRoute(
          name: '_initialize',
          path: '/',
          builder: (context, _) => appStateNotifier.showSplashImage
              ? Builder(
                  builder: (context) => Container(
                    color: Colors.transparent,
                    child: Image.asset(
                      'assets/images/Designer.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                )
              : const HomePageWidget(),
        ),
        FFRoute(
          name: 'HomePage',
          path: '/homePage',
          builder: (context, params) => const HomePageWidget(),
        ),
        FFRoute(
          name: 'ProblemTopic',
          path: '/problemTopic',
          builder: (context, params) => const ProblemTopicWidget(),
        ),
        FFRoute(
          name: 'TimeComplexity',
          path: '/timeComplexity',
          builder: (context, params) => const TimeComplexityWidget(),
        ),
        FFRoute(
          name: 'Loop-cmpl',
          path: '/loopCmpl',
          builder: (context, params) => const LoopCmplWidget(),
        ),
        FFRoute(
          name: 'Nestedcmpl3',
          path: '/nestedcmpl3',
          builder: (context, params) => const Nestedcmpl3Widget(),
        ),
        FFRoute(
          name: 'Nestedcmpl',
          path: '/nestedcmpl',
          builder: (context, params) => const NestedcmplWidget(),
        ),
        FFRoute(
          name: 'Nestedcmpl2',
          path: '/nestedcmpl2',
          builder: (context, params) => const Nestedcmpl2Widget(),
        ),
        FFRoute(
          name: 'timechoose4',
          path: '/timechoose4',
          builder: (context, params) => const Timechoose4Widget(),
        ),
        FFRoute(
          name: 'reccmpl1',
          path: '/reccmpl1',
          builder: (context, params) => const Reccmpl1Widget(),
        ),
        FFRoute(
          name: 'reccmpl2',
          path: '/reccmpl2',
          builder: (context, params) => const Reccmpl2Widget(),
        ),
        FFRoute(
          name: 'reccmpl3',
          path: '/reccmpl3',
          builder: (context, params) => const Reccmpl3Widget(),
        ),
        FFRoute(
          name: 'Arrays',
          path: '/arrays',
          builder: (context, params) => const ArraysWidget(),
        ),
        FFRoute(
          name: 'Minstepsinfinitegrid',
          path: '/minstepsinfinitegrid',
          builder: (context, params) => const MinstepsinfinitegridWidget(),
        ),
        FFRoute(
          name: 'minmumlighttoactivate',
          path: '/minmumlighttoactivate',
          builder: (context, params) => const MinmumlighttoactivateWidget(),
        ),
        FFRoute(
          name: 'maximumsumtripet',
          path: '/maximumsumtripet',
          builder: (context, params) => const MaximumsumtripetWidget(),
        ),
        FFRoute(
          name: 'maxsumcontiunoussubarray',
          path: '/maxsumcontiunoussubarray',
          builder: (context, params) => const MaxsumcontiunoussubarrayWidget(),
        ),
        FFRoute(
          name: 'addonetonumber',
          path: '/addonetonumber',
          builder: (context, params) => const AddonetonumberWidget(),
        ),
        FFRoute(
          name: 'maximumabsolutedifference',
          path: '/maximumabsolutedifference',
          builder: (context, params) => const MaximumabsolutedifferenceWidget(),
        ),
        FFRoute(
          name: 'maximumareaoftriangle',
          path: '/maximumareaoftriangle',
          builder: (context, params) => const MaximumareaoftriangleWidget(),
        ),
        FFRoute(
          name: 'flip',
          path: '/flip',
          builder: (context, params) => const FlipWidget(),
        ),
        FFRoute(
          name: 'maxmin',
          path: '/maxmin',
          builder: (context, params) => const MaxminWidget(),
        ),
        FFRoute(
          name: 'mergeintervals',
          path: '/mergeintervals',
          builder: (context, params) => const MergeintervalsWidget(),
        ),
        FFRoute(
          name: 'mergeoverlappintervals',
          path: '/mergeoverlappintervals',
          builder: (context, params) => const MergeoverlappintervalsWidget(),
        ),
        FFRoute(
          name: 'movezeroes',
          path: '/movezeroes',
          builder: (context, params) => const MovezeroesWidget(),
        ),
        FFRoute(
          name: 'arraysum',
          path: '/arraysum',
          builder: (context, params) => const ArraysumWidget(),
        ),
        FFRoute(
          name: 'kthrowofpascaltriangle',
          path: '/kthrowofpascaltriangle',
          builder: (context, params) => const KthrowofpascaltriangleWidget(),
        ),
        FFRoute(
          name: 'spiralordermatrix',
          path: '/spiralordermatrix',
          builder: (context, params) => const SpiralordermatrixWidget(),
        ),
        FFRoute(
          name: 'pascaltriangle',
          path: '/pascaltriangle',
          builder: (context, params) => const PascaltriangleWidget(),
        ),
        FFRoute(
          name: 'antidiagonal',
          path: '/antidiagonal',
          builder: (context, params) => const AntidiagonalWidget(),
        ),
        FFRoute(
          name: 'findduplicatesinaarray',
          path: '/findduplicatesinaarray',
          builder: (context, params) => const FindduplicatesinaarrayWidget(),
        ),
        FFRoute(
          name: 'largestnumber',
          path: '/largestnumber',
          builder: (context, params) => const LargestnumberWidget(),
        ),
        FFRoute(
          name: 'rotatematrix',
          path: '/rotatematrix',
          builder: (context, params) => const RotatematrixWidget(),
        ),
        FFRoute(
          name: 'nextpermuatation',
          path: '/nextpermuatation',
          builder: (context, params) => const NextpermuatationWidget(),
        ),
        FFRoute(
          name: 'findpermuatation',
          path: '/findpermuatation',
          builder: (context, params) => const FindpermuatationWidget(),
        ),
        FFRoute(
          name: 'reorderdatainlogfiles',
          path: '/reorderdatainlogfiles',
          builder: (context, params) => const ReorderdatainlogfilesWidget(),
        ),
        FFRoute(
          name: 'setintersection',
          path: '/setintersection',
          builder: (context, params) => const SetintersectionWidget(),
        ),
        FFRoute(
          name: 'wavearray',
          path: '/wavearray',
          builder: (context, params) => const WavearrayWidget(),
        ),
        FFRoute(
          name: 'hotelbookingpossible',
          path: '/hotelbookingpossible',
          builder: (context, params) => const HotelbookingpossibleWidget(),
        ),
        FFRoute(
          name: 'maxdistance',
          path: '/maxdistance',
          builder: (context, params) => const MaxdistanceWidget(),
        ),
        FFRoute(
          name: 'maximumunsorted',
          path: '/maximumunsorted',
          builder: (context, params) => const MaximumunsortedWidget(),
        ),
        FFRoute(
          name: 'setmatrixzero',
          path: '/setmatrixzero',
          builder: (context, params) => const SetmatrixzeroWidget(),
        ),
        FFRoute(
          name: 'firstmissinginteger',
          path: '/firstmissinginteger',
          builder: (context, params) => const FirstmissingintegerWidget(),
        ),
        FFRoute(
          name: 'repeatandmissingnumberarray',
          path: '/repeatandmissingnumberarray',
          builder: (context, params) => const RepeatandmissingnumberarrayWidget(),
        ),
        FFRoute(
          name: 'n3repeatnumber',
          path: '/n3repeatnumber',
          builder: (context, params) => const N3repeatnumberWidget(),
        ),
        FFRoute(
          name: 'maths',
          path: '/maths',
          builder: (context, params) => const MathsWidget(),
        ),
        FFRoute(
          name: 'sumofpairringhammingdistance',
          path: '/sumofpairringhammingdistance',
          builder: (context, params) => const SumofpairringhammingdistanceWidget(),
        ),
        FFRoute(
          name: 'powerofinteger',
          path: '/powerofinteger',
          builder: (context, params) => const PowerofintegerWidget(),
        ),
        FFRoute(
          name: 'excelcloumnnumber',
          path: '/excelcloumnnumber',
          builder: (context, params) => const ExcelcloumnnumberWidget(),
        ),
        FFRoute(
          name: 'excelcolumntitle',
          path: '/excelcolumntitle',
          builder: (context, params) => const ExcelcolumntitleWidget(),
        ),
        FFRoute(
          name: 'nextsmallestpalindrome',
          path: '/nextsmallestpalindrome',
          builder: (context, params) => const NextsmallestpalindromeWidget(),
        ),
        FFRoute(
          name: 'greastestcommondivisor',
          path: '/greastestcommondivisor',
          builder: (context, params) => const GreastestcommondivisorWidget(),
        ),
        FFRoute(
          name: 'findnthfibonnaci',
          path: '/findnthfibonnaci',
          builder: (context, params) => const FindnthfibonnaciWidget(),
        ),
        FFRoute(
          name: 'divisibleby60',
          path: '/divisibleby60',
          builder: (context, params) => const Divisibleby60Widget(),
        ),
        FFRoute(
          name: 'trailingzerosinfactorial',
          path: '/trailingzerosinfactorial',
          builder: (context, params) => const TrailingzerosinfactorialWidget(),
        ),
        FFRoute(
          name: 'soretedpermutationrank',
          path: '/soretedpermutationrank',
          builder: (context, params) => const SoretedpermutationrankWidget(),
        ),
        FFRoute(
          name: 'sortedpermuatationwithrepeats',
          path: '/sortedpermuatationwithrepeats',
          builder: (context, params) => const SortedpermuatationwithrepeatsWidget(),
        ),
        FFRoute(
          name: 'kthpermutation',
          path: '/kthpermutation',
          builder: (context, params) => const KthpermutationWidget(),
        ),
        FFRoute(
          name: 'griduniquepath',
          path: '/griduniquepath',
          builder: (context, params) => const GriduniquepathWidget(),
        ),
        FFRoute(
          name: 'additionwithoutsummation',
          path: '/additionwithoutsummation',
          builder: (context, params) => const AdditionwithoutsummationWidget(),
        ),
        FFRoute(
          name: 'nextsimilarnumber',
          path: '/nextsimilarnumber',
          builder: (context, params) => const NextsimilarnumberWidget(),
        ),
        FFRoute(
          name: 'rearrangearray',
          path: '/rearrangearray',
          builder: (context, params) => const RearrangearrayWidget(),
        ),
        FFRoute(
          name: 'binarysearch',
          path: '/binarysearch',
          builder: (context, params) => const BinarysearchWidget(),
        ),
        FFRoute(
          name: 'woodcuttingmadeeasy',
          path: '/woodcuttingmadeeasy',
          builder: (context, params) => const WoodcuttingmadeeasyWidget(),
        ),
        FFRoute(
          name: 'matrixsearch',
          path: '/matrixsearch',
          builder: (context, params) => const MatrixsearchWidget(),
        ),
        FFRoute(
          name: 'searchforrange',
          path: '/searchforrange',
          builder: (context, params) => const SearchforrangeWidget(),
        ),
        FFRoute(
          name: 'sortedinsertposition',
          path: '/sortedinsertposition',
          builder: (context, params) => const SortedinsertpositionWidget(),
        ),
        FFRoute(
          name: 'capacitytoshipinbdays',
          path: '/capacitytoshipinbdays',
          builder: (context, params) => const CapacitytoshipinbdaysWidget(),
        ),
        FFRoute(
          name: 'matrixmedian',
          path: '/matrixmedian',
          builder: (context, params) => const MatrixmedianWidget(),
        ),
        FFRoute(
          name: 'squarerootofinteger',
          path: '/squarerootofinteger',
          builder: (context, params) => const SquarerootofintegerWidget(),
        ),
        FFRoute(
          name: 'allocatebooks',
          path: '/allocatebooks',
          builder: (context, params) => const AllocatebooksWidget(),
        ),
        FFRoute(
          name: 'painterpartition',
          path: '/painterpartition',
          builder: (context, params) => const PainterpartitionWidget(),
        ),
        FFRoute(
          name: 'implementpowerfunction',
          path: '/implementpowerfunction',
          builder: (context, params) => const ImplementpowerfunctionWidget(),
        ),
        FFRoute(
          name: 'medianoferror',
          path: '/medianoferror',
          builder: (context, params) => const MedianoferrorWidget(),
        ),
        FFRoute(
          name: 'rotatedsortarray',
          path: '/rotatedsortarray',
          builder: (context, params) => const RotatedsortarrayWidget(),
        ),
        FFRoute(
          name: 'bitmanipulation',
          path: '/bitmanipulation',
          builder: (context, params) => const BitmanipulationWidget(),
        ),
        FFRoute(
          name: 'numberof1bits',
          path: '/numberof1bits',
          builder: (context, params) => const Numberof1bitsWidget(),
        ),
        FFRoute(
          name: 'reversebits',
          path: '/reversebits',
          builder: (context, params) => const ReversebitsWidget(),
        ),
        FFRoute(
          name: 'divideinteger',
          path: '/divideinteger',
          builder: (context, params) => const DivideintegerWidget(),
        ),
        FFRoute(
          name: 'differentbitssumpairwise',
          path: '/differentbitssumpairwise',
          builder: (context, params) => const DifferentbitssumpairwiseWidget(),
        ),
        FFRoute(
          name: 'counttotalsetbits',
          path: '/counttotalsetbits',
          builder: (context, params) => const CounttotalsetbitsWidget(),
        ),
        FFRoute(
          name: 'palindromebinaryrepresentation',
          path: '/palindromebinaryrepresentation',
          builder: (context, params) => const PalindromebinaryrepresentationWidget(),
        ),
        FFRoute(
          name: 'xorigthesubarray',
          path: '/xorigthesubarray',
          builder: (context, params) => const XorigthesubarrayWidget(),
        ),
        FFRoute(
          name: 'singlenumber',
          path: '/singlenumber',
          builder: (context, params) => const SinglenumberWidget(),
        ),
        FFRoute(
          name: 'singlenumber2',
          path: '/singlenumber2',
          builder: (context, params) => const Singlenumber2Widget(),
        ),
        FFRoute(
          name: 'strings',
          path: '/strings',
          builder: (context, params) => const StringsWidget(),
        ),
        FFRoute(
          name: 'seralize',
          path: '/seralize',
          builder: (context, params) => const SeralizeWidget(),
        ),
        FFRoute(
          name: 'deserialize',
          path: '/deserialize',
          builder: (context, params) => const DeserializeWidget(),
        ),
        FFRoute(
          name: 'bullsandcows',
          path: '/bullsandcows',
          builder: (context, params) => const BullsandcowsWidget(),
        ),
        FFRoute(
          name: 'longestcommonprefix',
          path: '/longestcommonprefix',
          builder: (context, params) => const LongestcommonprefixWidget(),
        ),
        FFRoute(
          name: 'countandsay',
          path: '/countandsay',
          builder: (context, params) => const CountandsayWidget(),
        ),
        FFRoute(
          name: 'implementstrstr',
          path: '/implementstrstr',
          builder: (context, params) => const ImplementstrstrWidget(),
        ),
        FFRoute(
          name: 'minimumcharacterrequiredtomake',
          path: '/minimumcharacterrequiredtomake',
          builder: (context, params) => const MinimumcharacterrequiredtomakeWidget(),
        ),
        FFRoute(
          name: 'converttopalindrome',
          path: '/converttopalindrome',
          builder: (context, params) => const ConverttopalindromeWidget(),
        ),
        FFRoute(
          name: 'minimumappendsforpalindrome',
          path: '/minimumappendsforpalindrome',
          builder: (context, params) => const MinimumappendsforpalindromeWidget(),
        ),
        FFRoute(
          name: 'minimumparantheses',
          path: '/minimumparantheses',
          builder: (context, params) => const MinimumparanthesesWidget(),
        ),
        FFRoute(
          name: 'longestpalindromesubstring',
          path: '/longestpalindromesubstring',
          builder: (context, params) => const LongestpalindromesubstringWidget(),
        ),
        FFRoute(
          name: 'integertoroman',
          path: '/integertoroman',
          builder: (context, params) => const IntegertoromanWidget(),
        ),
        FFRoute(
          name: 'romantointeger',
          path: '/romantointeger',
          builder: (context, params) => const RomantointegerWidget(),
        ),
        FFRoute(
          name: 'addbinarystrings',
          path: '/addbinarystrings',
          builder: (context, params) => const AddbinarystringsWidget(),
        ),
        FFRoute(
          name: 'powerof2',
          path: '/powerof2',
          builder: (context, params) => const Powerof2Widget(),
        ),
        FFRoute(
          name: 'multiplystrings',
          path: '/multiplystrings',
          builder: (context, params) => const MultiplystringsWidget(),
        ),
        FFRoute(
          name: 'converttheamountinumberstowords',
          path: '/converttheamountinumberstowords',
          builder: (context, params) => const ConverttheamountinumberstowordsWidget(),
        ),
        FFRoute(
          name: 'compareversionnumbers',
          path: '/compareversionnumbers',
          builder: (context, params) => const CompareversionnumbersWidget(),
        ),
        FFRoute(
          name: 'atoi',
          path: '/atoi',
          builder: (context, params) => const AtoiWidget(),
        ),
        FFRoute(
          name: 'validipaddress',
          path: '/validipaddress',
          builder: (context, params) => const ValidipaddressWidget(),
        ),
        FFRoute(
          name: 'twopointer',
          path: '/twopointer',
          builder: (context, params) => const TwopointerWidget(),
        ),
        FFRoute(
          name: 'pairwithgivendifference',
          path: '/pairwithgivendifference',
          builder: (context, params) => const PairwithgivendifferenceWidget(),
        ),
        FFRoute(
          name: 'sum3',
          path: '/sum3',
          builder: (context, params) => const Sum3Widget(),
        ),
        FFRoute(
          name: 'diffk',
          path: '/diffk',
          builder: (context, params) => const DiffkWidget(),
        ),
        FFRoute(
          name: 'maximumonesaftermodification',
          path: '/maximumonesaftermodification',
          builder: (context, params) => const MaximumonesaftermodificationWidget(),
        ),
        FFRoute(
          name: 'countingsubarrays',
          path: '/countingsubarrays',
          builder: (context, params) => const CountingsubarraysWidget(),
        ),
        FFRoute(
          name: 'subarraywithdistinctinteger',
          path: '/subarraywithdistinctinteger',
          builder: (context, params) => const SubarraywithdistinctintegerWidget(),
        ),
        FFRoute(
          name: 'maxcontiunousseriesof1s',
          path: '/maxcontiunousseriesof1s',
          builder: (context, params) => const Maxcontiunousseriesof1sWidget(),
        ),
        FFRoute(
          name: 'array3pointer',
          path: '/array3pointer',
          builder: (context, params) => const Array3pointerWidget(),
        ),
        FFRoute(
          name: 'cointerwithmostwater',
          path: '/cointerwithmostwater',
          builder: (context, params) => const CointerwithmostwaterWidget(),
        ),
        FFRoute(
          name: 'mergetwosortedlists2',
          path: '/mergetwosortedlists2',
          builder: (context, params) => const Mergetwosortedlists2Widget(),
        ),
        FFRoute(
          name: 'intersectionofsortedarray',
          path: '/intersectionofsortedarray',
          builder: (context, params) => const IntersectionofsortedarrayWidget(),
        ),
        FFRoute(
          name: 'removeduplicatefromsortedarray',
          path: '/removeduplicatefromsortedarray',
          builder: (context, params) => const RemoveduplicatefromsortedarrayWidget(),
        ),
        FFRoute(
          name: 'removeduplicatefromsortedarray2',
          path: '/removeduplicatefromsortedarray2',
          builder: (context, params) => const Removeduplicatefromsortedarray2Widget(),
        ),
        FFRoute(
          name: 'removeelementfromarray',
          path: '/removeelementfromarray',
          builder: (context, params) => const RemoveelementfromarrayWidget(),
        ),
        FFRoute(
          name: 'sortbycolor',
          path: '/sortbycolor',
          builder: (context, params) => const SortbycolorWidget(),
        ),
        FFRoute(
          name: 'linkedlist',
          path: '/linkedlist',
          builder: (context, params) => const LinkedlistWidget(),
        ),
        FFRoute(
          name: 'sortbinarylinkedlist',
          path: '/sortbinarylinkedlist',
          builder: (context, params) => const SortbinarylinkedlistWidget(),
        ),
        FFRoute(
          name: 'partitionlist',
          path: '/partitionlist',
          builder: (context, params) => const PartitionlistWidget(),
        ),
        FFRoute(
          name: 'insertionsortlist',
          path: '/insertionsortlist',
          builder: (context, params) => const InsertionsortlistWidget(),
        ),
        FFRoute(
          name: 'sortlist',
          path: '/sortlist',
          builder: (context, params) => const SortlistWidget(),
        ),
        FFRoute(
          name: 'palindromelist',
          path: '/palindromelist',
          builder: (context, params) => const PalindromelistWidget(),
        ),
        FFRoute(
          name: 'removeduplicatefromsortedlist2',
          path: '/removeduplicatefromsortedlist2',
          builder: (context, params) => const Removeduplicatefromsortedlist2Widget(),
        ),
        FFRoute(
          name: 'mergetwosortedlists',
          path: '/mergetwosortedlists',
          builder: (context, params) => const MergetwosortedlistsWidget(),
        ),
        FFRoute(
          name: 'removedupulicatefromsortedlist',
          path: '/removedupulicatefromsortedlist',
          builder: (context, params) => const RemovedupulicatefromsortedlistWidget(),
        ),
        FFRoute(
          name: 'removenthnodefromlistend',
          path: '/removenthnodefromlistend',
          builder: (context, params) => const RemoventhnodefromlistendWidget(),
        ),
        FFRoute(
          name: 'kreverselinkedlist',
          path: '/kreverselinkedlist',
          builder: (context, params) => const KreverselinkedlistWidget(),
        ),
        FFRoute(
          name: 'evenreverse',
          path: '/evenreverse',
          builder: (context, params) => const EvenreverseWidget(),
        ),
        FFRoute(
          name: 'swaplistnodesinpairs',
          path: '/swaplistnodesinpairs',
          builder: (context, params) => const SwaplistnodesinpairsWidget(),
        ),
        FFRoute(
          name: 'rotatelist',
          path: '/rotatelist',
          builder: (context, params) => const RotatelistWidget(),
        ),
        FFRoute(
          name: 'kthnodefrommiddle',
          path: '/kthnodefrommiddle',
          builder: (context, params) => const KthnodefrommiddleWidget(),
        ),
        FFRoute(
          name: 'reversealternateknodes',
          path: '/reversealternateknodes',
          builder: (context, params) => const ReversealternateknodesWidget(),
        ),
        FFRoute(
          name: 'reverselinklist2',
          path: '/reverselinklist2',
          builder: (context, params) => const Reverselinklist2Widget(),
        ),
        FFRoute(
          name: 'reorderlist',
          path: '/reorderlist',
          builder: (context, params) => const ReorderlistWidget(),
        ),
        FFRoute(
          name: 'addtwonumbersaslists',
          path: '/addtwonumbersaslists',
          builder: (context, params) => const AddtwonumbersaslistsWidget(),
        ),
        FFRoute(
          name: 'listcycle',
          path: '/listcycle',
          builder: (context, params) => const ListcycleWidget(),
        ),
        FFRoute(
          name: 'longestpalindromesubsequence',
          path: '/longestpalindromesubsequence',
          builder: (context, params) => const LongestpalindromesubsequenceWidget(),
        ),
        FFRoute(
          name: 'editdistance',
          path: '/editdistance',
          builder: (context, params) => const EditdistanceWidget(),
        ),
        FFRoute(
          name: 'stacksandqueues',
          path: '/stacksandqueues',
          builder: (context, params) => const StacksandqueuesWidget(),
        ),
        FFRoute(
          name: 'balancedparanthesis',
          path: '/balancedparanthesis',
          builder: (context, params) => const BalancedparanthesisWidget(),
        ),
        FFRoute(
          name: 'simplifydirectorypath',
          path: '/simplifydirectorypath',
          builder: (context, params) => const SimplifydirectorypathWidget(),
        ),
        FFRoute(
          name: 'redundantbraces',
          path: '/redundantbraces',
          builder: (context, params) => const RedundantbracesWidget(),
        ),
        FFRoute(
          name: 'minstack',
          path: '/minstack',
          builder: (context, params) => const MinstackWidget(),
        ),
        FFRoute(
          name: 'nearestsmallerelement',
          path: '/nearestsmallerelement',
          builder: (context, params) => const NearestsmallerelementWidget(),
        ),
        FFRoute(
          name: 'largestrectangleinhistogram',
          path: '/largestrectangleinhistogram',
          builder: (context, params) => const LargestrectangleinhistogramWidget(),
        ),
        FFRoute(
          name: 'firstnonrepeatingchararcterinastreamofcharacter',
          path: '/firstnonrepeatingchararcterinastreamofcharacter',
          builder: (context, params) =>
              const FirstnonrepeatingchararcterinastreamofcharacterWidget(),
        ),
        FFRoute(
          name: 'slidingwindowmaximum',
          path: '/slidingwindowmaximum',
          builder: (context, params) => const SlidingwindowmaximumWidget(),
        ),
        FFRoute(
          name: 'evaluateexpression',
          path: '/evaluateexpression',
          builder: (context, params) => const EvaluateexpressionWidget(),
        ),
        FFRoute(
          name: 'rainwatertrapped',
          path: '/rainwatertrapped',
          builder: (context, params) => const RainwatertrappedWidget(),
        ),
        FFRoute(
          name: 'backtracking',
          path: '/backtracking',
          builder: (context, params) => const BacktrackingWidget(),
        ),
        FFRoute(
          name: 'subset',
          path: '/subset',
          builder: (context, params) => const SubsetWidget(),
        ),
        FFRoute(
          name: 'combinationsum',
          path: '/combinationsum',
          builder: (context, params) => const CombinationsumWidget(),
        ),
        FFRoute(
          name: 'combinationsum2',
          path: '/combinationsum2',
          builder: (context, params) => const Combinationsum2Widget(),
        ),
        FFRoute(
          name: 'combinations',
          path: '/combinations',
          builder: (context, params) => const CombinationsWidget(),
        ),
        FFRoute(
          name: 'subset2',
          path: '/subset2',
          builder: (context, params) => const Subset2Widget(),
        ),
        FFRoute(
          name: 'maximalstring',
          path: '/maximalstring',
          builder: (context, params) => const MaximalstringWidget(),
        ),
        FFRoute(
          name: 'kthpermuatationsequence',
          path: '/kthpermuatationsequence',
          builder: (context, params) => const KthpermuatationsequenceWidget(),
        ),
        FFRoute(
          name: 'graycode',
          path: '/graycode',
          builder: (context, params) => const GraycodeWidget(),
        ),
        FFRoute(
          name: 'letterphone',
          path: '/letterphone',
          builder: (context, params) => const LetterphoneWidget(),
        ),
        FFRoute(
          name: 'palindromepartitioning',
          path: '/palindromepartitioning',
          builder: (context, params) => const PalindromepartitioningWidget(),
        ),
        FFRoute(
          name: 'generateallparentheses2',
          path: '/generateallparentheses2',
          builder: (context, params) => const Generateallparentheses2Widget(),
        ),
        FFRoute(
          name: 'permutations',
          path: '/permutations',
          builder: (context, params) => const PermutationsWidget(),
        ),
        FFRoute(
          name: 'nqueens',
          path: '/nqueens',
          builder: (context, params) => const NqueensWidget(),
        ),
        FFRoute(
          name: 'sudoku',
          path: '/sudoku',
          builder: (context, params) => const SudokuWidget(),
        ),
        FFRoute(
          name: 'hashing',
          path: '/hashing',
          builder: (context, params) => const HashingWidget(),
        ),
        FFRoute(
          name: 'largestcontiuoussequencezerosum',
          path: '/largestcontiuoussequencezerosum',
          builder: (context, params) => const LargestcontiuoussequencezerosumWidget(),
        ),
        FFRoute(
          name: 'sum2',
          path: '/sum2',
          builder: (context, params) => const Sum2Widget(),
        ),
        FFRoute(
          name: 'sum4',
          path: '/sum4',
          builder: (context, params) => const Sum4Widget(),
        ),
        FFRoute(
          name: 'validsudoku',
          path: '/validsudoku',
          builder: (context, params) => const ValidsudokuWidget(),
        ),
        FFRoute(
          name: 'difffk2',
          path: '/difffk2',
          builder: (context, params) => const Difffk2Widget(),
        ),
        FFRoute(
          name: 'pairswithgivenxor',
          path: '/pairswithgivenxor',
          builder: (context, params) => const PairswithgivenxorWidget(),
        ),
        FFRoute(
          name: 'anagrams',
          path: '/anagrams',
          builder: (context, params) => const AnagramsWidget(),
        ),
        FFRoute(
          name: 'equal',
          path: '/equal',
          builder: (context, params) => const EqualWidget(),
        ),
        FFRoute(
          name: 'copylist',
          path: '/copylist',
          builder: (context, params) => const CopylistWidget(),
        ),
        FFRoute(
          name: 'fraction',
          path: '/fraction',
          builder: (context, params) => const FractionWidget(),
        ),
        FFRoute(
          name: 'pointsonthestraightline',
          path: '/pointsonthestraightline',
          builder: (context, params) => const PointsonthestraightlineWidget(),
        ),
        FFRoute(
          name: 'anincrementproblem',
          path: '/anincrementproblem',
          builder: (context, params) => const AnincrementproblemWidget(),
        ),
        FFRoute(
          name: 'substringconcatenation',
          path: '/substringconcatenation',
          builder: (context, params) => const SubstringconcatenationWidget(),
        ),
        FFRoute(
          name: 'windowstring',
          path: '/windowstring',
          builder: (context, params) => const WindowstringWidget(),
        ),
        FFRoute(
          name: 'longestsubstringwithoutrepeat',
          path: '/longestsubstringwithoutrepeat',
          builder: (context, params) => const LongestsubstringwithoutrepeatWidget(),
        ),
        FFRoute(
          name: 'heapsnadmaps',
          path: '/heapsnadmaps',
          builder: (context, params) => const HeapsnadmapsWidget(),
        ),
        FFRoute(
          name: 'waystoformmaxheap',
          path: '/waystoformmaxheap',
          builder: (context, params) => const WaystoformmaxheapWidget(),
        ),
        FFRoute(
          name: 'klargestelements',
          path: '/klargestelements',
          builder: (context, params) => const KlargestelementsWidget(),
        ),
        FFRoute(
          name: 'maximumsumcombinations',
          path: '/maximumsumcombinations',
          builder: (context, params) => const MaximumsumcombinationsWidget(),
        ),
        FFRoute(
          name: 'mergeksortedlists',
          path: '/mergeksortedlists',
          builder: (context, params) => const MergeksortedlistsWidget(),
        ),
        FFRoute(
          name: 'distinctnumbersinwindow',
          path: '/distinctnumbersinwindow',
          builder: (context, params) => const DistinctnumbersinwindowWidget(),
        ),
        FFRoute(
          name: 'lrucache',
          path: '/lrucache',
          builder: (context, params) => const LrucacheWidget(),
        ),
        FFRoute(
          name: 'treesdsa',
          path: '/treesdsa',
          builder: (context, params) => const TreesdsaWidget(),
        ),
        FFRoute(
          name: 'validbstfrompreorder',
          path: '/validbstfrompreorder',
          builder: (context, params) => const ValidbstfrompreorderWidget(),
        ),
        FFRoute(
          name: 'kthsmallestelemetintree',
          path: '/kthsmallestelemetintree',
          builder: (context, params) => const KthsmallestelemetintreeWidget(),
        ),
        FFRoute(
          name: 'sumbinarytree2',
          path: '/sumbinarytree2',
          builder: (context, params) => const Sumbinarytree2Widget(),
        ),
        FFRoute(
          name: 'bstiterator',
          path: '/bstiterator',
          builder: (context, params) => const BstiteratorWidget(),
        ),
        FFRoute(
          name: 'recoverybinarysearchtree',
          path: '/recoverybinarysearchtree',
          builder: (context, params) => const RecoverybinarysearchtreeWidget(),
        ),
        FFRoute(
          name: 'hotelreviews',
          path: '/hotelreviews',
          builder: (context, params) => const HotelreviewsWidget(),
        ),
        FFRoute(
          name: 'shortestuniqueprefix',
          path: '/shortestuniqueprefix',
          builder: (context, params) => const ShortestuniqueprefixWidget(),
        ),
        FFRoute(
          name: 'pathtogivennode',
          path: '/pathtogivennode',
          builder: (context, params) => const PathtogivennodeWidget(),
        ),
        FFRoute(
          name: 'removehalfnodes',
          path: '/removehalfnodes',
          builder: (context, params) => const RemovehalfnodesWidget(),
        ),
        FFRoute(
          name: 'nodesatdistancek',
          path: '/nodesatdistancek',
          builder: (context, params) => const NodesatdistancekWidget(),
        ),
        FFRoute(
          name: 'lastnodeinacompletebinarytree',
          path: '/lastnodeinacompletebinarytree',
          builder: (context, params) => const LastnodeinacompletebinarytreeWidget(),
        ),
        FFRoute(
          name: 'balancedbinarytree',
          path: '/balancedbinarytree',
          builder: (context, params) => const BalancedbinarytreeWidget(),
        ),
        FFRoute(
          name: 'mergetwobinarytree',
          path: '/mergetwobinarytree',
          builder: (context, params) => const MergetwobinarytreeWidget(),
        ),
        FFRoute(
          name: 'symmetricbinarytree',
          path: '/symmetricbinarytree',
          builder: (context, params) => const SymmetricbinarytreeWidget(),
        ),
        FFRoute(
          name: 'identicalbinarytrees',
          path: '/identicalbinarytrees',
          builder: (context, params) => const IdenticalbinarytreesWidget(),
        ),
        FFRoute(
          name: 'inordertransversalofcartesiantree',
          path: '/inordertransversalofcartesiantree',
          builder: (context, params) =>
              const InordertransversalofcartesiantreeWidget(),
        ),
        FFRoute(
          name: 'sortedarraytobalancedbst',
          path: '/sortedarraytobalancedbst',
          builder: (context, params) => const SortedarraytobalancedbstWidget(),
        ),
        FFRoute(
          name: 'constructbinarytreefrominorderandpreorder',
          path: '/constructbinarytreefrominorderandpreorder',
          builder: (context, params) =>
              const ConstructbinarytreefrominorderandpreorderWidget(),
        ),
        FFRoute(
          name: 'binarytreefrominorderandpostorder',
          path: '/binarytreefrominorderandpostorder',
          builder: (context, params) =>
              const BinarytreefrominorderandpostorderWidget(),
        ),
        FFRoute(
          name: 'verticalordertransversalofbinarytree',
          path: '/verticalordertransversalofbinarytree',
          builder: (context, params) =>
              const VerticalordertransversalofbinarytreeWidget(),
        ),
        FFRoute(
          name: 'diagonaltransversal',
          path: '/diagonaltransversal',
          builder: (context, params) => const DiagonaltransversalWidget(),
        ),
        FFRoute(
          name: 'verticalsumofabinarytree',
          path: '/verticalsumofabinarytree',
          builder: (context, params) => const VerticalsumofabinarytreeWidget(),
        ),
        FFRoute(
          name: 'covereduncoverednodes',
          path: '/covereduncoverednodes',
          builder: (context, params) => const CovereduncoverednodesWidget(),
        ),
        FFRoute(
          name: 'inordertransversal',
          path: '/inordertransversal',
          builder: (context, params) => const InordertransversalWidget(),
        ),
        FFRoute(
          name: 'preordertransversal',
          path: '/preordertransversal',
          builder: (context, params) => const PreordertransversalWidget(),
        ),
        FFRoute(
          name: 'postordertransversal',
          path: '/postordertransversal',
          builder: (context, params) => const PostordertransversalWidget(),
        ),
        FFRoute(
          name: 'cousinsinbinarytree',
          path: '/cousinsinbinarytree',
          builder: (context, params) => const CousinsinbinarytreeWidget(),
        ),
        FFRoute(
          name: 'zigzaglevelordertransersalbt',
          path: '/zigzaglevelordertransersalbt',
          builder: (context, params) => const ZigzaglevelordertransersalbtWidget(),
        ),
        FFRoute(
          name: 'populatenextrightpointertree',
          path: '/populatenextrightpointertree',
          builder: (context, params) => const PopulatenextrightpointertreeWidget(),
        ),
        FFRoute(
          name: 'burnatree',
          path: '/burnatree',
          builder: (context, params) => const BurnatreeWidget(),
        ),
        FFRoute(
          name: 'maxdepthofbinarytree',
          path: '/maxdepthofbinarytree',
          builder: (context, params) => const MaxdepthofbinarytreeWidget(),
        ),
        FFRoute(
          name: 'sumroottoleafnumbers',
          path: '/sumroottoleafnumbers',
          builder: (context, params) => const SumroottoleafnumbersWidget(),
        ),
        FFRoute(
          name: 'pathsum',
          path: '/pathsum',
          builder: (context, params) => const PathsumWidget(),
        ),
        FFRoute(
          name: 'mindepthofbinarytree',
          path: '/mindepthofbinarytree',
          builder: (context, params) => const MindepthofbinarytreeWidget(),
        ),
        FFRoute(
          name: 'roottoleafpathswithsum',
          path: '/roottoleafpathswithsum',
          builder: (context, params) => const RoottoleafpathswithsumWidget(),
        ),
        FFRoute(
          name: 'invertthebinarytree',
          path: '/invertthebinarytree',
          builder: (context, params) => const InvertthebinarytreeWidget(),
        ),
        FFRoute(
          name: 'leastcommonancestor',
          path: '/leastcommonancestor',
          builder: (context, params) => const LeastcommonancestorWidget(),
        ),
        FFRoute(
          name: 'flatenbinarytreetobinarytree',
          path: '/flatenbinarytreetobinarytree',
          builder: (context, params) => const FlatenbinarytreetobinarytreeWidget(),
        ),
        FFRoute(
          name: 'orderofpeopleheights',
          path: '/orderofpeopleheights',
          builder: (context, params) => const OrderofpeopleheightsWidget(),
        ),
        FFRoute(
          name: 'dynamicsprogramming',
          path: '/dynamicsprogramming',
          builder: (context, params) => const DynamicsprogrammingWidget(),
        ),
        FFRoute(
          name: 'repreatingsubsequence',
          path: '/repreatingsubsequence',
          builder: (context, params) => const RepreatingsubsequenceWidget(),
        ),
        FFRoute(
          name: 'distinctsubsequence',
          path: '/distinctsubsequence',
          builder: (context, params) => const DistinctsubsequenceWidget(),
        ),
        FFRoute(
          name: 'regularexpressionmatch',
          path: '/regularexpressionmatch',
          builder: (context, params) => const RegularexpressionmatchWidget(),
        ),
        FFRoute(
          name: 'regularexpression2',
          path: '/regularexpression2',
          builder: (context, params) => const Regularexpression2Widget(),
        ),
        FFRoute(
          name: 'interleavingstrings',
          path: '/interleavingstrings',
          builder: (context, params) => const InterleavingstringsWidget(),
        ),
        FFRoute(
          name: 'lengthoflongestsubsequence',
          path: '/lengthoflongestsubsequence',
          builder: (context, params) => const LengthoflongestsubsequenceWidget(),
        ),
        FFRoute(
          name: 'smallestsequencewithgivenprimes',
          path: '/smallestsequencewithgivenprimes',
          builder: (context, params) => const SmallestsequencewithgivenprimesWidget(),
        ),
        FFRoute(
          name: 'largestareaofrectangle',
          path: '/largestareaofrectangle',
          builder: (context, params) => const LargestareaofrectangleWidget(),
        ),
        FFRoute(
          name: 'tillingwithdominoes',
          path: '/tillingwithdominoes',
          builder: (context, params) => const TillingwithdominoesWidget(),
        ),
        FFRoute(
          name: 'painthouse',
          path: '/painthouse',
          builder: (context, params) => const PainthouseWidget(),
        ),
        FFRoute(
          name: 'waystodecode',
          path: '/waystodecode',
          builder: (context, params) => const WaystodecodeWidget(),
        ),
        FFRoute(
          name: 'stairs',
          path: '/stairs',
          builder: (context, params) => const StairsWidget(),
        ),
        FFRoute(
          name: 'longestincreasingsubsequence',
          path: '/longestincreasingsubsequence',
          builder: (context, params) => const LongestincreasingsubsequenceWidget(),
        ),
        FFRoute(
          name: 'intersectingchordsinacircle',
          path: '/intersectingchordsinacircle',
          builder: (context, params) => const IntersectingchordsinacircleWidget(),
        ),
        FFRoute(
          name: 'jumpgamearray',
          path: '/jumpgamearray',
          builder: (context, params) => const JumpgamearrayWidget(),
        ),
        FFRoute(
          name: 'minjumparray',
          path: '/minjumparray',
          builder: (context, params) => const MinjumparrayWidget(),
        ),
        FFRoute(
          name: 'longestarithemicprogession',
          path: '/longestarithemicprogession',
          builder: (context, params) => const LongestarithemicprogessionWidget(),
        ),
        FFRoute(
          name: 'shortestcommonsuperstring',
          path: '/shortestcommonsuperstring',
          builder: (context, params) => const ShortestcommonsuperstringWidget(),
        ),
        FFRoute(
          name: 'waystocolor3nboard',
          path: '/waystocolor3nboard',
          builder: (context, params) => const Waystocolor3nboardWidget(),
        ),
        FFRoute(
          name: 'evaluateexpressiontotrue',
          path: '/evaluateexpressiontotrue',
          builder: (context, params) => const EvaluateexpressiontotrueWidget(),
        ),
        FFRoute(
          name: 'besttimetobuyandsellstocks3',
          path: '/besttimetobuyandsellstocks3',
          builder: (context, params) => const Besttimetobuyandsellstocks3Widget(),
        ),
        FFRoute(
          name: 'longestvalidparentheses',
          path: '/longestvalidparentheses',
          builder: (context, params) => const LongestvalidparenthesesWidget(),
        ),
        FFRoute(
          name: 'maxsumpathinbinarytree',
          path: '/maxsumpathinbinarytree',
          builder: (context, params) => const MaxsumpathinbinarytreeWidget(),
        ),
        FFRoute(
          name: 'maximumpathintriangle',
          path: '/maximumpathintriangle',
          builder: (context, params) => const MaximumpathintriangleWidget(),
        ),
        FFRoute(
          name: 'maximumsizesquaresubmatrix',
          path: '/maximumsizesquaresubmatrix',
          builder: (context, params) => const MaximumsizesquaresubmatrixWidget(),
        ),
        FFRoute(
          name: 'increasingpathinmatrix',
          path: '/increasingpathinmatrix',
          builder: (context, params) => const IncreasingpathinmatrixWidget(),
        ),
        FFRoute(
          name: 'minimumdiffferencesubset',
          path: '/minimumdiffferencesubset',
          builder: (context, params) => const MinimumdiffferencesubsetWidget(),
        ),
        FFRoute(
          name: 'subsetsumproblem',
          path: '/subsetsumproblem',
          builder: (context, params) => const SubsetsumproblemWidget(),
        ),
        FFRoute(
          name: 'uniquepathsinagrid',
          path: '/uniquepathsinagrid',
          builder: (context, params) => const UniquepathsinagridWidget(),
        ),
        FFRoute(
          name: 'minsumpathinmatrix',
          path: '/minsumpathinmatrix',
          builder: (context, params) => const MinsumpathinmatrixWidget(),
        ),
        FFRoute(
          name: 'maxrectanglebinarymatrix',
          path: '/maxrectanglebinarymatrix',
          builder: (context, params) => const MaxrectanglebinarymatrixWidget(),
        ),
        FFRoute(
          name: 'rodcutting',
          path: '/rodcutting',
          builder: (context, params) => const RodcuttingWidget(),
        ),
        FFRoute(
          name: 'submatriceswithsumzero',
          path: '/submatriceswithsumzero',
          builder: (context, params) => const SubmatriceswithsumzeroWidget(),
        ),
        FFRoute(
          name: 'coinsuminfinte',
          path: '/coinsuminfinte',
          builder: (context, params) => const CoinsuminfinteWidget(),
        ),
        FFRoute(
          name: 'maxproductsubarray',
          path: '/maxproductsubarray',
          builder: (context, params) => const MaxproductsubarrayWidget(),
        ),
        FFRoute(
          name: 'besttimetobuyandsellstocks1',
          path: '/besttimetobuyandsellstocks1',
          builder: (context, params) => const Besttimetobuyandsellstocks1Widget(),
        ),
        FFRoute(
          name: 'arrange2',
          path: '/arrange2',
          builder: (context, params) => const Arrange2Widget(),
        ),
        FFRoute(
          name: 'greedyalgorithm',
          path: '/greedyalgorithm',
          builder: (context, params) => const GreedyalgorithmWidget(),
        ),
        FFRoute(
          name: 'highestproduct',
          path: '/highestproduct',
          builder: (context, params) => const HighestproductWidget(),
        ),
        FFRoute(
          name: 'disjointintervals',
          path: '/disjointintervals',
          builder: (context, params) => const DisjointintervalsWidget(),
        ),
        FFRoute(
          name: 'meetingrooms',
          path: '/meetingrooms',
          builder: (context, params) => const MeetingroomsWidget(),
        ),
        FFRoute(
          name: 'distribtecandy',
          path: '/distribtecandy',
          builder: (context, params) => const DistribtecandyWidget(),
        ),
        FFRoute(
          name: 'seats',
          path: '/seats',
          builder: (context, params) => const SeatsWidget(),
        ),
        FFRoute(
          name: 'assignmicetoholes',
          path: '/assignmicetoholes',
          builder: (context, params) => const AssignmicetoholesWidget(),
        ),
        FFRoute(
          name: 'majorityelement',
          path: '/majorityelement',
          builder: (context, params) => const MajorityelementWidget(),
        ),
        FFRoute(
          name: 'gasstation',
          path: '/gasstation',
          builder: (context, params) => const GasstationWidget(),
        ),
        FFRoute(
          name: 'grapthdatastructure',
          path: '/grapthdatastructure',
          builder: (context, params) => const GrapthdatastructureWidget(),
        ),
        FFRoute(
          name: 'pathindirectedgrapth',
          path: '/pathindirectedgrapth',
          builder: (context, params) => const PathindirectedgrapthWidget(),
        ),
        FFRoute(
          name: 'waterflow',
          path: '/waterflow',
          builder: (context, params) => const WaterflowWidget(),
        ),
        FFRoute(
          name: 'steppingnumbers',
          path: '/steppingnumbers',
          builder: (context, params) => const SteppingnumbersWidget(),
        ),
        FFRoute(
          name: 'captureregionsonboard',
          path: '/captureregionsonboard',
          builder: (context, params) => const CaptureregionsonboardWidget(),
        ),
        FFRoute(
          name: 'wordsearchboard',
          path: '/wordsearchboard',
          builder: (context, params) => const WordsearchboardWidget(),
        ),
        FFRoute(
          name: 'largestdistancebetweennodesofatree',
          path: '/largestdistancebetweennodesofatree',
          builder: (context, params) =>
              const LargestdistancebetweennodesofatreeWidget(),
        ),
        FFRoute(
          name: 'goodgraph',
          path: '/goodgraph',
          builder: (context, params) => const GoodgraphWidget(),
        ),
        FFRoute(
          name: 'cycleindirectedgraph',
          path: '/cycleindirectedgraph',
          builder: (context, params) => const CycleindirectedgraphWidget(),
        ),
        FFRoute(
          name: 'deletededge',
          path: '/deletededge',
          builder: (context, params) => const DeletededgeWidget(),
        ),
        FFRoute(
          name: 'twoteams',
          path: '/twoteams',
          builder: (context, params) => const TwoteamsWidget(),
        ),
        FFRoute(
          name: 'validpath',
          path: '/validpath',
          builder: (context, params) => const ValidpathWidget(),
        ),
        FFRoute(
          name: 'snakeladderproblem',
          path: '/snakeladderproblem',
          builder: (context, params) => const SnakeladderproblemWidget(),
        ),
        FFRoute(
          name: 'regioninbinarymatrix',
          path: '/regioninbinarymatrix',
          builder: (context, params) => const RegioninbinarymatrixWidget(),
        ),
        FFRoute(
          name: 'pathinmatrix',
          path: '/pathinmatrix',
          builder: (context, params) => const PathinmatrixWidget(),
        ),
        FFRoute(
          name: 'levelorder',
          path: '/levelorder',
          builder: (context, params) => const LevelorderWidget(),
        ),
        FFRoute(
          name: 'smallestmultiplewith0and1',
          path: '/smallestmultiplewith0and1',
          builder: (context, params) => const Smallestmultiplewith0and1Widget(),
        ),
        FFRoute(
          name: 'mincostpath',
          path: '/mincostpath',
          builder: (context, params) => const MincostpathWidget(),
        ),
        FFRoute(
          name: 'permutationswaps',
          path: '/permutationswaps',
          builder: (context, params) => const PermutationswapsWidget(),
        ),
        FFRoute(
          name: 'commutableislands',
          path: '/commutableislands',
          builder: (context, params) => const CommutableislandsWidget(),
        ),
        FFRoute(
          name: 'possibilityoffinishingallcoursesgiven',
          path: '/possibilityoffinishingallcoursesgiven',
          builder: (context, params) =>
              const PossibilityoffinishingallcoursesgivenWidget(),
        ),
        FFRoute(
          name: 'cycleinundirectedgraph',
          path: '/cycleinundirectedgraph',
          builder: (context, params) => const CycleinundirectedgraphWidget(),
        ),
        FFRoute(
          name: 'mothervertex',
          path: '/mothervertex',
          builder: (context, params) => const MothervertexWidget(),
        ),
        FFRoute(
          name: 'blackshapes',
          path: '/blackshapes',
          builder: (context, params) => const BlackshapesWidget(),
        ),
        FFRoute(
          name: 'convertsortedlisttobinarysearchtree',
          path: '/convertsortedlisttobinarysearchtree',
          builder: (context, params) =>
              const ConvertsortedlisttobinarysearchtreeWidget(),
        ),
        FFRoute(
          name: 'knighonchessboard',
          path: '/knighonchessboard',
          builder: (context, params) => const KnighonchessboardWidget(),
        ),
        FFRoute(
          name: 'usefulextraedge',
          path: '/usefulextraedge',
          builder: (context, params) => const UsefulextraedgeWidget(),
        ),
        FFRoute(
          name: 'wordladder1',
          path: '/wordladder1',
          builder: (context, params) => const Wordladder1Widget(),
        ),
        FFRoute(
          name: 'wordladder2',
          path: '/wordladder2',
          builder: (context, params) => const Wordladder2Widget(),
        ),
        FFRoute(
          name: 'clonegraph',
          path: '/clonegraph',
          builder: (context, params) => const ClonegraphWidget(),
        ),
        FFRoute(
          name: 'problemdifficulty',
          path: '/problemdifficulty',
          builder: (context, params) => const ProblemdifficultyWidget(),
        ),
        FFRoute(
          name: 'easydifficulty',
          path: '/easydifficulty',
          builder: (context, params) => const EasydifficultyWidget(),
        ),
        FFRoute(
          name: 'mediumdifficulty',
          path: '/mediumdifficulty',
          builder: (context, params) => const MediumdifficultyWidget(),
        ),
        FFRoute(
          name: 'harddifficulty',
          path: '/harddifficulty',
          builder: (context, params) => const HarddifficultyWidget(),
        ),
        FFRoute(
          name: 'compnaywisequestion',
          path: '/compnaywisequestion',
          builder: (context, params) => const CompnaywisequestionWidget(),
        ),
        FFRoute(
          name: 'amazonquestions',
          path: '/amazonquestions',
          builder: (context, params) => const AmazonquestionsWidget(),
        ),
        FFRoute(
          name: 'microsoftquestion',
          path: '/microsoftquestion',
          builder: (context, params) => const MicrosoftquestionWidget(),
        ),
        FFRoute(
          name: 'directiquestions',
          path: '/directiquestions',
          builder: (context, params) => const DirectiquestionsWidget(),
        ),
        FFRoute(
          name: 'facebookquestion',
          path: '/facebookquestion',
          builder: (context, params) => const FacebookquestionWidget(),
        ),
        FFRoute(
          name: 'paypalquestions',
          path: '/paypalquestions',
          builder: (context, params) => const PaypalquestionsWidget(),
        ),
        FFRoute(
          name: 'lindeinquestion',
          path: '/lindeinquestion',
          builder: (context, params) => const LindeinquestionWidget(),
        ),
        FFRoute(
          name: 'googlequestion',
          path: '/googlequestion',
          builder: (context, params) => const GooglequestionWidget(),
        ),
        FFRoute(
          name: 'fabquestions',
          path: '/fabquestions',
          builder: (context, params) => const FabquestionsWidget(),
        ),
        FFRoute(
          name: 'flipkartquestion',
          path: '/flipkartquestion',
          builder: (context, params) => const FlipkartquestionWidget(),
        ),
        FFRoute(
          name: 'adobequestion',
          path: '/adobequestion',
          builder: (context, params) => const AdobequestionWidget(),
        ),
        FFRoute(
          name: 'paytmquestions',
          path: '/paytmquestions',
          builder: (context, params) => const PaytmquestionsWidget(),
        ),
        FFRoute(
          name: 'uberquestion',
          path: '/uberquestion',
          builder: (context, params) => const UberquestionWidget(),
        ),
        FFRoute(
          name: 'walmartquestion',
          path: '/walmartquestion',
          builder: (context, params) => const WalmartquestionWidget(),
        ),
        FFRoute(
          name: 'housingquestion',
          path: '/housingquestion',
          builder: (context, params) => const HousingquestionWidget(),
        ),
        FFRoute(
          name: 'grofersquestions',
          path: '/grofersquestions',
          builder: (context, params) => const GrofersquestionsWidget(),
        ),
        FFRoute(
          name: 'zenefitsquestion',
          path: '/zenefitsquestion',
          builder: (context, params) => const ZenefitsquestionWidget(),
        ),
        FFRoute(
          name: 'yahooquestion',
          path: '/yahooquestion',
          builder: (context, params) => const YahooquestionWidget(),
        ),
        FFRoute(
          name: 'expediaquestion',
          path: '/expediaquestion',
          builder: (context, params) => const ExpediaquestionWidget(),
        ),
        FFRoute(
          name: 'mooonfroglabsquestions',
          path: '/mooonfroglabsquestions',
          builder: (context, params) => const MooonfroglabsquestionsWidget(),
        ),
        FFRoute(
          name: 'applequestion',
          path: '/applequestion',
          builder: (context, params) => const ApplequestionWidget(),
        ),
        FFRoute(
          name: 'inmobiquestions',
          path: '/inmobiquestions',
          builder: (context, params) => const InmobiquestionsWidget(),
        ),
        FFRoute(
          name: 'ebayquestions',
          path: '/ebayquestions',
          builder: (context, params) => const EbayquestionsWidget(),
        ),
        FFRoute(
          name: 'codenationquestion',
          path: '/codenationquestion',
          builder: (context, params) => const CodenationquestionWidget(),
        ),
        FFRoute(
          name: 'hrquestions',
          path: '/hrquestions',
          builder: (context, params) => const HrquestionsWidget(),
        ),
        FFRoute(
          name: 'traditionalhrquestion',
          path: '/traditionalhrquestion',
          builder: (context, params) => const TraditionalhrquestionWidget(),
        ),
        FFRoute(
          name: 'behaviouralhrinterviewquestions',
          path: '/behaviouralhrinterviewquestions',
          builder: (context, params) => const BehaviouralhrinterviewquestionsWidget(),
        ),
        FFRoute(
          name: 'opinionbasedhrinterviewquestion',
          path: '/opinionbasedhrinterviewquestion',
          builder: (context, params) => const OpinionbasedhrinterviewquestionWidget(),
        ),
        FFRoute(
          name: 'brainteaserquestion',
          path: '/brainteaserquestion',
          builder: (context, params) => const BrainteaserquestionWidget(),
        ),
        FFRoute(
          name: 'salaryrelatedquestion',
          path: '/salaryrelatedquestion',
          builder: (context, params) => const SalaryrelatedquestionWidget(),
        ),
        FFRoute(
          name: 'expolarequestionsaskedincompanies',
          path: '/expolarequestionsaskedincompanies',
          builder: (context, params) =>
              const ExpolarequestionsaskedincompaniesWidget(),
        ),
        FFRoute(
          name: 'tcsquestions',
          path: '/tcsquestions',
          builder: (context, params) => const TcsquestionsWidget(),
        ),
        FFRoute(
          name: 'wiproquestion',
          path: '/wiproquestion',
          builder: (context, params) => const WiproquestionWidget(),
        ),
        FFRoute(
          name: 'cognizantquestions',
          path: '/cognizantquestions',
          builder: (context, params) => const CognizantquestionsWidget(),
        ),
        FFRoute(
          name: 'mindtreequestios',
          path: '/mindtreequestios',
          builder: (context, params) => const MindtreequestiosWidget(),
        ),
        FFRoute(
          name: 'infosesquestions',
          path: '/infosesquestions',
          builder: (context, params) => const InfosesquestionsWidget(),
        ),
        FFRoute(
          name: 'accenturequestions',
          path: '/accenturequestions',
          builder: (context, params) => const AccenturequestionsWidget(),
        ),
        FFRoute(
          name: 'datascience',
          path: '/datascience',
          builder: (context, params) => const DatascienceWidget(),
        ),
        FFRoute(
          name: 'probabitlityofraining',
          path: '/probabitlityofraining',
          builder: (context, params) => const ProbabitlityofrainingWidget(),
        ),
        FFRoute(
          name: 'whitemarbleprobabitlity',
          path: '/whitemarbleprobabitlity',
          builder: (context, params) => const WhitemarbleprobabitlityWidget(),
        ),
        FFRoute(
          name: 'boyorgirlparadox',
          path: '/boyorgirlparadox',
          builder: (context, params) => const BoyorgirlparadoxWidget(),
        ),
        FFRoute(
          name: 'distributionpertenc',
          path: '/distributionpertenc',
          builder: (context, params) => const DistributionpertencWidget(),
        ),
        FFRoute(
          name: 'medianovermean',
          path: '/medianovermean',
          builder: (context, params) => const MedianovermeanWidget(),
        ),
        FFRoute(
          name: 'puzzele',
          path: '/puzzele',
          builder: (context, params) => const PuzzeleWidget(),
        ),
        FFRoute(
          name: 'monkeyandoor',
          path: '/monkeyandoor',
          builder: (context, params) => const MonkeyandoorWidget(),
        ),
        FFRoute(
          name: 'crossthebirdge',
          path: '/crossthebirdge',
          builder: (context, params) => const CrossthebirdgeWidget(),
        ),
        FFRoute(
          name: 'worldtrips',
          path: '/worldtrips',
          builder: (context, params) => const WorldtripsWidget(),
        ),
        FFRoute(
          name: 'onemileonthegloabe',
          path: '/onemileonthegloabe',
          builder: (context, params) => const OnemileonthegloabeWidget(),
        ),
        FFRoute(
          name: 'nextnumber2',
          path: '/nextnumber2',
          builder: (context, params) => const Nextnumber2Widget(),
        ),
        FFRoute(
          name: 'eggsnadbuilding',
          path: '/eggsnadbuilding',
          builder: (context, params) => const EggsnadbuildingWidget(),
        ),
        FFRoute(
          name: 'ratioofboysandgirls',
          path: '/ratioofboysandgirls',
          builder: (context, params) => const RatioofboysandgirlsWidget(),
        ),
        FFRoute(
          name: 'quateronatable',
          path: '/quateronatable',
          builder: (context, params) => const QuateronatableWidget(),
        ),
        FFRoute(
          name: 'lightswitchesinacellar',
          path: '/lightswitchesinacellar',
          builder: (context, params) => const LightswitchesinacellarWidget(),
        ),
        FFRoute(
          name: 'dividethecake',
          path: '/dividethecake',
          builder: (context, params) => const DividethecakeWidget(),
        ),
        FFRoute(
          name: 'findthedefectiveball',
          path: '/findthedefectiveball',
          builder: (context, params) => const FindthedefectiveballWidget(),
        ),
        FFRoute(
          name: 'dividethegoldbar',
          path: '/dividethegoldbar',
          builder: (context, params) => const DividethegoldbarWidget(),
        ),
        FFRoute(
          name: 'daughtersage',
          path: '/daughtersage',
          builder: (context, params) => const DaughtersageWidget(),
        ),
        FFRoute(
          name: 'jellybeansjars',
          path: '/jellybeansjars',
          builder: (context, params) => const JellybeansjarsWidget(),
        ),
        FFRoute(
          name: 'thetribe',
          path: '/thetribe',
          builder: (context, params) => const ThetribeWidget(),
        ),
        FFRoute(
          name: 'colorofabean',
          path: '/colorofabean',
          builder: (context, params) => const ColorofabeanWidget(),
        ),
        FFRoute(
          name: 'Resume',
          path: '/resume',
          builder: (context, params) => const ResumeWidget(),
        ),
        FFRoute(
          name: 'PythonDeveloperResume',
          path: '/pythonDeveloperResume',
          builder: (context, params) => const PythonDeveloperResumeWidget(),
        ),
        FFRoute(
          name: 'DataScientistResume',
          path: '/dataScientistResume',
          builder: (context, params) => const DataScientistResumeWidget(),
        ),
        FFRoute(
          name: 'ScrumMasterResume',
          path: '/scrumMasterResume',
          builder: (context, params) => const ScrumMasterResumeWidget(),
        ),
        FFRoute(
          name: 'FullStackDeveloperResume',
          path: '/fullStackDeveloperResume',
          builder: (context, params) => const FullStackDeveloperResumeWidget(),
        ),
        FFRoute(
          name: 'FrontEndDeveloperResume',
          path: '/frontEndDeveloperResume',
          builder: (context, params) => const FrontEndDeveloperResumeWidget(),
        ),
        FFRoute(
          name: 'companyprinciple',
          path: '/companyprinciple',
          builder: (context, params) => const CompanyprincipleWidget(),
        ),
        FFRoute(
          name: 'amazonprinciple',
          path: '/amazonprinciple',
          builder: (context, params) => const AmazonprincipleWidget(),
        ),
        FFRoute(
          name: 'microsoftprinciple',
          path: '/microsoftprinciple',
          builder: (context, params) => const MicrosoftprincipleWidget(),
        ),
        FFRoute(
          name: 'facebookprinciple',
          path: '/facebookprinciple',
          builder: (context, params) => const FacebookprincipleWidget(),
        ),
        FFRoute(
          name: 'paypalprinciple',
          path: '/paypalprinciple',
          builder: (context, params) => const PaypalprincipleWidget(),
        ),
        FFRoute(
          name: 'linkedinprinciple',
          path: '/linkedinprinciple',
          builder: (context, params) => const LinkedinprincipleWidget(),
        ),
        FFRoute(
          name: 'googleprinciple',
          path: '/googleprinciple',
          builder: (context, params) => const GoogleprincipleWidget(),
        ),
        FFRoute(
          name: 'flipkartprinciple',
          path: '/flipkartprinciple',
          builder: (context, params) => const FlipkartprincipleWidget(),
        ),
        FFRoute(
          name: 'adobeprinciple',
          path: '/adobeprinciple',
          builder: (context, params) => const AdobeprincipleWidget(),
        ),
        FFRoute(
          name: 'Paytmprinciple',
          path: '/paytmprinciple',
          builder: (context, params) => const PaytmprincipleWidget(),
        ),
        FFRoute(
          name: 'uberprinciple',
          path: '/uberprinciple',
          builder: (context, params) => const UberprincipleWidget(),
        ),
        FFRoute(
          name: 'walmartprinciple',
          path: '/walmartprinciple',
          builder: (context, params) => const WalmartprincipleWidget(),
        ),
        FFRoute(
          name: 'yahooprinciple',
          path: '/yahooprinciple',
          builder: (context, params) => const YahooprincipleWidget(),
        ),
        FFRoute(
          name: 'appleprinciple',
          path: '/appleprinciple',
          builder: (context, params) => const AppleprincipleWidget(),
        ),
        FFRoute(
          name: 'Interviewetiquette',
          path: '/interviewetiquette',
          builder: (context, params) => const InterviewetiquetteWidget(),
        ),
        FFRoute(
          name: 'TipsforBeforeanInterview',
          path: '/tipsforBeforeanInterview',
          builder: (context, params) => const TipsforBeforeanInterviewWidget(),
        ),
        FFRoute(
          name: 'TipsforduringanInterview',
          path: '/tipsforduringanInterview',
          builder: (context, params) => const TipsforduringanInterviewWidget(),
        ),
        FFRoute(
          name: 'TipsforafteranInterview',
          path: '/tipsforafteranInterview',
          builder: (context, params) => const TipsforafteranInterviewWidget(),
        ),
        FFRoute(
          name: 'GeminiBot',
          path: '/geminiBot',
          builder: (context, params) => const GeminiBotWidget(),
        ),
        FFRoute(
          name: 'CodeEditor',
          path: '/codeEditor',
          builder: (context, params) => const CodeEditorWidget(),
        ),
        FFRoute(
          name: 'Jobportal',
          path: '/jobportal',
          builder: (context, params) => const JobportalWidget(),
        ),
        FFRoute(
          name: 'contestcalender',
          path: '/contestcalender',
          builder: (context, params) => const ContestcalenderWidget(),
        ),
        FFRoute(
          name: 'Roadmaps',
          path: '/roadmaps',
          builder: (context, params) => const RoadmapsWidget(),
        ),
        FFRoute(
          name: 'frontend',
          path: '/frontend',
          builder: (context, params) => const FrontendWidget(),
        ),
        FFRoute(
          name: 'fullstack',
          path: '/fullstack',
          builder: (context, params) => const FullstackWidget(),
        ),
        FFRoute(
          name: 'andriod',
          path: '/andriod',
          builder: (context, params) => const AndriodWidget(),
        ),
        FFRoute(
          name: 'blockchain',
          path: '/blockchain',
          builder: (context, params) => const BlockchainWidget(),
        ),
        FFRoute(
          name: 'cybersecurity',
          path: '/cybersecurity',
          builder: (context, params) => const CybersecurityWidget(),
        ),
        FFRoute(
          name: 'technicalwriter',
          path: '/technicalwriter',
          builder: (context, params) => const TechnicalwriterWidget(),
        ),
        FFRoute(
          name: 'Developerrelation',
          path: '/developerrelation',
          builder: (context, params) => const DeveloperrelationWidget(),
        ),
        FFRoute(
          name: 'Backend',
          path: '/backend',
          builder: (context, params) => const BackendWidget(),
        ),
        FFRoute(
          name: 'Aiands',
          path: '/aiands',
          builder: (context, params) => const AiandsWidget(),
        ),
        FFRoute(
          name: 'iosdev',
          path: '/iosdev',
          builder: (context, params) => const IosdevWidget(),
        ),
        FFRoute(
          name: 'QA',
          path: '/qa',
          builder: (context, params) => const QaWidget(),
        ),
        FFRoute(
          name: 'UXdesign',
          path: '/uXdesign',
          builder: (context, params) => const UXdesignWidget(),
        ),
        FFRoute(
          name: 'MLops',
          path: '/mLops',
          builder: (context, params) => const MLopsWidget(),
        ),
        FFRoute(
          name: 'DevOps',
          path: '/devOps',
          builder: (context, params) => const DevOpsWidget(),
        ),
        FFRoute(
          name: 'Dataalanyst',
          path: '/dataalanyst',
          builder: (context, params) => const DataalanystWidget(),
        ),
        FFRoute(
          name: 'PostgreSQl',
          path: '/postgreSQl',
          builder: (context, params) => const PostgreSQlWidget(),
        ),
        FFRoute(
          name: 'softwareartic',
          path: '/softwareartic',
          builder: (context, params) => const SoftwarearticWidget(),
        ),
        FFRoute(
          name: 'gamedev',
          path: '/gamedev',
          builder: (context, params) => const GamedevWidget(),
        ),
        FFRoute(
          name: 'Productmanager',
          path: '/productmanager',
          builder: (context, params) => const ProductmanagerWidget(),
        )
      ].map((r) => r.toRoute(appStateNotifier)).toList(),
      observers: [routeObserver],
    );

extension NavParamExtensions on Map<String, String?> {
  Map<String, String> get withoutNulls => Map.fromEntries(
        entries
            .where((e) => e.value != null)
            .map((e) => MapEntry(e.key, e.value!)),
      );
}

extension NavigationExtensions on BuildContext {
  void safePop() {
    // If there is only one route on the stack, navigate to the initial
    // page instead of popping.
    if (canPop()) {
      pop();
    } else {
      go('/');
    }
  }
}

extension _GoRouterStateExtensions on GoRouterState {
  Map<String, dynamic> get extraMap =>
      extra != null ? extra as Map<String, dynamic> : {};
  Map<String, dynamic> get allParams => <String, dynamic>{}
    ..addAll(pathParameters)
    ..addAll(uri.queryParameters)
    ..addAll(extraMap);
  TransitionInfo get transitionInfo => extraMap.containsKey(kTransitionInfoKey)
      ? extraMap[kTransitionInfoKey] as TransitionInfo
      : TransitionInfo.appDefault();
}

class FFParameters {
  FFParameters(this.state, [this.asyncParams = const {}]);

  final GoRouterState state;
  final Map<String, Future<dynamic> Function(String)> asyncParams;

  Map<String, dynamic> futureParamValues = {};

  // Parameters are empty if the params map is empty or if the only parameter
  // present is the special extra parameter reserved for the transition info.
  bool get isEmpty =>
      state.allParams.isEmpty ||
      (state.allParams.length == 1 &&
          state.extraMap.containsKey(kTransitionInfoKey));
  bool isAsyncParam(MapEntry<String, dynamic> param) =>
      asyncParams.containsKey(param.key) && param.value is String;
  bool get hasFutures => state.allParams.entries.any(isAsyncParam);
  Future<bool> completeFutures() => Future.wait(
        state.allParams.entries.where(isAsyncParam).map(
          (param) async {
            final doc = await asyncParams[param.key]!(param.value)
                .onError((_, __) => null);
            if (doc != null) {
              futureParamValues[param.key] = doc;
              return true;
            }
            return false;
          },
        ),
      ).onError((_, __) => [false]).then((v) => v.every((e) => e));

  dynamic getParam<T>(
    String paramName,
    ParamType type, {
    bool isList = false,
  }) {
    if (futureParamValues.containsKey(paramName)) {
      return futureParamValues[paramName];
    }
    if (!state.allParams.containsKey(paramName)) {
      return null;
    }
    final param = state.allParams[paramName];
    // Got parameter from `extras`, so just directly return it.
    if (param is! String) {
      return param;
    }
    // Return serialized value.
    return deserializeParam<T>(
      param,
      type,
      isList,
    );
  }
}

class FFRoute {
  const FFRoute({
    required this.name,
    required this.path,
    required this.builder,
    this.requireAuth = false,
    this.asyncParams = const {},
    this.routes = const [],
  });

  final String name;
  final String path;
  final bool requireAuth;
  final Map<String, Future<dynamic> Function(String)> asyncParams;
  final Widget Function(BuildContext, FFParameters) builder;
  final List<GoRoute> routes;

  GoRoute toRoute(AppStateNotifier appStateNotifier) => GoRoute(
        name: name,
        path: path,
        pageBuilder: (context, state) {
          fixStatusBarOniOS16AndBelow(context);
          final ffParams = FFParameters(state, asyncParams);
          final page = ffParams.hasFutures
              ? FutureBuilder(
                  future: ffParams.completeFutures(),
                  builder: (context, _) => builder(context, ffParams),
                )
              : builder(context, ffParams);
          final child = page;

          final transitionInfo = state.transitionInfo;
          return transitionInfo.hasTransition
              ? CustomTransitionPage(
                  key: state.pageKey,
                  child: child,
                  transitionDuration: transitionInfo.duration,
                  transitionsBuilder:
                      (context, animation, secondaryAnimation, child) =>
                          PageTransition(
                    type: transitionInfo.transitionType,
                    duration: transitionInfo.duration,
                    reverseDuration: transitionInfo.duration,
                    alignment: transitionInfo.alignment,
                    child: child,
                  ).buildTransitions(
                    context,
                    animation,
                    secondaryAnimation,
                    child,
                  ),
                )
              : MaterialPage(key: state.pageKey, child: child);
        },
        routes: routes,
      );
}

class TransitionInfo {
  const TransitionInfo({
    required this.hasTransition,
    this.transitionType = PageTransitionType.fade,
    this.duration = const Duration(milliseconds: 300),
    this.alignment,
  });

  final bool hasTransition;
  final PageTransitionType transitionType;
  final Duration duration;
  final Alignment? alignment;

  static TransitionInfo appDefault() => const TransitionInfo(hasTransition: false);
}

class RootPageContext {
  const RootPageContext(this.isRootPage, [this.errorRoute]);
  final bool isRootPage;
  final String? errorRoute;

  static bool isInactiveRootPage(BuildContext context) {
    final rootPageContext = context.read<RootPageContext?>();
    final isRootPage = rootPageContext?.isRootPage ?? false;
    final location = GoRouterState.of(context).uri.toString();
    return isRootPage &&
        location != '/' &&
        location != rootPageContext?.errorRoute;
  }

  static Widget wrap(Widget child, {String? errorRoute}) => Provider.value(
        value: RootPageContext(true, errorRoute),
        child: child,
      );
}

extension GoRouterLocationExtension on GoRouter {
  String getCurrentLocation() {
    final RouteMatch lastMatch = routerDelegate.currentConfiguration.last;
    final RouteMatchList matchList = lastMatch is ImperativeRouteMatch
        ? lastMatch.matches
        : routerDelegate.currentConfiguration;
    return matchList.uri.toString();
  }
}
