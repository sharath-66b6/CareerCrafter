import '/flutter_flow/flutter_flow_util.dart';
import 'housingquestion_widget.dart' show HousingquestionWidget;
import 'package:flutter/material.dart';

class HousingquestionModel extends FlutterFlowModel<HousingquestionWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
