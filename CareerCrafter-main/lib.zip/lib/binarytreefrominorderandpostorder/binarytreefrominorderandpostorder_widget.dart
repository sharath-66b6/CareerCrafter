import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'binarytreefrominorderandpostorder_model.dart';
export 'binarytreefrominorderandpostorder_model.dart';

class BinarytreefrominorderandpostorderWidget extends StatefulWidget {
  const BinarytreefrominorderandpostorderWidget({super.key});

  @override
  State<BinarytreefrominorderandpostorderWidget> createState() =>
      _BinarytreefrominorderandpostorderWidgetState();
}

class _BinarytreefrominorderandpostorderWidgetState
    extends State<BinarytreefrominorderandpostorderWidget> {
  late BinarytreefrominorderandpostorderModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model =
        createModel(context, () => BinarytreefrominorderandpostorderModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Binary Tree From Inorder And Postorder',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1000.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \nGiven inorder and postorder traversal of a tree, construct the binary tree.\n\nNote: You may assume that duplicates do not exist in the tree.\n\nExample :\n\nInput : \n        Inorder : [2, 1, 3]\n        Postorder : [2, 3, 1]\n\nReturn : \n            1\n           / \\\n          2   3\n\n\n\nAnswer :-\nint getindex(int x,int in[],int start,int end){\n    int i=0;\n    for (i=start;i<=end;i++){\n        if(in[i]==x)\n        return i;\n    }\n    return -1;\n} \ntreenode* tree(treenode* root,int in[],int post[],int start,int end,int pos){\n    if(start>end)\n    return NULL;\n    root=treenode_new(post[pos]);\n    int index=getindex(root->val,in,start,end);\n    root->right=tree(root,in,post,index+1,end,pos-1);\n    root->left=tree(root,in,post,start,index-1,pos-(end-index)-1);\n    return root;\n}\n\ntreenode* buildTree(int* inorder, int n1, int* postorder, int n2) {\n    treenode* root=NULL;\n    root=tree(root,inorder,postorder,0,n1-1,n1-1);\n    return root;\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=7siC3XcaMbs&pp=ygUzaW50ZXJ2aWV3Yml0IGJpbmFyeSB0cmVlIGZyb20gaW5vcmRlciBhbmQgcG9zdG9yZGVy',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
