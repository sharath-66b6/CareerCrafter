import '/flutter_flow/flutter_flow_util.dart';
import 'binarytreefrominorderandpostorder_widget.dart'
    show BinarytreefrominorderandpostorderWidget;
import 'package:flutter/material.dart';

class BinarytreefrominorderandpostorderModel
    extends FlutterFlowModel<BinarytreefrominorderandpostorderWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
