import '/flutter_flow/flutter_flow_util.dart';
import 'implementstrstr_widget.dart' show ImplementstrstrWidget;
import 'package:flutter/material.dart';

class ImplementstrstrModel extends FlutterFlowModel<ImplementstrstrWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
