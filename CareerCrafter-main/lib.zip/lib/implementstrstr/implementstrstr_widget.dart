import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'implementstrstr_model.dart';
export 'implementstrstr_model.dart';

class ImplementstrstrWidget extends StatefulWidget {
  const ImplementstrstrWidget({super.key});

  @override
  State<ImplementstrstrWidget> createState() => _ImplementstrstrWidgetState();
}

class _ImplementstrstrWidgetState extends State<ImplementstrstrWidget> {
  late ImplementstrstrModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ImplementstrstrModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Implement StrStr',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1700.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nAnother question which belongs to the category of questions which are intentionally stated vaguely.\n\nExpectation is that you will ask for correct clarification or you will state your assumptions before you start coding.\n\nImplement strStr().\n\nstrstr - locate a substring ( needle ) in a string ( haystack ).\n\nTry not to use standard library string functions for this question.\n\nReturns the index of the first occurrence of needle in haystack, or -1 if needle is not part of haystack.\n\nNOTE: String A is haystack, B is needle.\n\nGood clarification questions:\n\nWhat should be the return value if the needle is empty?\nWhat if both haystack and needle are empty?\nFor the purpose of this problem, assume that the return value should be -1 in both cases.\n\n\nProblem Constraints\n1 <= |haystack| <= 104\n1 <= |needle| <= 103\n\n\nInput Format\nThe first argument is a string A (haystack)\nThe second argument is a string B (needle)\n\n\nOutput Format\nReturn an integer, the index of the first occurrence of needle in haystack, or -1 if needle is not part of haystack.\n\n\nExample Input\nInput 1:\nA = \"strstr\"\nB = \"str\"\nInput 2:\nA = \"bighit\"\nB = \"bit\"\n\n\nExample Output\nOutput 1:\n0\nOutput 1:\n-1\n\n\nExample Explanation\nExplanation 1:\n\"str\" occurs at index 0 and 3.\nThe first occurrence is at index 0, so we return 0.\nExplanation 2:\n\"bit\" did not occur in \"bighit\", so we return -1.\n\n\n\nAnswer :-\n/**\n * @input haystack : Read only ( DON\'T MODIFY ) String termination by \'\\0\'\n * @input needle : Read only ( DON\'T MODIFY ) String termination by \'\\0\'\n * \n * @Output Integer\n */\nint strStr(const char* haystack, const char* needle) {\n    char *loc = strstr(haystack, needle);\n    if (loc == NULL) return -1;\n    else return loc - haystack;\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=GyKG65IdtEA&pp=ygUeaW50ZXJ2aWV3Yml0IGltcGxlbWVudCBzdHJzdHJy',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
