import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'constructbinarytreefrominorderandpreorder_model.dart';
export 'constructbinarytreefrominorderandpreorder_model.dart';

class ConstructbinarytreefrominorderandpreorderWidget extends StatefulWidget {
  const ConstructbinarytreefrominorderandpreorderWidget({super.key});

  @override
  State<ConstructbinarytreefrominorderandpreorderWidget> createState() =>
      _ConstructbinarytreefrominorderandpreorderWidgetState();
}

class _ConstructbinarytreefrominorderandpreorderWidgetState
    extends State<ConstructbinarytreefrominorderandpreorderWidget> {
  late ConstructbinarytreefrominorderandpreorderModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(
        context, () => ConstructbinarytreefrominorderandpreorderModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Construct Binary Tree From Inorder And Preorder',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1600.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven preorder and inorder traversal of a tree, construct the binary tree.\nNote: You may assume that duplicates do not exist in the tree.\n\n\nProblem Constraints\n1 <= |A| <= 105\n|A| == |B|\n\n\nInput Format\nThe first argument is an integer array A representing the preorder traversal.\nThe second argument is an integer array B representing the inorder traversal.\n\n\nOutput Format\nReturn the pointer to the root node of the tree.\n\n\nExample Input\nPreorder : [1, 2, 3]\nInorder  : [2, 1, 3]\n\n\nExample Output\n            1\n           / \\\n          2   3\n\n\nAnswer :-\nint ind(int num,int *a,int s,int n)\n{\n    int i,index=0;\n    for(i=s;i<=n;i++)\n    {\n        if(a[i]==num)\n        index=i;\n    }\n    return index;\n}\nint m;\nvoid init()\n{\n    m=0;\n}\ntreenode* find(int* preorder,int *inorder,int i1,int i2,int n)\n{\n    int index1;//1,index2;\n    if(i1>i2)\n    return NULL;\n    if(m<=n)\n    {\n        index1 = ind(preorder[m],inorder,i1,i2);\n        if(index1==-1) return NULL;\n        treenode* root = (treenode *)malloc(sizeof(treenode));\n        root->val = preorder[m];\n        m++;\n        //index2 = ind(preorder[m],int *inorder,int i1,int i2);\n        root->left = find(preorder,inorder,i1,index1-1,n);\n        root->right = find(preorder,inorder,index1+1,i2,n);\n        return root;\n    }\n}\n\n\ntreenode* buildTree(int* preorder, int n1, int* inorder, int n2) {\n    init();\n    treenode *root;\n    root = find(preorder,inorder,0,n2-1,n1-1);\n    return root;\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=FnlsqbEQBcE&pp=ygU0aW50ZXJ2aWV3Yml0IGNvbnN0cnVjdCBiaW5hcnkgdHJlZSBmcm9tIGlub3JkZXIgYW5kIA%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
