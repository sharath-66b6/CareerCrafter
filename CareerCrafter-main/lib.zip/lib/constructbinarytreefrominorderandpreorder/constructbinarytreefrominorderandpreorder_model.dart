import '/flutter_flow/flutter_flow_util.dart';
import 'constructbinarytreefrominorderandpreorder_widget.dart'
    show ConstructbinarytreefrominorderandpreorderWidget;
import 'package:flutter/material.dart';

class ConstructbinarytreefrominorderandpreorderModel
    extends FlutterFlowModel<ConstructbinarytreefrominorderandpreorderWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
