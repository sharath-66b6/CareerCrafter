import '/flutter_flow/flutter_flow_util.dart';
import 'anincrementproblem_widget.dart' show AnincrementproblemWidget;
import 'package:flutter/material.dart';

class AnincrementproblemModel
    extends FlutterFlowModel<AnincrementproblemWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
