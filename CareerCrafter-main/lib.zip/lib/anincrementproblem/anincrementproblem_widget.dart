import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'anincrementproblem_model.dart';
export 'anincrementproblem_model.dart';

class AnincrementproblemWidget extends StatefulWidget {
  const AnincrementproblemWidget({super.key});

  @override
  State<AnincrementproblemWidget> createState() =>
      _AnincrementproblemWidgetState();
}

class _AnincrementproblemWidgetState extends State<AnincrementproblemWidget> {
  late AnincrementproblemModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => AnincrementproblemModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).primary,
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30.0,
            borderWidth: 1.0,
            buttonSize: 60.0,
            icon: const Icon(
              Icons.arrow_back_rounded,
              color: Colors.white,
              size: 30.0,
            ),
            onPressed: () async {
              context.pop();
            },
          ),
          title: Text(
            'An Increment Problem',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: 'Outfit',
                  color: Colors.white,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                ),
          ),
          actions: const [],
          centerTitle: true,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: ListView(
            padding: const EdgeInsets.symmetric(vertical: 12.0),
            scrollDirection: Axis.vertical,
            children: [
              Container(
                width: 100.0,
                height: 3100.0,
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryBackground,
                ),
                child: Align(
                  alignment: const AlignmentDirectional(0.0, -1.0),
                  child: Text(
                    'Problem Description\n \n \n\nGiven a stream of numbers A. On arrival of each number, you need to increase its first occurrence by 1 and include this in the stream.\n\nReturn the final stream of numbers.\n\nNote: You will traverse the stream from left to right and update the first occurrence of the number by 1, if found.\n\n\n\nProblem Constraints\n1 <= |A| <= 100000\n\n1 <= A[i] <= 10000\n\n\n\nInput Format\nFirst and only argument is the array A.\n\n\n\nOutput Format\nReturn an array, the final stream of numbers.\n\n\n\nExample Input\nInput 1: \n\nA = [1, 1]\n \n\nInput 2:\n\nA = [1, 2]\n \n\nInput 3:\n\nA = [1, 1, 2, 2]\n\n\nExample Output\nOutput 1:\n\n[2, 1]\n \n\nOutput 2:\n\n[1, 2]\n \n\nOutput 3:\n\n[3, 1, 3, 2]\n\n\nExample Explanation\nExplanation 1:\n\nOn arrival of the second element, the other element is increased by 1.\n \n\nExplanation 2:\n\nNo increases are to be done.\n \n\nExplanation 3:\n\nStream after arrival of numbers (1-based indexing):\n  First number  (1): [1]          , Simply push 1 to the stream\n  Second number (1): [2, 1]       , Increment first occurence of 1, present at 1st Index and push 1 to the stream\n  Third number  (2): [3, 1, 2]    , Increment first occurence of 2, present at 1st Index and push 2 to the stream\n  Fourth number (2): [3, 1, 3, 2] , Increment first occurence of 2, present at 3rd Index and push 2 to the stream\n\n\nAnswer :-\n/**\n * @input A : Integer array\n * @input n1 : Integer array\'s ( A ) length\n * \n * @Output Integer array. You need to malloc memory, and fill the length in len1\n */\n\ntypedef struct map_s {\n    int n;\n    int min;\n    struct map_s *next;\n} map_t;\n\n#define HSIZE (71)\n\nint* solve(int* A, int n1, int *len1) {\n    int i;\n    int bin;\n    map_t *data;\n    int nextN;\n    int prevMin;\n    \n    int *s = malloc(n1 * sizeof(*A));\n    *len1 = n1;\n    \n    map_t *h[HSIZE] = {NULL};\n    \n    for (i = 0; i < n1; i++) {\n        if (A[i] > 0) {\n            bin = A[i];\n        } else {\n            bin = -A[i];\n        }\n        bin %= HSIZE;\n        data = h[bin];\n        while (data && data->n != A[i]) {\n            data = data->next;\n        }\n        if (data == NULL) {\n            data = (map_t*) malloc(sizeof(*data));\n            data->n = A[i];\n            data->min = i;\n            data->next = h[bin];\n            h[bin] = data;\n        } else {\n            prevMin = data->min;\n            nextN = s[prevMin] + 1;\n            s[data->min] = nextN;\n            data->min = i;\n            if (nextN > 0) {\n                bin = nextN;\n            } else {\n                bin = -nextN;\n            }\n            bin %= HSIZE;\n            data = h[bin];\n            while (data && data->n != nextN) {\n                data = data->next;\n            }\n            if (data == NULL) {\n                data = (map_t*) malloc(sizeof(*data));\n                data->n = nextN;\n                data->min = prevMin;\n                data->next = h[bin];\n                h[bin] = data;\n            } else {\n                if (prevMin < data->min) {\n                    data->min = prevMin;\n                }\n            }\n        }\n        \n        s[i] = A[i];\n    }\n    \n    return s;\n}\n\n',
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Readex Pro',
                          letterSpacing: 0.0,
                        ),
                  ),
                ),
              ),
            ].divide(const SizedBox(height: 12.0)),
          ),
        ),
      ),
    );
  }
}
