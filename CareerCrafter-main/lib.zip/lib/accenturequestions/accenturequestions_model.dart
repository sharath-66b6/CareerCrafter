import '/flutter_flow/flutter_flow_util.dart';
import 'accenturequestions_widget.dart' show AccenturequestionsWidget;
import 'package:flutter/material.dart';

class AccenturequestionsModel
    extends FlutterFlowModel<AccenturequestionsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
