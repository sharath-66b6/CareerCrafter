import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'inordertransversal_model.dart';
export 'inordertransversal_model.dart';

class InordertransversalWidget extends StatefulWidget {
  const InordertransversalWidget({super.key});

  @override
  State<InordertransversalWidget> createState() =>
      _InordertransversalWidgetState();
}

class _InordertransversalWidgetState extends State<InordertransversalWidget> {
  late InordertransversalModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => InordertransversalModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Inorder Traversal',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1600.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven a binary tree, return the inorder traversal of its nodes values.\n\nNOTE: Using recursion is not allowed.\n\n\n\nProblem Constraints\n 1 <= number of nodes <= 105\n\n\n\nInput Format\nFirst and only argument is root node of the binary tree, A.\n\n\n\nOutput Format\nReturn an integer array denoting the inorder traversal of the given binary tree.\n\n\n\nExample Input\nInput 1:\n\n   1\n    \\\n     2\n    /\n   3\nInput 2:\n\n   1\n  / \\\n 6   2\n    /\n   3\n\n\nExample Output\nOutput 1:\n\n [1, 3, 2]\nOutput 2:\n\n [6, 1, 3, 2]\n\n\nExample Explanation\nExplanation 1:\n\n The Inorder Traversal of the given tree is [1, 3, 2].\nExplanation 2:\n\n The Inorder Traversal of the given tree is [6, 1, 3, 2].\n\n\nAnswer :-\nint *st,i;\n void traversal(treenode *node)\n {\n     if(node->left!=NULL)\n     traversal(node->left);\n     \n     st[i++]=node->val;\n     \n     if(node->right!=NULL)\n     traversal(node->right);\n }\nint* inorderTraversal(treenode* A, int *len1) \n{\n    st=(int *)malloc(sizeof(int)*3000000);\n    i=0;\n    traversal(A);\n    *len1=i;\n    return st;\n}',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=rbINW7Dvwv0&pp=ygUeaW50ZXJ2aWV3Yml0IGlub3JkZXIgdHJhdmVyc2Fs',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
