import '/flutter_flow/flutter_flow_util.dart';
import 'inordertransversal_widget.dart' show InordertransversalWidget;
import 'package:flutter/material.dart';

class InordertransversalModel
    extends FlutterFlowModel<InordertransversalWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
