import '/flutter_flow/flutter_flow_util.dart';
import 'minimumparantheses_widget.dart' show MinimumparanthesesWidget;
import 'package:flutter/material.dart';

class MinimumparanthesesModel
    extends FlutterFlowModel<MinimumparanthesesWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
