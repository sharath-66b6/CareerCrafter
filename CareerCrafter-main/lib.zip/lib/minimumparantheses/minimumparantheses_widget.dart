import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'minimumparantheses_model.dart';
export 'minimumparantheses_model.dart';

class MinimumparanthesesWidget extends StatefulWidget {
  const MinimumparanthesesWidget({super.key});

  @override
  State<MinimumparanthesesWidget> createState() =>
      _MinimumparanthesesWidgetState();
}

class _MinimumparanthesesWidgetState extends State<MinimumparanthesesWidget> {
  late MinimumparanthesesModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MinimumparanthesesModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Minimum Parantheses!',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1900.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nGiven a string A of parantheses  ‘(‘ or ‘)’.\n\nThe task is to find minimum number of parentheses ‘(‘ or ‘)’ (at any positions) we must add to make the resulting parentheses string valid.\n\nAn string is valid if:\n\nOpen brackets must be closed by the corresponding closing bracket.\nOpen brackets must be closed in the correct order.\n\n\nProblem Constraints\n1 <= |A| <= 105\n\nA[i] = \'(\' or A[i] = \')\'\n\n\n\nInput Format\nFirst and only argument is an string A.\n\n\n\nOutput Format\nReturn a single integer denoting the minimumnumber of parentheses ‘(‘ or ‘)’ (at any positions) we must add in A to make the resulting parentheses string valid.\n\n\n\nExample Input\nInput 1:\n\n A = \"())\"\nInput 2:\n\n A = \"(((\"\n\n\nExample Output\nOutput 1:\n\n 1\nOutput 2:\n\n 3\n\n\nExample Explanation\nExplanation 1:\n\n One \'(\' is required at beginning.\nExplanation 2:\n\n Three \')\' is required at end.\n\n\nAnswer:-\n/**\n * @input A : String termination by \'\\0\'\n * \n * @Output Integer\n */\nint solve(char* A) {\n    int i;\n    int count =0;\n    int flag = 0;\n    int n=0;\n    int l = strlen(A);\n    for(i=0;i<l;i++){\n        if(count == n){\n            flag =0;\n        }\n        if(A[i] == \'(\'){\n            count++;\n            flag = 1;\n        }\n        else if(A[i]==\')\' && flag == 1){\n            count--;\n        }\n        else if(A[i] == \')\' && flag == 0){\n            count ++;\n            n++;\n        }\n    }\n  if(count > 0){\n      return count;\n  }\n  else return count*(-1);\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=e7HyTdHAf4U&pp=ygUgaW50ZXJ2aWV3Yml0IG1pbmltdW0gcGFyZW50aGVzZXM%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
