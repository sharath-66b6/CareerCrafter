import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'counttotalsetbits_model.dart';
export 'counttotalsetbits_model.dart';

class CounttotalsetbitsWidget extends StatefulWidget {
  const CounttotalsetbitsWidget({super.key});

  @override
  State<CounttotalsetbitsWidget> createState() =>
      _CounttotalsetbitsWidgetState();
}

class _CounttotalsetbitsWidgetState extends State<CounttotalsetbitsWidget> {
  late CounttotalsetbitsModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CounttotalsetbitsModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Count Total Set Bits',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1900.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nGiven a positive integer A, the task is to count the total number of set bits in the binary representation of all the numbers from 1 to A.\n\nReturn the count modulo 109 + 7.\n\n\n\nProblem Constraints\n1 <= A <= 109\n\n\n\nInput Format\nFirst and only argument is an integer A.\n\n\n\nOutput Format\nReturn an integer denoting the ( Total number of set bits in the binary representation of all the numbers from 1 to A )modulo 109 + 7.\n\n\n\nExample Input\nInput 1:\n\n A = 3\nInput 2:\n\n A = 1\n\n\nExample Output\nOutput 1:\n\n 4\nOutput 2:\n\n 1\n\n\nExample Explanation\nExplanation 1:\n\n DECIMAL    BINARY  SET BIT COUNT\n    1          01        1\n    2          10        1\n    3          11        2\n 1 + 1 + 2 = 4 \n Answer = 4 % 1000000007 = 4\nExplanation 2:\n\n A = 1\n  DECIMAL    BINARY  SET BIT COUNT\n    1          01        1\n Answer = 1 % 1000000007 = 1\n\n\n\n\nAnswer :-\n/**\n * @input A : Integer\n * \n * @Output Integer\n */\nint solve(int A) {\n    if (A < 2) return A;\n    int i = 0, x = A;\n    long long int result = 0;\n    while (x != 0) {\n        if (i == 0) {\n            result += A / 2;\n        } else {\n            int temp = pow(2, i);\n            int ratio = A / temp;\n            if (ratio&1) {\n                result += A % temp;\n                ratio--;\n            }\n            result += (ratio/2)*temp;\n        }\n        if (x&1) result++;\n        result %= 1000000007;\n        x /= 2;\n        i++;\n    }\n    return result;\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=kU5G5-6xEF4&pp=ygUiaW50ZXJ2aWV3Yml0IGNvdW50IHRvdHRhbCBzZXQgYml0cw%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
