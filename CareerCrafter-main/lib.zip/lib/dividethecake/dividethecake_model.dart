import '/flutter_flow/flutter_flow_util.dart';
import 'dividethecake_widget.dart' show DividethecakeWidget;
import 'package:flutter/material.dart';

class DividethecakeModel extends FlutterFlowModel<DividethecakeWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
