import '/flutter_flow/flutter_flow_util.dart';
import 'additionwithoutsummation_widget.dart'
    show AdditionwithoutsummationWidget;
import 'package:flutter/material.dart';

class AdditionwithoutsummationModel
    extends FlutterFlowModel<AdditionwithoutsummationWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
