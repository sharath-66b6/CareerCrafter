import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'additionwithoutsummation_model.dart';
export 'additionwithoutsummation_model.dart';

class AdditionwithoutsummationWidget extends StatefulWidget {
  const AdditionwithoutsummationWidget({super.key});

  @override
  State<AdditionwithoutsummationWidget> createState() =>
      _AdditionwithoutsummationWidgetState();
}

class _AdditionwithoutsummationWidgetState
    extends State<AdditionwithoutsummationWidget> {
  late AdditionwithoutsummationModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => AdditionwithoutsummationModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Addition without Summation',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1400.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nYou are given two numbers A and B.\n\nYou have to add them without using arithmetic operators and return their sum.\n\n\n\nProblem Constraints\n1 <= A, B <= 109\n\n\nInput Format\nThe first argument is the integer A. The second argument is the integer B.\n\n\nOutput Format\nReturn a single integer denoting their sum.\n\n\nExample Input\nInput 1:\nA = 3\nB = 10\nInput 2:\n\nA = 6\nB = 1\n\n\nExample Output\nOutput 1:\n13\nOutput 2:\n\n7\n\n\nExample Explanation\nExplanation 1:\n3 + 10 = 13\nExplanation 2:\n\n6 + 1 = 7.\nNote, you have to add without using arithmetic operators.\n\n\n\nAnswer :-\n\n/**\n * @input A : Integer\n * @input B : Integer\n * \n * @Output Integer\n */\nint addNumbers(int A, int B) {\n    if(B==0){\n        return A;\n    }\n    if (B != 0) {\n        int carry = A & B;\n        A = A ^ B;\n        B = carry << 1;\n    }\n    return addNumbers(A,B);\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=N3dtzMKJMn8&pp=ygUnaW50ZXJ2aWV3Yml0IGFkZGl0aW9uIHdpdGhvdXQgc3VtbWF0aW9u',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
