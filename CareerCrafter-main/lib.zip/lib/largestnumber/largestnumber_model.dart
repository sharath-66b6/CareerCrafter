import '/flutter_flow/flutter_flow_util.dart';
import 'largestnumber_widget.dart' show LargestnumberWidget;
import 'package:flutter/material.dart';

class LargestnumberModel extends FlutterFlowModel<LargestnumberWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
