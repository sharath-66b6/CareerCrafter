import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'largestnumber_model.dart';
export 'largestnumber_model.dart';

class LargestnumberWidget extends StatefulWidget {
  const LargestnumberWidget({super.key});

  @override
  State<LargestnumberWidget> createState() => _LargestnumberWidgetState();
}

class _LargestnumberWidgetState extends State<LargestnumberWidget> {
  late LargestnumberModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => LargestnumberModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Largest Number',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 4000.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven a list of non-negative integers, arrange them such that they form the largest number.\nNote: The result may be very large, so you need to return a string instead of an integer.\n\n\nProblem Constraints\n1 <= |A| <= 105\n0 <= Ai <= 109\n\n\nInput Format\nThe first argument is an integer array A.\n\n\nOutput Format\nReturn a string representing the largest number formed\n\n\nExample Input\nA = [3, 30, 34, 5, 9]\n\n\nExample Output\n9534330\n\n\nExample Explanation\nLargest possible number that can be formed is 9534330\n\n\n\nAnswer :-\n/**\n * @input A : Read only ( DON\'T MODIFY ) Integer array\n * @input n1 : Integer array\'s ( A ) length\n * \n * @Output string. Make sure the string ends with null character\n * \n * \n */\n int comp (const void * elem1, const void * elem2) \n{\n    long f = (long)*((int*)elem1);\n    long s = (long)*((int*)elem2);\n    int counts = 1;\n    int countf = 1;\n    int temp;\n    temp = s;\n    int i;\n    while(1)\n    {\n        temp = temp/10;\n        counts = counts *10;\n    \n        if(temp ==0)\n        {\n            break;\n        }\n    }\n    temp = f;\n     while(1)\n    {\n        temp = temp/10;\n        countf = countf*10;\n    \n        if(temp ==0)\n        {\n            break;\n        }\n    }\n        \n    //printf(\"The two number f*pow(10,counts) + s = %d s*pow(10,countf) + f = %d \\n\", f*counts + s, s*countf + f);\n    \n    if (f*counts + s > s*countf + f) return 1;\n    if (f*counts + s < s*countf + f) return -1;\n    return 0;\n}\n \n \nchar* largestNumber(const int* A, int n1) {\n\n    int i = 0;\n\n    if(n1 > 1)\n    {\n        qsort (A, n1, sizeof(int), comp);    \n    }\n    \n    int flag = 0;\n    for(i = 0; i < n1; i++)\n    {\n        if(A[i] > 0)\n        {\n            flag = 1;\n        }\n    }\n\n    if(flag ==0)\n    {\n        char *s = (char *)malloc(2*sizeof(char));\n        s[0] = \'0\';\n        s[1] = \'\\0\';\n        return s;\n    }\n\n\n\n\n\n    // for(i = 0; i < n1; i++)\n    // {\n    //     printf(\"%d\\n\", A[i]);\n    // }\n    int counts[n1];\n    int count = 0;\n    int temp;\n    for(i = 0; i < n1; i++)\n    {\n        temp = A[i];\n        counts[i] = 0;\n        while(1)\n        {\n            temp = temp/10;\n            counts[i] = counts[i] + 1;\n            count = count + 1;\n            if(temp ==0)\n            {\n                break;\n            }\n        }\n    }\n    \n    char *result = (char *)malloc((count + 1)*(sizeof(char)));\n    int k = 0;\n    \n    for(i = n1-1; i >= 0; i--)\n    {\n        temp = A[i];\n        int temp2 = counts[i];\n        // printf(\"A[i] = %d, count = %d total count = %d \\n\", A[i], counts[i], count);\n        while(1)\n        {\n            result[k + counts[i] - 1] = \'0\' + temp%10; \n            \n            temp = temp/10;\n            counts[i] = counts[i] -1;\n            if(temp==0)\n            {\n                break;\n            }\n        }\n        k = k + temp2;\n            \n        \n    }\n    \n    // for(i = 0; i < count; i++)\n    // {\n    //     printf(\"%c\\n\", result[i]);\n    // }\n    \n    \n    // char *num[n1];\n    // int total_count = 0;\n    // for ( i = 0; i < n1; i++)\n    // {\n    //     int temp = A[i];\n    //     int count = 0;\n    //     while(temp > 0)\n    //     {\n    //         temp = temp/10;\n    //         count = count + 1;\n    //         total_count++;\n    //     }\n        \n    //     num[i] = ( char*)malloc(count*sizeof(char));\n    //     int j = 0;\n    //     temp = A[i];\n    //     for(j = count - 1; j >=0;j--)\n    //     {\n    //         num[i][j] = temp%10;\n    //         temp = temp/10;\n    //     }\n        \n    // }\n    // int rank[n1];\n    // for(i = 0; i < n1; i++)\n    // {\n    //     rank[i] = 0;\n    // }\n    \n    // for(i = 0; i < n1; i++)\n    // {\n    //     for(j = 0; j < n1-1; j++)\n    //     {\n    //         if(num[j][0] > num[rank[i]][0])\n    //         {\n    //             rank[i] = j;\n    //         }\n            \n    //         else if(num)\n    //     }\n    // }\n    result[count] =  \'\\0\';\n    return result;\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=WgPutbD3lu0&pp=ygUbaW50ZXJ2aWV3Yml0IGxhcmdlc3QgbnVtYmVy',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
