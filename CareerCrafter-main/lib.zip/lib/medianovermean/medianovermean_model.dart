import '/flutter_flow/flutter_flow_util.dart';
import 'medianovermean_widget.dart' show MedianovermeanWidget;
import 'package:flutter/material.dart';

class MedianovermeanModel extends FlutterFlowModel<MedianovermeanWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
