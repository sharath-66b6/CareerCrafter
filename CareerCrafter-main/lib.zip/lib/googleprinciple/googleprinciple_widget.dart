import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'googleprinciple_model.dart';
export 'googleprinciple_model.dart';

class GoogleprincipleWidget extends StatefulWidget {
  const GoogleprincipleWidget({super.key});

  @override
  State<GoogleprincipleWidget> createState() => _GoogleprincipleWidgetState();
}

class _GoogleprincipleWidgetState extends State<GoogleprincipleWidget> {
  late GoogleprincipleModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => GoogleprincipleModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).primary,
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30.0,
            borderWidth: 1.0,
            buttonSize: 60.0,
            icon: const Icon(
              Icons.arrow_back_rounded,
              color: Colors.white,
              size: 30.0,
            ),
            onPressed: () async {
              context.pop();
            },
          ),
          title: Text(
            'Google Principles',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: 'Outfit',
                  color: Colors.white,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                ),
          ),
          actions: const [],
          centerTitle: true,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: ListView(
            padding: const EdgeInsets.symmetric(vertical: 12.0),
            scrollDirection: Axis.vertical,
            children: [
              Container(
                width: 100.0,
                height: 900.0,
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryBackground,
                ),
                child: Align(
                  alignment: const AlignmentDirectional(0.0, -1.0),
                  child: Text(
                    'Overview\nWebsite\nabout.google\nFounded\n1998\n# Employees\n10K+\nAbout Google\nGoogle is an American multinational technology company that specializes in Internet-related services and products. Their products/services include online advertising technologies, a search engine, cloud computing, software, and hardware. Their products are used by billions of customers across the world. \n\nMission and Vision of Google\nGoogle\'s mission is to organise the world’s information and make it universally accessible and useful.\n\nValues and Principles of Google\nHere are the Ten things of Google.\n\nFocus on the user and all else will follow\nIt’s best to do one thing really, really well\nFast is better than slow\nDemocracy on the web works\nYou don’t need to be at your desk to need an answer\nYou can make money without doing evil\nThere’s always more information out there\nThe need for information crosses all borders\nYou can be serious without a suit\nGreat just isn’t good enough',
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Readex Pro',
                          letterSpacing: 0.0,
                        ),
                  ),
                ),
              ),
            ].divide(const SizedBox(height: 12.0)),
          ),
        ),
      ),
    );
  }
}
