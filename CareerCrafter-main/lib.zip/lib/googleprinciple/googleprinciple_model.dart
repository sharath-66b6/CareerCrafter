import '/flutter_flow/flutter_flow_util.dart';
import 'googleprinciple_widget.dart' show GoogleprincipleWidget;
import 'package:flutter/material.dart';

class GoogleprincipleModel extends FlutterFlowModel<GoogleprincipleWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
