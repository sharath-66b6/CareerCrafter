import '/flutter_flow/flutter_flow_util.dart';
import 'divideinteger_widget.dart' show DivideintegerWidget;
import 'package:flutter/material.dart';

class DivideintegerModel extends FlutterFlowModel<DivideintegerWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
