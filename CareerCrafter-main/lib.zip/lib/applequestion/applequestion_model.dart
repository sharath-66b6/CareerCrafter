import '/flutter_flow/flutter_flow_util.dart';
import 'applequestion_widget.dart' show ApplequestionWidget;
import 'package:flutter/material.dart';

class ApplequestionModel extends FlutterFlowModel<ApplequestionWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
