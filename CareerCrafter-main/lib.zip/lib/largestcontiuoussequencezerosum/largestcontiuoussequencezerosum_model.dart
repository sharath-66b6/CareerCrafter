import '/flutter_flow/flutter_flow_util.dart';
import 'largestcontiuoussequencezerosum_widget.dart'
    show LargestcontiuoussequencezerosumWidget;
import 'package:flutter/material.dart';

class LargestcontiuoussequencezerosumModel
    extends FlutterFlowModel<LargestcontiuoussequencezerosumWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
