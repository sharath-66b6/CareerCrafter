import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'largestcontiuoussequencezerosum_model.dart';
export 'largestcontiuoussequencezerosum_model.dart';

class LargestcontiuoussequencezerosumWidget extends StatefulWidget {
  const LargestcontiuoussequencezerosumWidget({super.key});

  @override
  State<LargestcontiuoussequencezerosumWidget> createState() =>
      _LargestcontiuoussequencezerosumWidgetState();
}

class _LargestcontiuoussequencezerosumWidgetState
    extends State<LargestcontiuoussequencezerosumWidget> {
  late LargestcontiuoussequencezerosumModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => LargestcontiuoussequencezerosumModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Largest Continuous Sequence Zero Sum',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\n Given an array A of N integers.\n\nFind the largest continuous sequence in a array which sums to zero.\n\n\n\nProblem Constraints\n1 <= N <= 106\n\n -107 <= A[i] <= 107\n\n\n\nInput Format\nSingle argument which is an integer array A.\n\n\n\nOutput Format\nReturn an array denoting the longest continuous sequence with total sum of zero.\n\nNOTE : If there are multiple correct answers, return the sequence which occurs first in the array.\n\n\n\nExample Input\nA = [1,2,-2,4,-4]\n\n\nExample Output\n[2,-2,4,-4]\n\n\nExample Explanation\n[2,-2,4,-4] is the longest sequence with total sum of zero.\n\n\n\nAnswer :-\n\n\n/**\n * @input A : Integer array\n * @input n1 : Integer array\'s ( A ) length\n * \n * @Output Integer array. You need to malloc memory, and fill the length in len1\n */\n typedef struct _unit_t {\n     int idx;\n     int sum;\n } unit_t;\n \n int compare(void *a, void *b) {\n     unit_t *u_a = (unit_t *)a;\n     unit_t *u_b = (unit_t *)b;\n     if (u_a->sum > u_b->sum)\n        return 1;\n     if (u_a->sum < u_b->sum)\n        return -1;\n     return u_a->idx - u_b->idx;\n }\nint* lszero(int* A, int n1, int *len1) {\n    int i, j, k, sum, max_l, start, end;\n    int *ret = (int *)malloc(sizeof(int) * n1);\n    unit_t *units = (unit_t *)malloc(sizeof(unit_t) * n1);\n    sum = 0;\n    for (i = 0; i < n1; i++) {\n       sum += A[i];\n       units[i].idx = i;\n       units[i].sum = sum;\n    }\n    qsort(units, n1, sizeof(unit_t), compare);\n    \n    max_l = INT_MIN;\n    i = 0;\n    while (i < n1) {\n        if (units[i].sum == 0) {\n            if (units[i].idx + 1>= max_l) {\n                start = 0;\n                end = units[i].idx;\n                max_l = end - start + 1;\n            } \n        } else {\n            j = i + 1;\n            while(j < n1 && units[j].sum == units[i].sum)\n                j++;\n            if (j > i + 1) {\n                j--;\n                if (units[j].idx - units[i].idx > max_l) {\n                    start = units[i].idx + 1;\n                    end = units[j].idx;\n                    max_l = end -start + 1;\n                } else if (units[j].idx - units[i].idx == max_l) {\n                    if (units[i].idx + 1 < start) {\n                        start = units[i].idx + 1;\n                        end = units[j].idx;\n                    }\n                }\n                i = j;\n            }\n        }\n        i++;\n    }\n    if (max_l < 0) {\n        *len1 = 0;\n        return NULL;\n    }\n    *len1 = end - start + 1;\n    k = 0;\n    for (i = start; i <= end; i++) {\n        ret[k++] = A[i];\n    }\n    return ret;\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=_UULScn5ni8&pp=ygUxaW50ZXJ2aWV3Yml0IGxhcmdlc3QgY29udGludW91cyBzZXF1ZW5jZSB6ZXJvIHN1bQ%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
