import '/flutter_flow/flutter_flow_util.dart';
import 'kthnodefrommiddle_widget.dart' show KthnodefrommiddleWidget;
import 'package:flutter/material.dart';

class KthnodefrommiddleModel extends FlutterFlowModel<KthnodefrommiddleWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
