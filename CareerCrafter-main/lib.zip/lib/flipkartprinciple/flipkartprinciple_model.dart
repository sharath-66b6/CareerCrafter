import '/flutter_flow/flutter_flow_util.dart';
import 'flipkartprinciple_widget.dart' show FlipkartprincipleWidget;
import 'package:flutter/material.dart';

class FlipkartprincipleModel extends FlutterFlowModel<FlipkartprincipleWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
