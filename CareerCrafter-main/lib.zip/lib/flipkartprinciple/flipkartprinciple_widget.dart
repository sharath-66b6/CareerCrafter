import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'flipkartprinciple_model.dart';
export 'flipkartprinciple_model.dart';

class FlipkartprincipleWidget extends StatefulWidget {
  const FlipkartprincipleWidget({super.key});

  @override
  State<FlipkartprincipleWidget> createState() =>
      _FlipkartprincipleWidgetState();
}

class _FlipkartprincipleWidgetState extends State<FlipkartprincipleWidget> {
  late FlipkartprincipleModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => FlipkartprincipleModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).primary,
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30.0,
            borderWidth: 1.0,
            buttonSize: 60.0,
            icon: const Icon(
              Icons.arrow_back_rounded,
              color: Colors.white,
              size: 30.0,
            ),
            onPressed: () async {
              context.pop();
            },
          ),
          title: Text(
            'Flipkart Principles',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: 'Outfit',
                  color: Colors.white,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                ),
          ),
          actions: const [],
          centerTitle: true,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: ListView(
            padding: const EdgeInsets.symmetric(vertical: 12.0),
            scrollDirection: Axis.vertical,
            children: [
              Container(
                width: 100.0,
                height: 900.0,
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryBackground,
                ),
                child: Align(
                  alignment: const AlignmentDirectional(0.0, -1.0),
                  child: Text(
                    'Overview\nWebsite\nflipkart.com\nFounded\n2007\n# Employees\n10K - 50K\nLocation (s)\nBengaluru\nAbout Flipkart\nThe Flipkart Group is one of India’s leading digital commerce entities and includes group companies Flipkart, Myntra, and Jabong.\n\nLaunched in 2007, Flipkart has enabled millions of consumers, sellers, merchants and small businesses to be a part of India’s e-commerce revolution. With a registered customer base of over 100 million, offering over 80 million products across 80+ categories,\n\nFlipkart is known for pioneering services such as Cash on Delivery, No Cost EMI and easy returns – customer-centric innovations that have made online shopping more accessible and affordable for millions of Indians. Together with Myntra and Jabong, which hold prominent positions in the online fashion market, the Flipkart Group has steered the transformation of commerce in India through technology.\n\nValues and Principles of Flipkart\nWhile we adapt, evolve, and continue to grow, the beliefs that are most important to us stay the same - Audacity, Bias for Action, and Customer First - our core values which are reflected in everything we do!\n\nWhile these core values define our identity and form the basis of all our decisions and actions, integrity and inclusion underpins all our processes.',
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Readex Pro',
                          letterSpacing: 0.0,
                        ),
                  ),
                ),
              ),
            ].divide(const SizedBox(height: 12.0)),
          ),
        ),
      ),
    );
  }
}
