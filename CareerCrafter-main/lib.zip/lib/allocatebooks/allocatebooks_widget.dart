import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'allocatebooks_model.dart';
export 'allocatebooks_model.dart';

class AllocatebooksWidget extends StatefulWidget {
  const AllocatebooksWidget({super.key});

  @override
  State<AllocatebooksWidget> createState() => _AllocatebooksWidgetState();
}

class _AllocatebooksWidgetState extends State<AllocatebooksWidget> {
  late AllocatebooksModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => AllocatebooksModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Allocate Books',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2200.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven an array of integers A of size N and an integer B.\n\nThe College library has N books. The ith book has A[i] number of pages.\n\nYou have to allocate books to B number of students so that the maximum number of pages allocated to a student is minimum.\n\nA book will be allocated to exactly one student.\nEach student has to be allocated at least one book.\nAllotment should be in contiguous order, for example: A student cannot be allocated book 1 and book 3, skipping book 2.\nCalculate and return that minimum possible number.\n\nNOTE: Return -1 if a valid assignment is not possible.\n\n\n\nProblem Constraints\n1 <= N <= 105\n 1 <= A[i], B <= 105\n\n\n\nInput Format\nThe first argument given is the integer array A.\nThe second argument given is the integer B.\n\n\n\nOutput Format\nReturn that minimum possible number.\n\n\n\nExample Input\nInput 1:\nA = [12, 34, 67, 90]\nB = 2\nInput 2:\nA = [5, 17, 100, 11]\nB = 4\n\n\nExample Output\nOutput 1:\n113\nOutput 2:\n100\n\n\nExample Explanation\nExplanation 1:\nThere are two students. Books can be distributed in following fashion : \n1)  [12] and [34, 67, 90]\n    Max number of pages is allocated to student 2 with 34 + 67 + 90 = 191 pages\n2)  [12, 34] and [67, 90]\n    Max number of pages is allocated to student 2 with 67 + 90 = 157 pages \n3)  [12, 34, 67] and [90]\n    Max number of pages is allocated to student 1 with 12 + 34 + 67 = 113 pages\n    Of the 3 cases, Option 3 has the minimum pages = 113.\n\n\nAnswer :- \n\n/**\n * @input A : Integer array\n * @input n1 : Integer array\'s ( A ) length\n * @input B : Integer\n * \n * @Output Integer\n */\nint books(int* C, int n3, int A) {\n    if(A>n3)\n    return -1;\n    \n    int i,paint,x;\n    long long int lo=-1,hi;\n   long long int required = 1, boards = 0;\n   for(i=0;i<n3;++i){\n      if(lo<C[i])\n        lo=C[i];\n      hi+=C[i];\n   }\n\n   while ( lo < hi ) {\n      x = lo + (hi-lo)/2;\n\n      required = 1, boards = 0;\n      for ( i=0; i<n3; ++i ) {\n         if ( boards + C[i] <= x ) {\n            boards += C[i];\n         }\n         else {\n            ++required;\n            boards = C[i];               \n         }\n      }\n\n      if ( required <= A )\n         hi = x;\n      else\n         lo = x+1;\n   }\n\n   return hi;\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=gYmWHvRHu-s&pp=ygUbaW50ZXJ2aWV3Yml0IGFsbG9jYXRlIGJvb2tz',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
