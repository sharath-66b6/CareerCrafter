import '/flutter_flow/flutter_flow_util.dart';
import 'allocatebooks_widget.dart' show AllocatebooksWidget;
import 'package:flutter/material.dart';

class AllocatebooksModel extends FlutterFlowModel<AllocatebooksWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
