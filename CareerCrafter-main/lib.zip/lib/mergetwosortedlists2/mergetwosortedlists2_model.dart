import '/flutter_flow/flutter_flow_util.dart';
import 'mergetwosortedlists2_widget.dart' show Mergetwosortedlists2Widget;
import 'package:flutter/material.dart';

class Mergetwosortedlists2Model
    extends FlutterFlowModel<Mergetwosortedlists2Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
