import '/flutter_flow/flutter_flow_util.dart';
import 'maxproductsubarray_widget.dart' show MaxproductsubarrayWidget;
import 'package:flutter/material.dart';

class MaxproductsubarrayModel
    extends FlutterFlowModel<MaxproductsubarrayWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
