import '/flutter_flow/flutter_flow_util.dart';
import 'largestareaofrectangle_widget.dart' show LargestareaofrectangleWidget;
import 'package:flutter/material.dart';

class LargestareaofrectangleModel
    extends FlutterFlowModel<LargestareaofrectangleWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
