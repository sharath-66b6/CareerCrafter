import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'largestareaofrectangle_model.dart';
export 'largestareaofrectangle_model.dart';

class LargestareaofrectangleWidget extends StatefulWidget {
  const LargestareaofrectangleWidget({super.key});

  @override
  State<LargestareaofrectangleWidget> createState() =>
      _LargestareaofrectangleWidgetState();
}

class _LargestareaofrectangleWidgetState
    extends State<LargestareaofrectangleWidget> {
  late LargestareaofrectangleModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => LargestareaofrectangleModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Largest area of rectangle with permutations',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2500.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven a binary grid A of size N x M consisting of 0\'s and 1\'s, find the area of the largest rectangle inside the grid such that all the cells inside the chosen rectangle should have 1 in them.\n\nYou are allowed to permutate the columns matrix i.e. you can arrange each of the column in any order in the final grid.\n\nPlease follow the sample input and explanation for more clarity.\n\n\n\nProblem Constraints\n1 <= N, M <= 103\n\n\nInput Format\nFirst and only argument is an 2D binary array A.\n\n\n\nOutput Format\nReturn a single integer denoting the area of the largest rectangle inside the grid such that all the cells inside the chosen rectangle should have 1 in them.\n\n\n\nExample Input\nInput 1:\n\n A = [  [1, 0, 1]\n        [0, 1 ,0]\n        [1, 0, 0]\n    ]\n\n\nExample Output\nOutput 1:\n\n 2\n\n\nExample Explanation\nExplanation 1:\n\n    1 0 1\n    0 1 0\n    1 0 0\n\n\nAt present we can see that max rectangle satisfying the criteria mentioned in the problem\n is of 1 * 1 = 1 area i.e either of the 4 cells which contain 1 in it.\n\n\n\nNow since we are allowed to permutate the columns of the given matrix, we can take column 1\n and column 3 and make them neighbours. One of the possible configuration of the grid can be:\n 1 1 0\n 0 0 1\n 1 0 0\n\n\n\nNow In this grid, first column is column 1, second column is column 3 and third column\n is column 2 from the original given grid.\n\n\n\nNow, we can see that if we calculate the max area rectangle, we get max area as 1 * 2 = 2\n which is bigger than the earlier case. Hence 2 will be the answer in this case.\n\n\nAnswer :-\n/**\n * @input A : 2D integer array \n * @input n11 : Integer array\'s ( A ) rows\n * @input n12 : Integer array\'s ( A ) columns\n * \n * @Output Integer\n */\nint solve(int** A, int n11, int n12) {\n    int i,j,k,max,freq[n11+1];\n    int dp[n11][n12];\n    for(i=0;i<n12;i++){\n        if(A[0][i]==1)\n            dp[0][i]=1;\n        else\n            dp[0][i]=0;    \n    }\n    for(i=0;i<n12;i++){\n        for(j=1;j<n11;j++){\n            if(A[j][i]==1)\n                dp[j][i]=dp[j-1][i]+1;\n        \n            else\n                dp[j][i]=0;\n        }\n    }\n    max=0;\n    for(i=0;i<n11;i++){\n        for(j=0;j<=n11;j++){\n            freq[j]=0;\n        }\n        for(j=0;j<n12;j++){\n            freq[dp[i][j]]++;\n        }\n        for(j=n11-1;j>0;j--){\n            freq[j]+=freq[j+1];\n        }\n        for(j=n11;j>0;j--){\n            if(max<(freq[j]*j))\n                max=freq[j]*j;\n        }\n    }\n    return max;\n}\n\n\n\n\n\n\n\n\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=9vYCQLYF6ng&pp=ygU3aW50ZXJ2aWV3Yml0IGxhcmdlc3QgYXJlYSBvZiByZWN0YW5nbGUgd2l0aCBwZXJtdXRhdGlvbg%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
