import '/flutter_flow/flutter_flow_util.dart';
import 'hotelreviews_widget.dart' show HotelreviewsWidget;
import 'package:flutter/material.dart';

class HotelreviewsModel extends FlutterFlowModel<HotelreviewsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
