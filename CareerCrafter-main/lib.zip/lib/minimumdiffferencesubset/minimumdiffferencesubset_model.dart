import '/flutter_flow/flutter_flow_util.dart';
import 'minimumdiffferencesubset_widget.dart'
    show MinimumdiffferencesubsetWidget;
import 'package:flutter/material.dart';

class MinimumdiffferencesubsetModel
    extends FlutterFlowModel<MinimumdiffferencesubsetWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
