import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'minimumdiffferencesubset_model.dart';
export 'minimumdiffferencesubset_model.dart';

class MinimumdiffferencesubsetWidget extends StatefulWidget {
  const MinimumdiffferencesubsetWidget({super.key});

  @override
  State<MinimumdiffferencesubsetWidget> createState() =>
      _MinimumdiffferencesubsetWidgetState();
}

class _MinimumdiffferencesubsetWidgetState
    extends State<MinimumdiffferencesubsetWidget> {
  late MinimumdiffferencesubsetModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MinimumdiffferencesubsetModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Minimum Difference Subsets!',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2200.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nGiven an integer array A containing N integers.\n\nYou need to divide the array A into two subsets S1 and S2 such that the absolute difference between their sums is minimum.\n\nFind and return this minimum possible absolute difference.\n\nNOTE:\n\nSubsets can contain elements from A in any order (not necessary to be contiguous).\nEach element of A should belong to any one subset S1 or S2, not both.\nIt may be possible that one subset remains empty.\n\n\nProblem Constraints\n1 <= N <= 100\n\n1 <= A[i] <= 100\n\n\n\nInput Format\nFirst and only argument is an integer array A.\n\n\n\nOutput Format\nReturn an integer denoting the minimum possible difference among the sums of two subsets.\n\n\n\nExample Input\nInput 1:\n\n A = [1, 6, 11, 5]\n\n\nExample Output\nOutput 1:\n\n 1\n\n\nExample Explanation\nExplanation 1:\n\n Subset1 = {1, 5, 6}, sum of Subset1 = 12\n Subset2 = {11}, sum of Subset2 = 11\n\n\n\n\nAnswer :-\n/**\n * @input A : Integer array\n * @input n1 : Integer array\'s ( A ) length\n * \n * @Output Integer\n */\n #include<stdint.h>\nint solve(int* A, int n1) {\n    int range=0;\n    int i=0;\n    for(i=0;i<n1;i++)\n    {\n        range=range+A[i];\n    }\n    int t[n1+1][range+1];\n    int j=0;\n    for(i=0;i<n1+1;i++)\n    {\n        for(j=0;j<range+1;j++)\n        {\n            if(j==0)\n            {\n                t[i][0]=1;\n            }\n            else if(i==0)\n            {\n                t[0][j]=0;\n            }\n            else if(A[i-1]<=j)\n            {\n                t[i][j]=(t[i-1][j]||t[i-1][j-A[i-1]]);\n            }\n            else if(A[i-1]>j)\n            {\n                t[i][j]=t[i-1][j];\n            }\n        }\n    }\n    int temp;\n    int min=INT_MAX;\n    for(j=0;j<range+1;j++)\n    {\n        if(t[n1][j]==1)\n        {\n            temp=range-2*j;\n            if(temp<min&&temp>=0)\n            {\n                min=temp;\n            }\n        }\n    }\n    return min;\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=FB0KUhsxXGY&pp=ygUnaW50ZXJ2aWV3Yml0IG1pbmltdW0gZGlmZmVyZW5jZSBzdWJzZXRz',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
