import '/flutter_flow/flutter_flow_util.dart';
import 'mindepthofbinarytree_widget.dart' show MindepthofbinarytreeWidget;
import 'package:flutter/material.dart';

class MindepthofbinarytreeModel
    extends FlutterFlowModel<MindepthofbinarytreeWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
