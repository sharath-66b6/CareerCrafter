import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'distinctsubsequence_model.dart';
export 'distinctsubsequence_model.dart';

class DistinctsubsequenceWidget extends StatefulWidget {
  const DistinctsubsequenceWidget({super.key});

  @override
  State<DistinctsubsequenceWidget> createState() =>
      _DistinctsubsequenceWidgetState();
}

class _DistinctsubsequenceWidgetState extends State<DistinctsubsequenceWidget> {
  late DistinctsubsequenceModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => DistinctsubsequenceModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Distinct Subsequences',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1600.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \nGiven two sequences A, B, count number of unique ways in sequence A, to form a subsequence that is identical to the sequence B.\n\nSubsequence : A subsequence of a string is a new string which is formed from the original string by deleting some (can be none) of the characters without disturbing the relative positions of the remaining characters. (ie, “ACE” is a subsequence of “ABCDE” while “AEC” is not).\n\nInput Format:\n\nThe first argument of input contains a string, A.\nThe second argument of input contains a string, B.\nOutput Format:\n\nReturn an integer representing the answer as described in the problem statement.\nConstraints:\n\n1 <= length(A), length(B) <= 700\nExample :\n\nInput 1:\n    A = \"abc\"\n    B = \"abc\"\n    \nOutput 1:\n    1\n\nExplanation 1:\n    Both the strings are equal.\n\nInput 2:\n    A = \"rabbbit\" \n    B = \"rabbit\"\n\nOutput 2:\n    3\n\nExplanation 2:\n    These are the possible removals of characters:\n        => A = \"ra_bbit\" \n        => A = \"rab_bit\" \n        => A = \"rabb_it\"\n        \n    Note: \"_\" marks the removed character.\n\n\n\n\n\nAnswer :-\n/**\n * @input S : String termination by \'\\0\' \n * @input T : String termination by \'\\0\'\n * @Output Integer\n */\nint numDistinct(char* S, char* T) {\n    int m = strlen(S);\n    int n = strlen(T);\n    \n    int dp[m+1][n+1];\n    int i,j;\n    memset(dp,0,sizeof dp);\n    for(i=0;i<=m;i++) {\n        dp[i][0]=1;\n    }\n    for(i=1;i<=m;i++){\n        for(j=1;j<=n;j++) {\n            dp[i][j] = dp[i-1][j];\n            if(S[i-1] == T[j-1]) {\n                dp[i][j] += dp[i-1][j-1];\n            }\n        }\n    }\n    return dp[m][n];\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=aV-OEO-eNJQ&pp=ygUiaW50ZXJ2aWV3Yml0IGRpc3RpbmN0IHN1YnNlcXVlbmNlcw%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
