import '/flutter_flow/flutter_flow_util.dart';
import 'distinctsubsequence_widget.dart' show DistinctsubsequenceWidget;
import 'package:flutter/material.dart';

class DistinctsubsequenceModel
    extends FlutterFlowModel<DistinctsubsequenceWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
