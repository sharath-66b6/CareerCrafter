import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'kthsmallestelemetintree_model.dart';
export 'kthsmallestelemetintree_model.dart';

class KthsmallestelemetintreeWidget extends StatefulWidget {
  const KthsmallestelemetintreeWidget({super.key});

  @override
  State<KthsmallestelemetintreeWidget> createState() =>
      _KthsmallestelemetintreeWidgetState();
}

class _KthsmallestelemetintreeWidgetState
    extends State<KthsmallestelemetintreeWidget> {
  late KthsmallestelemetintreeModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => KthsmallestelemetintreeModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Kth Smallest Element In Tree',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2000.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven a binary search tree, write a function to find the kth smallest element in the tree.\nNOTE: You may assume 1 <= k <= Total number of nodes in BST\n\n\nInput Format\nThe first argument is the root node of the binary tree.\nThe second argument B is an integer equal to the value of k.\n\n\nOutput Format\nReturn the value of the kth smallest node.\n\n\nExample Input\n  2\n / \\\n1   3\n\n\nand k = 2\n\n\n\nExample Output\n2\n\n\nExample Explanation\nAs 2 is the second smallest element in the tree.\n\n\n\n\n\nAnswer :-\n/**\n * Definition for binary tree\n * struct TreeNode {\n *     int val;\n *     struct TreeNode *left;\n *     struct TreeNode *right;\n * };\n * \n * typedef struct TreeNode treenode;\n * \n * treenode* treenode_new(int val) {\n *     treenode* node = (treenode *) malloc(sizeof(treenode));\n *     node->val = val;\n *     node->left = NULL;\n *     node->right = NULL;\n *     return node;\n * }\n */\n/**\n * @input A : Root pointer of the tree \n * @input B : Integer\n * \n * @Output Integer\n */\nint ind;\nint required;\nint element;\nint flag = 0;\n\nvoid traversal(treenode *node) {\n    if(node == NULL)\n        return;\n    if(flag == 1)\n        return;\n    traversal(node->left);\n    if(flag == 1)\n        return;\n    ind += 1;\n    if (ind == required) {\n        flag = 1;\n        element = node->val; \n        return element;\n    }\n    if(flag == 1)\n        return;\n    traversal(node->right);\n}\n \nint kthsmallest(treenode* A, int B) {\n    if(B == 0)\n        return -1;\n    flag = 0;\n    ind = 0;\n    required = B;\n    traversal(A);\n    if(flag == 0)\n        return -1;\n    return element;\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=5R9_qgIV98s&pp=ygUpaW50ZXJ2aWV3Yml0IGt0aCBzbWFsbGVzdCBlbGVtZW50IGluIHRyZWU%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
