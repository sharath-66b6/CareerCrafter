import '/flutter_flow/flutter_flow_util.dart';
import 'kthsmallestelemetintree_widget.dart' show KthsmallestelemetintreeWidget;
import 'package:flutter/material.dart';

class KthsmallestelemetintreeModel
    extends FlutterFlowModel<KthsmallestelemetintreeWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
