import '/flutter_flow/flutter_flow_util.dart';
import 'iosdev_widget.dart' show IosdevWidget;
import 'package:flutter/material.dart';

class IosdevModel extends FlutterFlowModel<IosdevWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
