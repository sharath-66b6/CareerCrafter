import '/flutter_flow/flutter_flow_util.dart';
import 'medianoferror_widget.dart' show MedianoferrorWidget;
import 'package:flutter/material.dart';

class MedianoferrorModel extends FlutterFlowModel<MedianoferrorWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
