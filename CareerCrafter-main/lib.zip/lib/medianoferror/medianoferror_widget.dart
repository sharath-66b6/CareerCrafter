import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'medianoferror_model.dart';
export 'medianoferror_model.dart';

class MedianoferrorWidget extends StatefulWidget {
  const MedianoferrorWidget({super.key});

  @override
  State<MedianoferrorWidget> createState() => _MedianoferrorWidgetState();
}

class _MedianoferrorWidgetState extends State<MedianoferrorWidget> {
  late MedianoferrorModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MedianoferrorModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Median of Array',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1500.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nThere are two sorted arrays A and B of size m and n respectively.\n\nFind the median of the two sorted arrays ( The median of the array formed by merging both arrays ).\n\nThe overall run time complexity should be O(log (m+n)).\n\nNOTE: If the number of elements in the merged array is even, then the median is the average of n / 2 th and n/2 + 1th element. For example, if the array is [1 2 3 4], the median is (2 + 3) / 2.0 = 2.5 \n\n\nProblem Constraints\n0 <= |A| <= 106\n0 <= |B| <= 106\n1 <= |A| + |B| <= 2 * 106\n\n\nInput Format\nThe first argument is an integer array A.\nThe second argument is an integer array B.\n\n\nOutput Format\nReturn a double value equal to the median.\n\n\nExample Input\nA : [1 4 5]\nB : [2 3]\n\n\nExample Output\n3\n\n\nExample Explanation\nMerged A and B will be : [1, 2, 3, 4, 5]\nIts median will be 3\n\n\n\nAnswer:- \nint min(int a,int b){\n     if(a<b)\n      return a;\n     return b;\n }\n\n double fms(const int *A, int m,const int *B, int n, int k){\n         \n        if (m>n) {return fms(B,n,A,m,k);}\n         \n        if (m==0) { return B[k-1];}\n        if (k==1) { return min(A[0],B[0]);}\n        int pa = min(k/2,m);\n        int pb = k-pa;\n        if (A[pa-1]<=B[pb-1]) {return fms(A+pa,m-pa,B,n,k-pa);}\n        return fms(A,m,B+pb,n-pb,k-pb);\n    }\ndouble findMedianSortedArrays(const int* A, int n1, const int* B, int n2) {\n    int total = n1+n2;\n    if(total%2==1)\n     return fms(A,n1,B,n2,total/2+1);\n    else\n    return ((fms(A,n1,B,n2,total/2)+fms(A,n1,B,n2,total/2+1))/2);\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=fh4QNKV1-yI&pp=ygUcaW50ZXJ2aWV3Yml0IG1lZGlhbiBvZiBhcnJheQ%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
