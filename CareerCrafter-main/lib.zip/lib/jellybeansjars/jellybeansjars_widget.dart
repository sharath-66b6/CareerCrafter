import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'jellybeansjars_model.dart';
export 'jellybeansjars_model.dart';

class JellybeansjarsWidget extends StatefulWidget {
  const JellybeansjarsWidget({super.key});

  @override
  State<JellybeansjarsWidget> createState() => _JellybeansjarsWidgetState();
}

class _JellybeansjarsWidgetState extends State<JellybeansjarsWidget> {
  late JellybeansjarsModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => JellybeansjarsModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Jelly Beans Jars',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1000.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'You have three jars that are all mislabeled. One contains peanut butter jelly beans, another grape jelly jelly beans and the third has a mix of both (not necessarily half-half mix).\n\nHow many minimum jelly beans would you have to pull out to find out how to fix the labels on the jars?\n\nLabels on jars are as follows\n\nJar 1 : Peanut butter\nJar 2 : Grape\nJar 3 : P.b. / Grape\nAnswer is a integer.  Just put the number without any decimal places if its an integer. If the answer is Infinity, output Infinity.\n\nAnswer :-\nOnly one jelly bean from the p.b./grape jar will do the trick.The trick here is to realize that every jar is mislabeled. Therefore you know that the peanut butter jelly bean jar is not the peanut butter jelly bean jar and the same goes for the rest.\n\nYou also need to realize that it is the jar labeled p.b./grape, labelled as the mix jar, that is your best hope. If you choose a jelly bean out of there, then you will know whether that jar is peanut butter or grape jelly jelly beans. It can’t be the mix jar because i already said that every jar is mislabeled.\n\nOnce you know that jar 3 is either peanut butter, or grape jelly, then you know the other jars also. If it is peanut butter, then jar 2 must be mixed because it can’t be grape (as its labeled) and it can’t be peanut butter (that’s jar 3). Hence jar 1 is grape.\n\nIf jar 3 is grape, then you know jar 1 must be the mix because it can’t be p.b. (as its labeled) and it can’t be grape (that’s jar 3). Hence jar 2 is peanut butter.',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=Ih3PvWxneNg&pp=ygUdaW50ZXJ2aWV3Yml0IGplbGx5IGJlYW5zIGphcnM%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
