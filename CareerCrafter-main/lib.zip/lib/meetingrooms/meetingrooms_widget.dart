import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'meetingrooms_model.dart';
export 'meetingrooms_model.dart';

class MeetingroomsWidget extends StatefulWidget {
  const MeetingroomsWidget({super.key});

  @override
  State<MeetingroomsWidget> createState() => _MeetingroomsWidgetState();
}

class _MeetingroomsWidgetState extends State<MeetingroomsWidget> {
  late MeetingroomsModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MeetingroomsModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Meeting rooms',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 3200.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven an 2D integer array A of size N x 2 denoting time intervals of different meetings.\n\n \n\nWhere:\n\n \n\nA[i][0] = start time of the ith meeting.\nA[i][1] = end time of the ith meeting.\n \n\nFind the minimum number of conference rooms required so that all meetings can be done.\n\nNote :- If a meeting ends at time t, another meeting starting at time t can use the same conference room\n\n \n\n\n\nProblem Constraints\n1 <= N <= 105\n\n \n\n0 <= A[i][0] < A[i][1] <= 2 * 109\n\n \n\n\n\nInput Format\nThe only argument given is the matrix A.\n\n\n\nOutput Format\nReturn the minimum number of conference rooms required so that all meetings can be done.\n\n\n\nExample Input\nInput 1:\n\n A = [      [0, 30]\n            [5, 10]\n            [15, 20]\n     ]\n\nInput 2:\n\n A =  [     [1, 18]\n            [18, 23]\n            [15, 29]\n            [4, 15]\n            [2, 11]\n            [5, 13]\n      ]\n\n\nExample Output\nOutput 1:\n\n 2\nOutput 2:\n\n 4\n\n\nExample Explanation\nExplanation 1:\n\n Meeting one can be done in conference room 1 form 0 - 30.\n Meeting two can be done in conference room 2 form 5 - 10.\n Meeting three can be done in conference room 2 form 15 - 20 as it is free in this interval.\nExplanation 2:\n\n Meeting one can be done in conference room 1 from 1 - 18.\n Meeting five can be done in conference room 2 from 2 - 11.\n Meeting four can be done in conference room 3 from 4 - 15.\n Meeting six can be done in conference room 4 from 5 - 13.\n Meeting three can be done in conference room 2 from 15 - 29 as it is free in this interval.\n Meeting two can be done in conference room 4 from 18 - 23 as it is free in this interval.\n\n\n\n\n\nAnswer :-\n/**\n * @input A : 2D integer array \n * @input n11 : Integer array\'s ( A ) rows\n * @input n12 : Integer array\'s ( A ) columns\n * \n * @Output Integer\n */\nvoid merge(int*a,int*b,int*c,int m,int n)\n{\n    int i=0,j=0,k=0;\n    while(i<m&&j<n)\n    {\n        if(a[i]<b[j])\n         c[k++]=a[i++];\n        else c[k++]=b[j++];\n    }\n    while(i<m) c[k++]=a[i++];\n    while(j<n) c[k++]=b[j++];\n}\nvoid mergesort(int*a,int n)\n{\n    if(n<=1)\n     return;\n    int*b=(int*)malloc(n*sizeof(int));\n    int i,j;\n    i=n/2;\n    mergesort(a,i);\n    mergesort(a+i,n-i);\n    merge(a,a+i,b,i,n-i);\n    for(j=0;j<n;j++)\n     a[j]=b[j];\n    free(b);\n}\nint solve(int** A, int n11, int n12) {\n    //int a[n11*3],k=0;\n    int i,j,b[n11],c[n11];\n    for(i=0;i<n11;i++)\n     {\n         //a[k++]=A[i][0];\n         //a[k++]=A[i][1];\n         b[i]=A[i][0];\n         c[i]=A[i][1];\n     }\n    //mergesort(a,k);\n    mergesort(b,n11);\n    mergesort(c,n11);\n    //return k;\n    int ans=0;\n    i=0;\n    j=0;\n    while(i<n11&&j<n11)\n     {\n         if(b[i]<c[j])\n          {\n              ans++;\n              i++;\n          }\n         else {\n             i++;\n             j++;\n         }\n     }\n    return ans;\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=s8oOsWGHIl4&pp=ygUaaW50ZXJ2aWV3Yml0IG1lZXRpbmcgcm9vbXM%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
