import '/flutter_flow/flutter_flow_util.dart';
import 'meetingrooms_widget.dart' show MeetingroomsWidget;
import 'package:flutter/material.dart';

class MeetingroomsModel extends FlutterFlowModel<MeetingroomsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
