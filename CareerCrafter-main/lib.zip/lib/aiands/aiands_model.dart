import '/flutter_flow/flutter_flow_util.dart';
import 'aiands_widget.dart' show AiandsWidget;
import 'package:flutter/material.dart';

class AiandsModel extends FlutterFlowModel<AiandsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
