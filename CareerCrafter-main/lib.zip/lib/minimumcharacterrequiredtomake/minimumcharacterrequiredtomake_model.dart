import '/flutter_flow/flutter_flow_util.dart';
import 'minimumcharacterrequiredtomake_widget.dart'
    show MinimumcharacterrequiredtomakeWidget;
import 'package:flutter/material.dart';

class MinimumcharacterrequiredtomakeModel
    extends FlutterFlowModel<MinimumcharacterrequiredtomakeWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
