import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'minimumcharacterrequiredtomake_model.dart';
export 'minimumcharacterrequiredtomake_model.dart';

class MinimumcharacterrequiredtomakeWidget extends StatefulWidget {
  const MinimumcharacterrequiredtomakeWidget({super.key});

  @override
  State<MinimumcharacterrequiredtomakeWidget> createState() =>
      _MinimumcharacterrequiredtomakeWidgetState();
}

class _MinimumcharacterrequiredtomakeWidgetState
    extends State<MinimumcharacterrequiredtomakeWidget> {
  late MinimumcharacterrequiredtomakeModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MinimumcharacterrequiredtomakeModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Minimum Characters required to make a String Palindromic',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1500.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven a string A. The only operation allowed is to insert characters at the beginning of the string.\nFind how many minimum characters are needed to be inserted to make the string a palindrome string.\n\n\nProblem Constraints\n1 <= |A| <= 106\n\n\nInput Format\nThe only argument given is string A.\n\n\nOutput Format\nReturn the minimum characters that are needed to be inserted to make the string a palindrome string.\n\n\nExample Input\nInput 1:\nA = \"ABC\"\nInput 2:\nA = \"AACECAAAA\"\n\n\nExample Output\nOutput 1:\n2\nOutput 2:\n2\n\n\nExample Explanation\nExplanation 1:\nInsert \'B\' at beginning, string becomes: \"BABC\".\nInsert \'C\' at beginning, string becomes: \"CBABC\".\nExplanation 2:\nInsert \'A\' at beginning, string becomes: \"AAACECAAAA\".\nInsert \'A\' at beginning, string becomes: \"AAAACECAAAA\".\n\n\nAnswer :-\nclass Solution:\n    # @param A : string\n    # @return an integer\n    def create_lps(self,A):\n        M=len(A)\n        lps=[None]*M\n        l=0\n        lps[0]=l\n        i=1\n        \n        while i<M:\n            if A[i]==A[l]:\n                l+=1\n                lps[i]=l\n                i+=1\n            else:\n                if l!=0:\n                    l=lps[l-1]\n                else:\n                    lps[i]=0\n                    i+=1\n        return lps\n        \n        \n    def solve(self, A):\n        lps=self.create_lps(A+\"\$\"+A[::-1])\n        return len(A)-lps[-1]',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=pE4D55Yti7o&pp=ygVCaW50ZXJ2aWV3Yml0IG1pbmltdW0gY2hhcmFjdGVyIHJlcXVpcmVkIHRvIG1ha2UgYSBwYWxpbmRyb20gc3RyaW5n',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
