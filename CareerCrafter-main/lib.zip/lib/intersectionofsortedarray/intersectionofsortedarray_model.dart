import '/flutter_flow/flutter_flow_util.dart';
import 'intersectionofsortedarray_widget.dart'
    show IntersectionofsortedarrayWidget;
import 'package:flutter/material.dart';

class IntersectionofsortedarrayModel
    extends FlutterFlowModel<IntersectionofsortedarrayWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
