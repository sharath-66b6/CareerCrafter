import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'hotelbookingpossible_model.dart';
export 'hotelbookingpossible_model.dart';

class HotelbookingpossibleWidget extends StatefulWidget {
  const HotelbookingpossibleWidget({super.key});

  @override
  State<HotelbookingpossibleWidget> createState() =>
      _HotelbookingpossibleWidgetState();
}

class _HotelbookingpossibleWidgetState
    extends State<HotelbookingpossibleWidget> {
  late HotelbookingpossibleModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => HotelbookingpossibleModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Hotel Bookings Possible',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nA hotel manager has to process N advance bookings of rooms for the next season. His hotel has C rooms. Bookings contain an arrival date and a departure date. He wants to find out whether there are enough rooms in the hotel to satisfy the demand. Write a program that solves this problem in time O(N log N) .\n\n\n\nProblem Constraints\n1 <= |A| <= 106\n|A|== |B|\n1 <= Ai <= Bi <= 108 \n1 <= C <= 106\n\n\n\nInput Format\nFirst argument is an integer array A containing arrival time of booking.\n\nSecond argument is an integer array B containing departure time of booking.\n\nThird argument is an integer C denoting the count of rooms.\n\n\n\nOutput Format\nReturn True if there are enough rooms for N bookings else return False.\n\nReturn 0/1 for C programs.\n\n\n\nExample Input\nInput 1:\n\n A = [1, 3, 5]\n B = [2, 6, 8]\n C = 1\nInput 2:\n\n A = [1, 2, 3]\n B = [2, 3, 4]\n C = 2\n\n\nExample Output\nOutput 1:\n\n 0\nOutput 2:\n\n 1\n\n\nExample Explanation\nExplanation 1:\n\n At day = 5, there are 2 guests in the hotel. But I have only one room.\nExplanation 2:\n\n At day = 1, there is 1 guest in the hotel.\n At day = 2, there are 2 guests in the hotel. \n At day = 3, there are 2 guests in the hotel.\n At day = 4, there is 1 guest in the hotel.\n\n We have two rooms available, which satisfy the demand.\n\n\n\nAnswer :-\n/**\n * @input arrive : Integer array\n * @input n1 : Integer array\'s ( arrive ) length\n * @input depart : Integer array\n * @input n2 : Integer array\'s ( depart ) length\n * @input K : Integer\n * \n * @Output Integer 0 / 1. 0 if not possible, else 1. \n */\n int compare(const void *a, const void *b)\n {\n     return *(int *)a - *(int *)b;\n }\nint hotel(int* arrive, int n1, int* depart, int n2, int k) {\n    \n    qsort(arrive,n1,sizeof(int),compare);\n    qsort(depart,n2,sizeof(int),compare);\n    int i,j,count=0;\n    i=j=0;\n    while(i<n1 && j<n2)\n    {\n        if(arrive[i]<depart[j])\n        {\n            count++;\n            i++;\n            if(count>k)\n            return 0;\n        }\n        else\n        {\n            count--;\n            j++;\n        }\n    }\n    return 1;\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=NTPOkuur_uA&pp=ygUjaW50ZXJ2aWV3Yml0IGhvdGVsIGJvb2tpbmcgcG9zc2libGU%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
