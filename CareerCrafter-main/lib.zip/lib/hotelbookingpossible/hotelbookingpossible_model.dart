import '/flutter_flow/flutter_flow_util.dart';
import 'hotelbookingpossible_widget.dart' show HotelbookingpossibleWidget;
import 'package:flutter/material.dart';

class HotelbookingpossibleModel
    extends FlutterFlowModel<HotelbookingpossibleWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
