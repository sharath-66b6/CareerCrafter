import '/flutter_flow/flutter_flow_util.dart';
import 'easydifficulty_widget.dart' show EasydifficultyWidget;
import 'package:flutter/material.dart';

class EasydifficultyModel extends FlutterFlowModel<EasydifficultyWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
