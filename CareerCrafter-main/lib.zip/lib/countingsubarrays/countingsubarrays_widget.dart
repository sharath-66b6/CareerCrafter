import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'countingsubarrays_model.dart';
export 'countingsubarrays_model.dart';

class CountingsubarraysWidget extends StatefulWidget {
  const CountingsubarraysWidget({super.key});

  @override
  State<CountingsubarraysWidget> createState() =>
      _CountingsubarraysWidgetState();
}

class _CountingsubarraysWidgetState extends State<CountingsubarraysWidget> {
  late CountingsubarraysModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CountingsubarraysModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Counting Subarrays!',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1800.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nGiven an array A of N non-negative numbers and you are also given non-negative number B.\n\nYou need to find the number of subarrays in A having sum less than B. We may assume that there is no overflow.\n\n\n\nProblem Constraints\n1 <= N <= 104\n\n1 <= A[i] <= 100\n\n1 <= B <= 108\n\n\n\nInput Format\nFirst argument is an integer array A.\n\nSecond argument is an integer B.\n\n\n\nOutput Format\nReturn an integer denoting the number of subarrays in A having sum less than B.\n\n\n\nExample Input\nInput 1:\n\n A = [2, 5, 6]\n B = 10\nInput 2:\n\n A = [1, 11, 2, 3, 15]\n B = 10\n\n\nExample Output\nOutput 1:\n\n 4\nOutput 2:\n\n 4\n\n\nExample Explanation\nExplanation 1:\n\n The subarrays with sum less than B are {2}, {5}, {6} and {2, 5},\nExplanation 2:\n\n The subarrays with sum less than B are {1}, {2}, {3} and {2, 3}\n\n\n\n\n\n\n\n\nAnswer :-\n/**\n * @input A : Integer array\n * @input n1 : Integer array\'s ( A ) length\n * @input B : Integer\n * \n * @Output Integer\n */\nint solve(int* A, int n1, int B) {\n    int i,j,sum,count=0;\n    for(i=0;i<n1;i++){\n        sum=A[i];j=i;\n        while(sum<B&&j<n1){\n              count++;j++;\n              sum+=A[j];\n        }\n    }\n    return(count);\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=L_yBEqBAZzs&pp=ygUfaW50ZXJ2aWV3Yml0IGNvdW50aW5nIHN1YmFycmF5cw%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
