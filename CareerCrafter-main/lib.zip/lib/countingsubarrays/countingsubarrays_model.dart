import '/flutter_flow/flutter_flow_util.dart';
import 'countingsubarrays_widget.dart' show CountingsubarraysWidget;
import 'package:flutter/material.dart';

class CountingsubarraysModel extends FlutterFlowModel<CountingsubarraysWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
