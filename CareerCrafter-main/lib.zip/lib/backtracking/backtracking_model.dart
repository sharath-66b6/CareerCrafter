import '/flutter_flow/flutter_flow_util.dart';
import 'backtracking_widget.dart' show BacktrackingWidget;
import 'package:flutter/material.dart';

class BacktrackingModel extends FlutterFlowModel<BacktrackingWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
