import '/flutter_flow/flutter_flow_util.dart';
import 'hashing_widget.dart' show HashingWidget;
import 'package:flutter/material.dart';

class HashingModel extends FlutterFlowModel<HashingWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
