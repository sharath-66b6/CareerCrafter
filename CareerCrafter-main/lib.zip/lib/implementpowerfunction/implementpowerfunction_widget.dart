import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'implementpowerfunction_model.dart';
export 'implementpowerfunction_model.dart';

class ImplementpowerfunctionWidget extends StatefulWidget {
  const ImplementpowerfunctionWidget({super.key});

  @override
  State<ImplementpowerfunctionWidget> createState() =>
      _ImplementpowerfunctionWidgetState();
}

class _ImplementpowerfunctionWidgetState
    extends State<ImplementpowerfunctionWidget> {
  late ImplementpowerfunctionModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ImplementpowerfunctionModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Implement Power Function',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1200.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nImplement pow(x, n) % d.\nIn other words, given x, n and d,\nFind (xn % d)\nNote that remainders on division cannot be negative. In other words, make sure the answer you return is non-negative integer.\n\n\nProblem Constraints\n-109 <= x <= 109\n0 <= n <= 109\n1 <= d <= 109\n\n\nExample Input\nInput 1:\nx = 2\nn = 3\nd = 3\nInput 2:\nx = 5\nn = 2\nd = 6\n\n\nExample Output\nOutput 1:\n2\nOutput 2:\n1\n\n\nExample Explanation\nExplanation 1:\n23 % 3 = 8 % 3 = 2.\nExplanation 2:\n52 % 6 = 25 % 6 = 1.\n\n\n\nAnswer :- \nlong long powmode(long long b,long long n,long long d)\n{\n  if(n==0) return 1;\n  else{\n   long long ans=powmode(b,n/2,d)%d;\n      if(n%2) return ((ans*ans)%d*b)%d;\n      else return (ans*ans)%d;\n\n  }\n}\nint powmod(int x,int n,int d)\n{\n   if(x==0) return 0;\n   long long ans=powmode(x,n,d);\n    if(ans<0) return (ans+d)%d;\n    else ans;\n }',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=r0-rryyMryA&pp=ygUlaW50ZXJ2aWV3Yml0IGltcGxlbWVudCBwb3dlciBmdW5jaXRvbg%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
