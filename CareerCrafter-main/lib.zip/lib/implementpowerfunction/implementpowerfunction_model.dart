import '/flutter_flow/flutter_flow_util.dart';
import 'implementpowerfunction_widget.dart' show ImplementpowerfunctionWidget;
import 'package:flutter/material.dart';

class ImplementpowerfunctionModel
    extends FlutterFlowModel<ImplementpowerfunctionWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
