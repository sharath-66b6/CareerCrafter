import '/flutter_flow/flutter_flow_util.dart';
import 'grofersquestions_widget.dart' show GrofersquestionsWidget;
import 'package:flutter/material.dart';

class GrofersquestionsModel extends FlutterFlowModel<GrofersquestionsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
