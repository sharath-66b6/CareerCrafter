import '/flutter_flow/flutter_flow_util.dart';
import 'listcycle_widget.dart' show ListcycleWidget;
import 'package:flutter/material.dart';

class ListcycleModel extends FlutterFlowModel<ListcycleWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
