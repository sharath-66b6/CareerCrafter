import '/flutter_flow/flutter_flow_util.dart';
import 'excelcolumntitle_widget.dart' show ExcelcolumntitleWidget;
import 'package:flutter/material.dart';

class ExcelcolumntitleModel extends FlutterFlowModel<ExcelcolumntitleWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
