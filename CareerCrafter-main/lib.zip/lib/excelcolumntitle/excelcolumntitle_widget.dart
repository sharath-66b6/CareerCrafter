import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'excelcolumntitle_model.dart';
export 'excelcolumntitle_model.dart';

class ExcelcolumntitleWidget extends StatefulWidget {
  const ExcelcolumntitleWidget({super.key});

  @override
  State<ExcelcolumntitleWidget> createState() => _ExcelcolumntitleWidgetState();
}

class _ExcelcolumntitleWidgetState extends State<ExcelcolumntitleWidget> {
  late ExcelcolumntitleModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ExcelcolumntitleModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Excel Column Title',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nGiven a positive integer A, return its corresponding column title as appear in an Excel sheet.\n\n\n\nProblem Constraints\n1 <= A <= 1000000000\n\n\n\nInput Format\nFirst and only argument is integer A.\n\n\n\nOutput Format\nReturn a string, the answer to the problem.\n\n\n\nExample Input\nInput 1:\n\n A = 1\nInput 2:\n\n A = 28\n\n\nExample Output\nOutput 1:\n\n \"A\"\nOutput 2:\n\n \"AB\"\n\n\nExample Explanation\nExplanation 1:\n\n 1 -> A\nExplanation 2:\n\n1 -> A\n2 -> B\n3 -> C\n...\n26 -> Z\n27 -> AA\n28 -> AB \n\n\nAnswers :- \nchar* convertToTitle(int n) {\n     char *res = (char *)calloc(8, sizeof(char));\n    int i = 6;\n    while(n){\n        res[i--] = (char)((n-1) % 26) + \'A\';\n        n = (n - 1) / 26;\n    }\n    return res+i+1;\n}',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=DzxYFza8Xts&pp=ygUeaW50ZXJ2aWV3Yml0IGV4Y2VsIHBvd2VyIHRpdGxl',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
