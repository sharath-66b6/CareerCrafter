import '/flutter_flow/flutter_flow_util.dart';
import 'companyprinciple_widget.dart' show CompanyprincipleWidget;
import 'package:flutter/material.dart';

class CompanyprincipleModel extends FlutterFlowModel<CompanyprincipleWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
