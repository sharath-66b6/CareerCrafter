import '/flutter_flow/flutter_flow_util.dart';
import 'longestpalindromesubsequence_widget.dart'
    show LongestpalindromesubsequenceWidget;
import 'package:flutter/material.dart';

class LongestpalindromesubsequenceModel
    extends FlutterFlowModel<LongestpalindromesubsequenceWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
