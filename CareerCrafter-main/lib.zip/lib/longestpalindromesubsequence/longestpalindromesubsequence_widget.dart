import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'longestpalindromesubsequence_model.dart';
export 'longestpalindromesubsequence_model.dart';

class LongestpalindromesubsequenceWidget extends StatefulWidget {
  const LongestpalindromesubsequenceWidget({super.key});

  @override
  State<LongestpalindromesubsequenceWidget> createState() =>
      _LongestpalindromesubsequenceWidgetState();
}

class _LongestpalindromesubsequenceWidgetState
    extends State<LongestpalindromesubsequenceWidget> {
  late LongestpalindromesubsequenceModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => LongestpalindromesubsequenceModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Longest Palindromic Subsequence',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2000.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven a string A, find the common palindromic sequence ( A sequence which does not need to be contiguous and is a pallindrome), which is common in itself.\n\nYou need to return the length of longest palindromic subsequence in A.\n\nNOTE:\n\nYour code will be run on multiple test cases (<=10). Try to come up with an optimised solution.\n\n\nProblem Constraints\n 1 <= |A| <= 1005\n\n\n\nInput Format\nFirst and only argument is an string A.\n\n\n\nOutput Format\nReturn a integer denoting the length of longest palindromic subsequence in A.\n\n\n\nExample Input\nInput 1:\n\n A = \"bebeeed\"\n\n\nExample Output\nOutput 1:\n\n 4\n\n\nExample Explanation\nExplanation 1:\n\n The longest common pallindromic subsequence is \"eeee\", which has a length of 4\n\n\n\n\n\nAnswer :-\n/**\n * @input A : String termination by \'\\0\'\n * \n * @Output Integer\n */\n int max (int x, int y) { return (x > y)? x : y; }\n int lps(char *str) \n{ \n   int n = strlen(str); \n   int i, j, cl; \n   int L[n][n];  // Create a table to store results of subproblems \n  \n  \n   // Strings of length 1 are palindrome of lentgh 1 \n   for (i = 0; i < n; i++) \n      L[i][i] = 1; \n  \n    // Build the table. Note that the lower diagonal values of table are \n    // useless and not filled in the process. The values are filled in a \n    // manner similar to Matrix Chain Multiplication DP solution (See \n    // https://www.geeksforgeeks.org/matrix-chain-multiplication-dp-8/). cl is length of \n    // substring \n    for (cl=2; cl<=n; cl++) \n    { \n        for (i=0; i<n-cl+1; i++) \n        { \n            j = i+cl-1; \n            if (str[i] == str[j] && cl == 2) \n               L[i][j] = 2; \n            else if (str[i] == str[j]) \n               L[i][j] = L[i+1][j-1] + 2; \n            else\n               L[i][j] = max(L[i][j-1], L[i+1][j]); \n        } \n    } \n  \n    return L[0][n-1]; \n} \nint solve(char* A) {\n    return lps(A);\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=U095bJJtW3w&pp=ygUraW50ZXJ2aWV3Yml0IGxvbmdlc3QgcGFsaW5kcm9tZSBzdWJzZXF1ZW5jZQ%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
