import '/flutter_flow/flutter_flow_util.dart';
import 'diffk_widget.dart' show DiffkWidget;
import 'package:flutter/material.dart';

class DiffkModel extends FlutterFlowModel<DiffkWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
