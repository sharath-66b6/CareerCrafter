import '/flutter_flow/flutter_flow_util.dart';
import 'cybersecurity_widget.dart' show CybersecurityWidget;
import 'package:flutter/material.dart';

class CybersecurityModel extends FlutterFlowModel<CybersecurityWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
