import '/flutter_flow/flutter_flow_util.dart';
import 'eggsnadbuilding_widget.dart' show EggsnadbuildingWidget;
import 'package:flutter/material.dart';

class EggsnadbuildingModel extends FlutterFlowModel<EggsnadbuildingWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
