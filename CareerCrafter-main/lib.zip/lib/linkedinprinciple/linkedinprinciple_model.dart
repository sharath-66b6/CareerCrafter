import '/flutter_flow/flutter_flow_util.dart';
import 'linkedinprinciple_widget.dart' show LinkedinprincipleWidget;
import 'package:flutter/material.dart';

class LinkedinprincipleModel extends FlutterFlowModel<LinkedinprincipleWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
