import '/flutter_flow/flutter_flow_util.dart';
import 'findduplicatesinaarray_widget.dart' show FindduplicatesinaarrayWidget;
import 'package:flutter/material.dart';

class FindduplicatesinaarrayModel
    extends FlutterFlowModel<FindduplicatesinaarrayWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
