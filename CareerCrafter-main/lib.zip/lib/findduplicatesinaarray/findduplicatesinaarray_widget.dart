import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'findduplicatesinaarray_model.dart';
export 'findduplicatesinaarray_model.dart';

class FindduplicatesinaarrayWidget extends StatefulWidget {
  const FindduplicatesinaarrayWidget({super.key});

  @override
  State<FindduplicatesinaarrayWidget> createState() =>
      _FindduplicatesinaarrayWidgetState();
}

class _FindduplicatesinaarrayWidgetState
    extends State<FindduplicatesinaarrayWidget> {
  late FindduplicatesinaarrayModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => FindduplicatesinaarrayModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Find Duplicate in Array',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1500.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven a read-only array of n + 1 integers between 1 and n, find one number that repeats in linear time using less than O(n) space and traversing the stream sequentially O(1) times.\nIf there are multiple possible answers ( like in the sample case ), output any one, if there is no duplicate, output -1\n\n\n\nProblem Constraints\n1 <= |A| <= 105\n1 <= Ai <= |A|\n\n\nInput Format\nThe first argument is an integer array A.\n\n\nOutput Format\nReturn the integer that repeats in array A\n\n\nExample Input\nInput 1:\nA = [3, 4, 1, 4, 2]\nInput 2:\nA = [1, 2, 3]\nInput 3:\nA = [3, 4, 1, 4, 1]\n\n\nExample Output\nOutput 1:\n4\nOutput 2:\n-1\nOutput 3:\n1\n\n\nExample Explanation\nExplanation 1:\n4 repeats itself in the array [3, 4, 1, 4, 2]\nExplanation 2:\nNo number repeats itself in the array [1, 2, 3]\nExplanation 3:\n1 and 4 repeats itself in the array [3, 4, 1, 4, 1], we can return 1 or 4\n\n\n\nAnswer :-\n/**\n * @input A : Read only ( DON\'T MODIFY ) Integer array\n * @input n1 : Integer array\'s ( A ) length\n * \n * @Output Integer\n */\nint repeatedNumber(const int* A, int n1) {\n    if(n1 <= 1) return -1;\n    int slow = A[0];\n    int fast = A[A[0]];\n    while(slow != fast){\n        slow = A[slow];\n        fast = A[A[fast]];\n    }\n    slow = 0;\n    while(slow != fast){\n        slow = A[slow];\n        fast = A[fast];\n    }\n    return slow;\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=jxcLp8RNgKU&pp=ygUkaW50ZXJ2aWV3Yml0IGZpbmQgZHVwbGljYXRlIGluIGFycmF5',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
