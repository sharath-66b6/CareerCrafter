import '/flutter_flow/flutter_flow_util.dart';
import 'microsoftquestion_widget.dart' show MicrosoftquestionWidget;
import 'package:flutter/material.dart';

class MicrosoftquestionModel extends FlutterFlowModel<MicrosoftquestionWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
