import '/flutter_flow/flutter_flow_util.dart';
import 'facebookquestion_widget.dart' show FacebookquestionWidget;
import 'package:flutter/material.dart';

class FacebookquestionModel extends FlutterFlowModel<FacebookquestionWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
