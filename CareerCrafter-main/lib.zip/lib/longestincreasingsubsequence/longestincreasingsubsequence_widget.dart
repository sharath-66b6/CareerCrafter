import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'longestincreasingsubsequence_model.dart';
export 'longestincreasingsubsequence_model.dart';

class LongestincreasingsubsequenceWidget extends StatefulWidget {
  const LongestincreasingsubsequenceWidget({super.key});

  @override
  State<LongestincreasingsubsequenceWidget> createState() =>
      _LongestincreasingsubsequenceWidgetState();
}

class _LongestincreasingsubsequenceWidgetState
    extends State<LongestincreasingsubsequenceWidget> {
  late LongestincreasingsubsequenceModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => LongestincreasingsubsequenceModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Longest Increasing Subsequence',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1700.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nFind the longest increasing subsequence of a given array of integers, A.\n\nIn other words, find a subsequence of array in which the subsequence\'s elements are in strictly increasing order, and in which the subsequence is as long as possible.\n\nIn this case, return the length of the longest increasing subsequence.\n\n\n\nProblem Constraints\n1 <= length(A) <= 2500\n\n0 <= A[i] <= 2500\n\n\n\nInput Format\nThe first and the only argument is an integer array A.\n\n\n\nOutput Format\nReturn an integer representing the length of the longest increasing subsequence.\n\n\n\nExample Input\nInput 1:\n\n A = [1, 2, 1, 5]\nInput 2:\n\n A = [0, 8, 4, 12, 2, 10, 6, 14, 1, 9, 5, 13, 3, 11, 7, 15]\n\n\nExample Output\nOutput 1:\n\n 3\nOutput 2:\n\n 6\n\n\nExample Explanation\nExplanation 1:\n\n The longest increasing subsequence: [1, 2, 5]\nExplanation 2:\n\n The possible longest increasing subsequences: [0, 2, 6, 9, 13, 15] or [0, 4, 6, 9, 11, 15] or [0, 4, 6, 9, 13, 15]\n\n\n\nAnswer :-\n/**\n * @input A : Read only ( DON\'T MODIFY ) Integer array\n * @input n1 : Integer array\'s ( A ) length\n * \n * @Output Integer\n */\nint lis(const int* A, int n1) {\n    int ans[n1];\n    int i=0,temp=1,j;\n    for(i=0;i<n1;i++) ans[i]=0;\n    ans[0]=1;\n    for(i=1;i<n1;i++){\n        \n        for(j=0;j<i;j++){\n            if(A[j]<A[i]){\n                if(ans[i]<ans[j]) ans[i]=ans[j];\n            }\n        }\n        ans[i]++;\n        if(ans[i]>temp) temp=ans[i];\n    }\n    return temp;\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=okgM58Tv9jQ&pp=ygUraW50ZXJ2aWV3Yml0IGxvbmdlc3QgaW5jcmVhc2luZyBzdWJzZXF1ZW5jZQ%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
