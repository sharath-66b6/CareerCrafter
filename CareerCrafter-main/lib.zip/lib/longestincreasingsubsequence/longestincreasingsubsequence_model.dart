import '/flutter_flow/flutter_flow_util.dart';
import 'longestincreasingsubsequence_widget.dart'
    show LongestincreasingsubsequenceWidget;
import 'package:flutter/material.dart';

class LongestincreasingsubsequenceModel
    extends FlutterFlowModel<LongestincreasingsubsequenceWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
