import '/flutter_flow/flutter_flow_util.dart';
import 'graycode_widget.dart' show GraycodeWidget;
import 'package:flutter/material.dart';

class GraycodeModel extends FlutterFlowModel<GraycodeWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
