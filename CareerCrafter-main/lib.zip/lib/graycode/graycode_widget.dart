import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'graycode_model.dart';
export 'graycode_model.dart';

class GraycodeWidget extends StatefulWidget {
  const GraycodeWidget({super.key});

  @override
  State<GraycodeWidget> createState() => _GraycodeWidgetState();
}

class _GraycodeWidgetState extends State<GraycodeWidget> {
  late GraycodeModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => GraycodeModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Gray Code',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2000.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nThe gray code is a binary numeral system where two successive values differ in only one bit.\n\nGiven a non-negative integer A representing the total number of bits in the code, print the sequence of gray code.\n\n A gray code sequence must begin with 0.\n\n\n\nProblem Constraints\n1 <= A <= 16\n\n\n\nInput Format\nThe first argument is an integer A.\n\n\n\nOutput Format\nReturn an array of integers representing the gray code sequence.\n\n\n\nExample Input\nInput 1:\n\nA = 2\nInput 1:\n\nA = 1\n\n\nExample Output\noutput 1:\n\n[0, 1, 3, 2]\noutput 2:\n\n[0, 1]\n\n\nExample Explanation\nExplanation 1:\n\nfor A = 2 the gray code sequence is:\n    00 - 0\n    01 - 1\n    11 - 3\n    10 - 2\nSo, return [0,1,3,2].\nExplanation 1:\n\nfor A = 1 the gray code sequence is:\n    00 - 0\n    01 - 1\nSo, return [0, 1].\n\n\n\nAnswer :-\n/**\n * @input A : Integer\n * \n * @Output Integer array. You need to malloc memory, and fill the length in len1\n */\n void fill(int A, int pos, int *cnt, int *ret) {\n     int i, v, up, k;\n     if (pos >= A)\n        return;\n    up = *cnt;\n    k = up;\n    for (i = up - 1; i >=0; i--) {\n        ret[k++] = (1 << pos) + ret[i];\n    }\n    *cnt = k;\n    fill(A, pos + 1, cnt, ret);\n }\nint* grayCode(int A, int *len1) {\n    int *ret;\n    int cnt, pos;\n    ret = (int *)malloc(sizeof(int) * (1 << A));\n    ret[0] = 0;\n    *len1 = 1 << A;\n    if (A == 0)\n        return ret;\n    ret[1] = 1;\n    if (A == 1)\n        return ret;\n    cnt = 2;\n    pos = 1;\n    fill(A, pos, &cnt, ret);\n    return ret;\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=Fha1CSxwvGg&pp=ygUWaW50ZXJ2aWV3Yml0IGdyYXkgY29kZQ%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
