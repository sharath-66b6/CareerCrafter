import '/flutter_flow/flutter_flow_util.dart';
import 'lrucache_widget.dart' show LrucacheWidget;
import 'package:flutter/material.dart';

class LrucacheModel extends FlutterFlowModel<LrucacheWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
