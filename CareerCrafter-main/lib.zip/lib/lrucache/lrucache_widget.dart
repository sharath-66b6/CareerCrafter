import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'lrucache_model.dart';
export 'lrucache_model.dart';

class LrucacheWidget extends StatefulWidget {
  const LrucacheWidget({super.key});

  @override
  State<LrucacheWidget> createState() => _LrucacheWidgetState();
}

class _LrucacheWidgetState extends State<LrucacheWidget> {
  late LrucacheModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => LrucacheModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'LRU Cache',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 3400.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nDesign and implement a data structure for LRU (Least Recently Used) cache. It should support the following operations: get and set.\n\nget(key) - Get the value (will always be positive) of the key if the key exists in the cache, otherwise return -1.\nset(key, value) - Set or insert the value if the key is not already present. When the cache reaches its capacity, it should invalidate the least recently used item before inserting the new item.\nThe LRU Cache will be initialized with an integer corresponding to its capacity. Capacity indicates the maximum number of unique keys it can hold at a time.\n\nDefinition of “least recently used” : An access to an item is defined as a get or a set operation of the item. “Least recently used” item is the one with the oldest access time.\n\nNOTE: If you are using any global variables, make sure to clear them in the constructor.\n\nExample :\n\nInput : \n         capacity = 2\n         set(1, 10)\n         set(5, 12)\n         get(5)        returns 12\n         get(1)        returns 10\n         get(10)       returns -1\n         set(6, 14)    this pushes out key = 5 as LRU is full. \n         get(5)        returns -1 \n\n\n\n\n\n\n\nAnswer :-\nstruct QueueNode {\n    int key;\n    int value;\n    struct QueueNode* prev;\n    struct QueueNode* next;\n};\nstruct Queue {\n    int capacity;\n    int count;\n    struct QueueNode* front;\n    struct QueueNode* rear;\n};\nstruct Hash {\n    int size;\n    struct QueueNode** array;\n};\nstruct Queue* queue;\nstruct Hash* hash;\nstruct Queue* createQueue(int c) {\n    struct Queue* q = (struct Queue*) malloc(sizeof(struct Queue));\n    q->capacity = c;\n    q->count = 0;\n    q->front=q->rear=NULL;\n    return q;\n}\nstruct Hash* createHash(int s) {\n    struct Hash* h= (struct Hash*) malloc(sizeof(struct Hash));\n    h->size = s;\n    h->array = (struct QueueNode**) malloc(s*sizeof(struct QueueNode*));\n    int i;\n    for(i=0;i<s;i++) {\n        h->array[i] = NULL;\n    }\n    return h;\n}\nstruct QueueNode* newNode(int key,int value) {\n    struct QueueNode* node = (struct QueueNode*) malloc(sizeof(struct QueueNode));\n    node->key = key;\n    node->value = value;\n    node->prev=NULL;\n    node->next = NULL;\n    return node;\n}\nint isEmpty(struct Queue* q) {\n    return q->rear == NULL;\n}\nint isFull(struct Queue* q) {\n    return q->count == q->capacity;\n}\nvoid deQueue(struct Queue* q) {\n    if(isEmpty(q)) {\n        return;\n    }\n    struct QueueNode* temp = q->rear;\n    if(q->front== q->rear) {\n        q->front=NULL;\n    }\n    if(temp->prev) {\n        temp->prev->next = NULL;\n    }\n    q->rear = q->rear->prev;\n    \n    q->count--;\n    free(temp);\n}\nvoid enqueue(struct Queue* q,int key, int value) {\n    if(isFull(queue)) {\n        hash->array[q->rear->key] = NULL;\n        deQueue(q);\n    } \n    struct QueueNode* node = newNode(key,value);\n    if(isEmpty(queue)) {\n        q->front=q->rear = node;\n    } else {\n        node->next = q->front;\n        q->front->prev = node;\n        q->front = node;\n    }\n    hash->array[key] = node;\n    q->count++;\n}\n\n\nvoid init(int capacity) {\nif(queue != NULL) {\n    free(queue);\n}\nif(hash!= NULL) {\n    free(hash);\n}\nqueue = createQueue(capacity);\nhash = createHash(1000);\n}\n\nvoid moveNodeToFront(struct QueueNode* node, struct Queue* q) {\n            node->prev->next = node->next;\n            if(node->next) {\n                node->next->prev = node->prev;\n            }\n            if(node==queue->rear) {\n                queue->rear = node->prev;\n            }\n            node->next = queue->front;\n            queue->front->prev = node;\n            node->prev = NULL;\n            queue->front = node;\n}\n\nint get(int key) {\n    struct QueueNode* node = hash->array[key];\n    if(node != NULL) {\n        int val = node->value;\n        if(node != queue->front) {\n           moveNodeToFront(node,queue);\n        }\n        return val;\n    }else {\n        return -1;\n    }\n}\n\nvoid set(int key, int value) {\n    struct QueueNode* node = hash->array[key];\n    if(node == NULL) {\n       enqueue(queue,key,value); \n    } else {\n        node->value = value;\n        if(node != queue->front) {\n            moveNodeToFront(node,queue);\n        }\n    }\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=xDEuM5qa0zg&pp=ygUWaW50ZXJ2aWV3Yml0IGxydSBjYWNoZQ%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
