import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'cointerwithmostwater_model.dart';
export 'cointerwithmostwater_model.dart';

class CointerwithmostwaterWidget extends StatefulWidget {
  const CointerwithmostwaterWidget({super.key});

  @override
  State<CointerwithmostwaterWidget> createState() =>
      _CointerwithmostwaterWidgetState();
}

class _CointerwithmostwaterWidgetState
    extends State<CointerwithmostwaterWidget> {
  late CointerwithmostwaterModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CointerwithmostwaterModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Container With Most Water',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1000.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nGiven n non-negative integers a1, a2, ..., an,\n\nwhere each represents a point at coordinate (i, ai).\n\n\'n\' vertical lines are drawn such that the two endpoints of line i is at (i, ai) and (i, 0).\n\nFind two lines, which together with x-axis forms a container, such that the container contains the most water.\n\nYour program should return an integer which corresponds to the maximum area of water that can be contained ( Yes, we know maximum area instead of maximum volume sounds weird. But this is 2D plane we are working with for simplicity ).\n\nNote: You may not slant the container.\n\nExample :\n\nInput : [1, 5, 4, 3]\nOutput : 6\n\nExplanation : 5 and 3 are distance 2 apart. So size of the base = 2. Height of container = min(5, 3) = 3. \nSo total area = 3 * 2 = 6\n\n\n\nAnswer :-\nint maxArea(int* a, int n) {\n    int i,j,area,min,ans=0;\n    i=0;j=n-1;\n    while(i<j)\n    {\n       // printf(\"%d %d  \",i,j);\n        min=a[i]>a[j]?a[j]:a[i];\n        area=(j-i)*min;\n        ans=area>ans?area:ans;\n        if(a[i]>a[j])\n         j--;\n         else\n         i++;\n    }\n     return ans;\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=rSfelukD9Dk&pp=ygUkaW50ZXJ2aWV3Yml0IGNvaW50ZXIgd2l0aCBtb3N0IHdhdGVy',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
