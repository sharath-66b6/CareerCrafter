import '/flutter_flow/flutter_flow_util.dart';
import 'cointerwithmostwater_widget.dart' show CointerwithmostwaterWidget;
import 'package:flutter/material.dart';

class CointerwithmostwaterModel
    extends FlutterFlowModel<CointerwithmostwaterWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
