import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'daughtersage_model.dart';
export 'daughtersage_model.dart';

class DaughtersageWidget extends StatefulWidget {
  const DaughtersageWidget({super.key});

  @override
  State<DaughtersageWidget> createState() => _DaughtersageWidgetState();
}

class _DaughtersageWidgetState extends State<DaughtersageWidget> {
  late DaughtersageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => DaughtersageModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Daughters\' Ages',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Two MIT math grads bump into each other at Fairway on the upper west side. They haven’t seen each other in over 20 years.\n\nThe first grad says to the second: “how have you been?”\nSecond: “great! i got married and i have three daughters now”\nFirst: “really? how old are they?”\nSecond: “well, the product of their ages is 72, and the sum of their ages is the same as the number on that building over there..”\nFirst: “right, ok.. oh wait.. hmm, i still don’t know”\nSecond: “oh sorry, the oldest one just started to play the piano”\nFirst: “wonderful! my oldest is the same age!”\nHow old are the daughters?\n\nRespond with daughter ages sorted in ascending order and concatenated together. No spaces.\n\n\nAnswer :-\nWe know that there are 3 daughters whose ages multiply to 72. Let’s look at the possibilities…Ages:          Sum of ages:\n\n1 1 72            74\n\n1 2 36            39\n\n1 3 24            28\n\n1 4 18            23\n\n1 6 12            19\n\n1 8 9             18\n\n2 2 18            22\n\n2 3 12            17\n\n2 4 9             15\n\n2 6 6             14\n\n3 3 8             14\n\n3 4 6             13\n\nAfter looking at the building number the second man still can’t figure out what their ages are, so that means that the sum of the ages (or building number) must be 14, since that is the only sum that has more than one possibility. Finally the man discovers that there is an oldest daughter. That rules out the “2 6 6″ possibility since the two oldest would be twins. Therefore, the daughters ages must be “3 3 8″.\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=JSGr0svQaoM&pp=ygUgaW50ZXJ2aWV3Yml0IHB1enpsZSBkYXVnaHRlciBhZ2U%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
