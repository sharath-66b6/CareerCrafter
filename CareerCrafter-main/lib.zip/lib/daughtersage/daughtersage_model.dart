import '/flutter_flow/flutter_flow_util.dart';
import 'daughtersage_widget.dart' show DaughtersageWidget;
import 'package:flutter/material.dart';

class DaughtersageModel extends FlutterFlowModel<DaughtersageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
