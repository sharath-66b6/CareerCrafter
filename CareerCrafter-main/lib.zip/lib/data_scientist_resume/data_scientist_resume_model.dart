import '/flutter_flow/flutter_flow_util.dart';
import 'data_scientist_resume_widget.dart' show DataScientistResumeWidget;
import 'package:flutter/material.dart';

class DataScientistResumeModel
    extends FlutterFlowModel<DataScientistResumeWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
