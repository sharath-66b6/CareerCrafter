import '/flutter_flow/flutter_flow_util.dart';
import 'nextpermuatation_widget.dart' show NextpermuatationWidget;
import 'package:flutter/material.dart';

class NextpermuatationModel extends FlutterFlowModel<NextpermuatationWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
