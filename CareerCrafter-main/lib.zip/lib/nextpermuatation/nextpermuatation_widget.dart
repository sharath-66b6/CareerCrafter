import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'nextpermuatation_model.dart';
export 'nextpermuatation_model.dart';

class NextpermuatationWidget extends StatefulWidget {
  const NextpermuatationWidget({super.key});

  @override
  State<NextpermuatationWidget> createState() => _NextpermuatationWidgetState();
}

class _NextpermuatationWidgetState extends State<NextpermuatationWidget> {
  late NextpermuatationModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => NextpermuatationModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Next Permutation',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1900.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nImplement the next permutation, which rearranges numbers into the numerically next greater permutation of numbers for a given array A of size N.\n\nIf such an arrangement is not possible, it must be rearranged in the lowest possible order i.e., sorted in ascending order.\n\nNote:\nThe replacement must be in-place, do not allocate extra memory.\nDO NOT USE LIBRARY FUNCTION FOR NEXT PERMUTATION. Use of Library functions will disqualify your submission retroactively and will give you penalty points.\n\n\nProblem Constraints\n1 <= N <= 5e5\n1 <= A[i] <= 1e9\n\n\nInput Format\nThe first and the only argument of input has an array of integers, A.\n\n\nOutput Format\nReturn an array of integers, representing the next permutation of the given array.\n\n\nExample Input\nInput 1:\n    A = [1, 2, 3]\nInput 2:\n    A = [3, 2, 1]\nInput 3:\n    A = [1, 1, 5]\nInput 4:\n    A = [20, 50, 113]\n\n\nExample Output\nOutput 1:\n    [1, 3, 2]\nOutput 2:\n    [1, 2, 3]\nOutput 3:\n    [1, 5, 1]\nOutput 4:\n    [20, 113, 50]\n\n\n\n\nAnswer :-\n/**\n * @input A : Integer array\n * @input n1 : Integer array\'s ( A ) length\n * \n * @Output Void. Just modifies the args passed by reference \n */\nvoid nextPermutation(int* a, int n) {\nint j,temp,k;\nfor(j=n-1;j>0;j--){\nif(a[j]>a[j-1]){\n for(k=n-1;k>=j;k--){\n if(a[k]>a[j-1]){     \ntemp=a[j-1];\na[j-1]=a[k];\na[k]=temp;\nbreak;\n}\n}\nbreak;    \n}\n}\ntemp=n-1;\nwhile(j<temp){\nk=a[j];\na[j]=a[temp];\na[temp]=k;\nj++;\ntemp--;\n}\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=sCCRFjFJv38&pp=ygUdaW50ZXJ2aWV3Yml0IG5leHQgcGVybXV0YXRpb24%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
