import '/flutter_flow/flutter_flow_util.dart';
import 'fabquestions_widget.dart' show FabquestionsWidget;
import 'package:flutter/material.dart';

class FabquestionsModel extends FlutterFlowModel<FabquestionsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
