import '/flutter_flow/flutter_flow_util.dart';
import 'bitmanipulation_widget.dart' show BitmanipulationWidget;
import 'package:flutter/material.dart';

class BitmanipulationModel extends FlutterFlowModel<BitmanipulationWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
