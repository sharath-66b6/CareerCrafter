import '/flutter_flow/flutter_flow_util.dart';
import 'letterphone_widget.dart' show LetterphoneWidget;
import 'package:flutter/material.dart';

class LetterphoneModel extends FlutterFlowModel<LetterphoneWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
