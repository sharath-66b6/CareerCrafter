import '/flutter_flow/flutter_flow_util.dart';
import 'crossthebirdge_widget.dart' show CrossthebirdgeWidget;
import 'package:flutter/material.dart';

class CrossthebirdgeModel extends FlutterFlowModel<CrossthebirdgeWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
