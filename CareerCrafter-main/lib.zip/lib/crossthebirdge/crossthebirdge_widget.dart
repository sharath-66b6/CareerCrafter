import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'crossthebirdge_model.dart';
export 'crossthebirdge_model.dart';

class CrossthebirdgeWidget extends StatefulWidget {
  const CrossthebirdgeWidget({super.key});

  @override
  State<CrossthebirdgeWidget> createState() => _CrossthebirdgeWidgetState();
}

class _CrossthebirdgeWidgetState extends State<CrossthebirdgeWidget> {
  late CrossthebirdgeModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CrossthebirdgeModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Cross the Bridge',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Four people are on this side of the bridge. Everyone has to get across. \n\nProblem is that it’s dark and so you can’t cross the bridge without a flashlight and they only have one flashlight. \n\nPlus the bridge is only big enough for two people to cross at once. \n\nThe four people walk at different speeds:\n\none fella is so fast it only takes him 1 minute to cross the bridge,\nanother 2 minutes,\na third 5 minutes,\nthe last it takes 10 minutes to cross the bridge.\nWhen two people cross the bridge together (sharing the flashlight), they both walk at the slower person’s pace. What is the minimum time required for all 4 to cross the bridge.\n\nRespond with a number which represents the number of minutes.\n\nAnswer is a integer.  Just put the number without any decimal places if its an integer. If the answer is Infinity, output Infinity.\n\nFeel free to get in touch with us if you have any questions\n\n\n\nAnswer :-\n1 minutePerson B : 2 minutes\n\nPerson C : 5 minutes\n\nPerson D : 10 minutes\n\nLet F represents Flashlight.\n\nPerson C and D are the slowest guys, if they don’t walk together that it self will make it 15 minutes, In this case (the best way to save time is) :\n\nA,D,F —-Bridge—-> = 10 min\n\n<—-Bridge—-A,F = 1 min (returning with flash light) A,C,F —-Bridge—-> = 5 min\n\n<—-Bridge—-A,F = 1 min A,B,F —-Bridge—-> = 2 min\n\nThat makes a total of 19 minutes, but thats not what we want.\n\nIt means they both should walk together, in this case if they both are walking together, then there should be another person(because if one of them will bring it will take 5 minutes) to bring the flashlight back. So here is the solution…A,B,F —-Bridge—-> = 2 min\n\n<—-Bridge—-A,F = 1 min C,D,F —-Bridge—-> = 10 min\n\n<—-Bridge—-B,F = 2 min A,B,F —-Bridge—-> = 2 min\n\nTotal time = 17 minutes.',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=yp1AEAATZkU&pp=ygUdaW50ZXJ2aWV3Yml0IGNyb3NzIHRoZSBicmlkZ2U%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
