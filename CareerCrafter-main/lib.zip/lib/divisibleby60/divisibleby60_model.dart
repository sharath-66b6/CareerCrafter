import '/flutter_flow/flutter_flow_util.dart';
import 'divisibleby60_widget.dart' show Divisibleby60Widget;
import 'package:flutter/material.dart';

class Divisibleby60Model extends FlutterFlowModel<Divisibleby60Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
