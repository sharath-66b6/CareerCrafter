import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'divisibleby60_model.dart';
export 'divisibleby60_model.dart';

class Divisibleby60Widget extends StatefulWidget {
  const Divisibleby60Widget({super.key});

  @override
  State<Divisibleby60Widget> createState() => _Divisibleby60WidgetState();
}

class _Divisibleby60WidgetState extends State<Divisibleby60Widget> {
  late Divisibleby60Model _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => Divisibleby60Model());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Divisible by 60',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1600.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven a large number represent in the form of an integer array A, where each element is a digit.\n\nYou have to find whether there exists any permutation of the array A such that the number becomes divisible by 60.\n\nReturn 1 if it exists, 0 otherwise.\n\n\n\nProblem Constraints\n1 <= |A| <= 105\n0 <= Ai <= 9\n\n\nInput Format\nThe first argument is an integer array A.\n\n\nOutput Format\nReturn a single integer \'1\' if there exists a permutation, \'0\' otherwise.\n\n\nExample Input\nInput 1:\nA = [0, 6]\nInput 2:\n\nA = [2, 3]\n\n\nExample Output\nOutput 1:\n1\nOutput 2:\n\n0\n\n\nExample Explanation\nExplanation 1:\nWe can rearrange the digits to form 60, which is divisible by 60.\nExplanation 2:\n\nThere are only two possible permutations: [23, 32].\nBoth of them are not divisible by 60.\n\n\nAnswer :- \n/**\n * @input A : Integer array\n * @input n1 : Integer array\'s ( A ) length\n * \n * @Output Integer\n */\nint divisibleBy60(int* A, int n1)\n{\n    if(n1==1)\n    if(A[--n1]==0)\n    return 1;\n    int t=0, s=0, z=0;\n    while(n1--)\n    {\n        if((!t && A[n1]%2==0) && A[n1]!=0)\n        t++;\n        if(!z && A[n1]==0)\n        z++;\n        s+=A[n1];\n    }\n    if((s%3==0 && z )&& t)\n    return 1;\n    return 0;\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=toYgBIaUdfM&pp=ygUcaW50ZXJ2aWV3Yml0IGRpdmlzaWJsZSBieSA2MA%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
