import '/flutter_flow/flutter_flow_util.dart';
import 'greedyalgorithm_widget.dart' show GreedyalgorithmWidget;
import 'package:flutter/material.dart';

class GreedyalgorithmModel extends FlutterFlowModel<GreedyalgorithmWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
