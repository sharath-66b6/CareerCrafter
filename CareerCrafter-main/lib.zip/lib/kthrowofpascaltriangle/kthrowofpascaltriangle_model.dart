import '/flutter_flow/flutter_flow_util.dart';
import 'kthrowofpascaltriangle_widget.dart' show KthrowofpascaltriangleWidget;
import 'package:flutter/material.dart';

class KthrowofpascaltriangleModel
    extends FlutterFlowModel<KthrowofpascaltriangleWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
