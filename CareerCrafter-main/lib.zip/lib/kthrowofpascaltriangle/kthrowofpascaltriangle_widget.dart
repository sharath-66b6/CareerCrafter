import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'kthrowofpascaltriangle_model.dart';
export 'kthrowofpascaltriangle_model.dart';

class KthrowofpascaltriangleWidget extends StatefulWidget {
  const KthrowofpascaltriangleWidget({super.key});

  @override
  State<KthrowofpascaltriangleWidget> createState() =>
      _KthrowofpascaltriangleWidgetState();
}

class _KthrowofpascaltriangleWidgetState
    extends State<KthrowofpascaltriangleWidget> {
  late KthrowofpascaltriangleModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => KthrowofpascaltriangleModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Kth Row of Pascal\'s Triangle',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 800.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nGiven an index k, return the kth row of the Pascal\'s triangle.\nPascal\'s triangle: To generate A[C] in row R, sum up A\'[C] and A\'[C-1] from previous row R - 1.\n\nExample:\n\nInput : k = 3\n\n\nReturn : [1,3,3,1]\n\nNote: k is 0 based. k = 0, corresponds to the row [1]. \n\nNote: Could you optimize your algorithm to use only O(k) extra space?\n\nAnswer :-\n/**\n * @input A : Integer\n * \n * @Output Integer array. You need to malloc memory for result array, and fill result\'s length in length_of_array\n */\nint* getRow(int A, int *length_of_array) {\n    *length_of_array = A + 1; // length of result array\n    int *result = (int *) malloc(*length_of_array * sizeof(int));\n    int i, x = 1;\n    for(i = 0; i <= A; i++){\n\t\tresult[i] = x;\n\t\tx = x*(A - i)/(i + 1);\n\t}\n\treturn result;\n}',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=bcsc9c3P5hc&pp=ygUeaW50ZXJ2aWV3Yml0IGt0aCByb3cgb2YgcGFzY2Fs',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
