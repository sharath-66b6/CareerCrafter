import '/flutter_flow/flutter_flow_util.dart';
import 'excelcloumnnumber_widget.dart' show ExcelcloumnnumberWidget;
import 'package:flutter/material.dart';

class ExcelcloumnnumberModel extends FlutterFlowModel<ExcelcloumnnumberWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
