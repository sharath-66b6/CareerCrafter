import '/flutter_flow/flutter_flow_util.dart';
import 'maxcontiunousseriesof1s_widget.dart' show Maxcontiunousseriesof1sWidget;
import 'package:flutter/material.dart';

class Maxcontiunousseriesof1sModel
    extends FlutterFlowModel<Maxcontiunousseriesof1sWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
