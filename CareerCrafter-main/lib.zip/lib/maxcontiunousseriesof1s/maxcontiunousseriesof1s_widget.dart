import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'maxcontiunousseriesof1s_model.dart';
export 'maxcontiunousseriesof1s_model.dart';

class Maxcontiunousseriesof1sWidget extends StatefulWidget {
  const Maxcontiunousseriesof1sWidget({super.key});

  @override
  State<Maxcontiunousseriesof1sWidget> createState() =>
      _Maxcontiunousseriesof1sWidgetState();
}

class _Maxcontiunousseriesof1sWidgetState
    extends State<Maxcontiunousseriesof1sWidget> {
  late Maxcontiunousseriesof1sModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => Maxcontiunousseriesof1sModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Max Continuous Series of 1s',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2000.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven a binary array A, find the maximum sequence of continuous 1\'s that can be formed by replacing at-most B zeroes.\n\nFor this problem, return the indices of maximum continuous series of 1s in order.\n\nIf there are multiple possible solutions, return the sequence which has the minimum start index.\n\n\n\nProblem Constraints\n 0 <= B <= 105\n\n 1 <= size(A) <= 105\n\n 0 <= A[i] <= 1\n\n\n\nInput Format\nFirst argument is an binary array A.\n\nSecond argument is an integer B.\n\n\n\nOutput Format\n Return an array of integers denoting the indices(0-based) of 1\'s in the maximum continuous series.\n\n\n\nExample Input\nInput 1:\n\n A = [1 1 0 1 1 0 0 1 1 1 ]\n B = 1\nInput 2:\n\n A = [1, 0, 0, 0, 1, 0, 1]\n B = 2\n\n\nExample Output\nOutput 1:\n\n [0, 1, 2, 3, 4]\nOutput 2:\n\n [3, 4, 5, 6]\n\n\nExample Explanation\nExplanation 1:\n\n Flipping 0 present at index 2 gives us the longest continous series of 1\'s i.e subarray [0:4].\nExplanation 2:\n\n Flipping 0 present at index 3 and index 5 gives us the longest continous series of 1\'s i.e subarray [3:6].\n\n\n\n\nAnswer :-\nint* maxone(int* A, int n1, int B, int *len1) {\n    int *result=(int *)malloc(n1*sizeof(int));\n    int wl=0,wr=0,nzero=0,bestwindow=-1,p,q,i;\n    while(wr<n1){\n        if(nzero<=B){\n            if(A[wr]==0){\n                nzero++;\n            }\n            wr++;\n        }\n        if(nzero>B){\n            if(A[wl]==0){\n                nzero--;\n            }\n            wl++;\n        }\n        if(wr-wl>bestwindow){\n            bestwindow=wr-wl;\n            p=wl;\n            q=wr;\n        }\n    }\n    //k=p;\n    for(i=p;i<q;i++){\n        result[i-p]=i;\n        \n    }\n    *len1=bestwindow;\n    return result;\n    \n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=DK8ivccaO5o&pp=ygUoaW50ZXJ2aWV3Yml0IG1heCBjb250aW51b3VzIHNlcmllcyBvZiAxcw%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
