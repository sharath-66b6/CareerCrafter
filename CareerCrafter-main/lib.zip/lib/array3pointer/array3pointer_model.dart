import '/flutter_flow/flutter_flow_util.dart';
import 'array3pointer_widget.dart' show Array3pointerWidget;
import 'package:flutter/material.dart';

class Array3pointerModel extends FlutterFlowModel<Array3pointerWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
