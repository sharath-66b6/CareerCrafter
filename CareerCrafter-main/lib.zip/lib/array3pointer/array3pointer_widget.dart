import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'array3pointer_model.dart';
export 'array3pointer_model.dart';

class Array3pointerWidget extends StatefulWidget {
  const Array3pointerWidget({super.key});

  @override
  State<Array3pointerWidget> createState() => _Array3pointerWidgetState();
}

class _Array3pointerWidgetState extends State<Array3pointerWidget> {
  late Array3pointerModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => Array3pointerModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Array 3 Pointers',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1000.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \nYou are given 3 arrays A, B and C. All 3 of the arrays are sorted.\n\nFind i, j, k such that :\n\nmax(abs(A[i] - B[j]), abs(B[j] - C[k]), abs(C[k] - A[i])) is minimized.\n\nReturn the minimum max(abs(A[i] - B[j]), abs(B[j] - C[k]), abs(C[k] - A[i]))\n\n**abs(x) is absolute value of x and is implemented in the following manner : **\n\n      if (x < 0) return -x;\n      else return x;\nExample :\n\nInput : \n        A : [1, 4, 10]\n        B : [2, 15, 20]\n        C : [10, 12]\n\nOutput : 5 \n         With 10 from A, 15 from B and 10 from C. \n\n\n\n\nAnswer :-\nint minimize(const int* A, int n1, const int* B, int n2, const int* C, int n3) {\n    int i=0,j=0,k=0,l=1<<31,n,m,h;\n    l++;\n    l=-l;\n    while(i<n1 && j<n2 && k<n3)\n    {\n        int min=A[i]<B[j]?A[i]:B[j];\n        min=min<C[k]?min:C[k];\n        int max=A[i]>B[j]?A[i]:B[j];\n        max=max>C[k]?max:C[k];\n        n=max-min;\n        if(n<l)\n            l=n;\n        if(A[i]==min)i++;\n        else if(B[j]==min)j++;\n        else k++;\n    }\n    return l;\n}',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=BlXTlC6_Xv4&pp=ygUbaW50ZXJ2aWV3Yml0IGFycmF5M3BvaW50ZXJz',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
