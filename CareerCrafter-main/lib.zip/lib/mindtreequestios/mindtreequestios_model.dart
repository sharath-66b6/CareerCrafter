import '/flutter_flow/flutter_flow_util.dart';
import 'mindtreequestios_widget.dart' show MindtreequestiosWidget;
import 'package:flutter/material.dart';

class MindtreequestiosModel extends FlutterFlowModel<MindtreequestiosWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
