import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'mindtreequestios_model.dart';
export 'mindtreequestios_model.dart';

class MindtreequestiosWidget extends StatefulWidget {
  const MindtreequestiosWidget({super.key});

  @override
  State<MindtreequestiosWidget> createState() => _MindtreequestiosWidgetState();
}

class _MindtreequestiosWidgetState extends State<MindtreequestiosWidget> {
  late MindtreequestiosModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MindtreequestiosModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).primary,
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30.0,
            borderWidth: 1.0,
            buttonSize: 60.0,
            icon: const Icon(
              Icons.arrow_back_rounded,
              color: Colors.white,
              size: 30.0,
            ),
            onPressed: () async {
              context.pop();
            },
          ),
          title: Text(
            'MindTree Interview Questions',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: 'Outfit',
                  color: Colors.white,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                ),
          ),
          actions: const [],
          centerTitle: true,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: ListView(
            padding: const EdgeInsets.symmetric(vertical: 12.0),
            scrollDirection: Axis.vertical,
            children: [
              Container(
                width: 100.0,
                height: 1000.0,
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryBackground,
                ),
                child: Align(
                  alignment: const AlignmentDirectional(0.0, -1.0),
                  child: Text(
                    'HR Interviews: The next round of assessment after the technical interviews is the HR interviews. The company wants to assess whether or not you will be a cultural fit for the company. MindTree lays great stress on the HR interviews. Make sure to go through the vision of the company and its leadership principles before you appear for an HR interview. Try to knit your answers accordingly. It is really important to be well prepared for the HR interviews. This round should not be taken lightly.\nMake sure that you are well prepared for any questions that the interviewer may ask based on things that you have mentioned in your resume. So it is important to make sure that you mention things that are true to the best of your knowledge in the resume. \nFollowing is a list of the most frequently asked questions in an HR Interview:\nTell me about yourself in a few words.\nWould you consider relocating to another part of India?\nWhat do you hope to get out of this job?\nWhat drew you to MindTree in the first place?\nIn five years, where do you see yourself?\nTell me about your internships and projects.\nWhat prompted you to look for a new job? (Many seasoned professionals on the lookout for a new job ask this question.)\nTell me about a moment when you faced a challenge and how you dealt with it.\nLet\'s pretend you\'re in charge of a group. One of your team members is underperforming and, despite many warnings, refuses to modify his or her attitude. What will you do if you find yourself in this situation?\nDescribe a circumstance in which you tried your hardest but failed.',
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Readex Pro',
                          letterSpacing: 0.0,
                        ),
                  ),
                ),
              ),
            ].divide(const SizedBox(height: 12.0)),
          ),
        ),
      ),
    );
  }
}
