import '/flutter_flow/flutter_flow_util.dart';
import 'heapsnadmaps_widget.dart' show HeapsnadmapsWidget;
import 'package:flutter/material.dart';

class HeapsnadmapsModel extends FlutterFlowModel<HeapsnadmapsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
