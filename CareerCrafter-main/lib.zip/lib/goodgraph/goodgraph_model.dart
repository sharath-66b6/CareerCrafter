import '/flutter_flow/flutter_flow_util.dart';
import 'goodgraph_widget.dart' show GoodgraphWidget;
import 'package:flutter/material.dart';

class GoodgraphModel extends FlutterFlowModel<GoodgraphWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
