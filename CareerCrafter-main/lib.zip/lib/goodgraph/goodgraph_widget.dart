import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'goodgraph_model.dart';
export 'goodgraph_model.dart';

class GoodgraphWidget extends StatefulWidget {
  const GoodgraphWidget({super.key});

  @override
  State<GoodgraphWidget> createState() => _GoodgraphWidgetState();
}

class _GoodgraphWidgetState extends State<GoodgraphWidget> {
  late GoodgraphModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => GoodgraphModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Good Graph',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1700.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven a directed graph of N nodes where each node is pointing to any one of the N nodes (can possibly point to itself). Ishu, the coder, is bored and he has discovered a problem out of it to keep himself busy.\n\nThe problem is as follows:\n\nA node is \'good\' if it satisfies one of the following:\nIt is the special node (marked as node 1)\nIt is pointing to the special node (node 1)\nIt is pointing to a good node.\n\nIshu is going to change the pointers of some nodes to make them all \'good\'. You have to find the min. the number of pointers to change in order to make all the nodes good (Thus, a Good Graph).\n\nNote: Resultant Graph should hold the property that all nodes are good and each node must point to exactly one node.\n\n\nProblem Constraints\n1 <= N <= 100,000\n\n\nInput Format\nA vector of N integers containing N numbers all between 1 to N, where i-th number is the number of node that i-th node is pointing to.\n\n\nOutput Format\nAn Integer denoting min. number of pointer changes.\n\n\nExample Input\nInput 1:\nA = [1, 2, 1, 2]\nInput 2:\nA = [3, 1, 3, 1]\n\n\nExample Output\nOutput 1:\n1\nOutput 2:\n1\n\n\nExample Explanation\nExplanation 1:\nPointer of node 2 is made to point to node 1\nExplanation 2:\nPointer of node 3 is made to point to node 1\n\n\n\nAnswer :-\nclass Solution:\n    # @param A : list of integers\n    # @return an integer\n    def solve(self, A):\n        n=len(A)\n        dsu=[i for i in range(n+1)]\n        def find(x):\n            while(x!=dsu[x]):\n                dsu[x]=dsu[dsu[x]]\n                x=dsu[x]\n            return x\n        ans=0\n        for i in range(1,n):\n            u=i+1\n            v=A[i]\n            if v==1:\n                one=1\n   #         print(u,v)\n            dsu[find(u)]=find(v)\n  #      print dsu\n        for i in range(2,n+1):\n            if dsu[i]==i:\n                ans+=1\n        return ans\n            \n        ',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=VjeeyLctD2s&pp=ygUXaW50ZXJ2aWV3Yml0IGdvb2QgZ3JhcGg%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
