import '/flutter_flow/flutter_flow_util.dart';
import 'behaviouralhrinterviewquestions_widget.dart'
    show BehaviouralhrinterviewquestionsWidget;
import 'package:flutter/material.dart';

class BehaviouralhrinterviewquestionsModel
    extends FlutterFlowModel<BehaviouralhrinterviewquestionsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
