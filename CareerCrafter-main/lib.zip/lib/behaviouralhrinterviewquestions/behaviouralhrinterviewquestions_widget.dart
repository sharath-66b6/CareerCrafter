import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'behaviouralhrinterviewquestions_model.dart';
export 'behaviouralhrinterviewquestions_model.dart';

class BehaviouralhrinterviewquestionsWidget extends StatefulWidget {
  const BehaviouralhrinterviewquestionsWidget({super.key});

  @override
  State<BehaviouralhrinterviewquestionsWidget> createState() =>
      _BehaviouralhrinterviewquestionsWidgetState();
}

class _BehaviouralhrinterviewquestionsWidgetState
    extends State<BehaviouralhrinterviewquestionsWidget> {
  late BehaviouralhrinterviewquestionsModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => BehaviouralhrinterviewquestionsModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).primary,
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30.0,
            borderWidth: 1.0,
            buttonSize: 60.0,
            icon: const Icon(
              Icons.arrow_back_rounded,
              color: Colors.white,
              size: 30.0,
            ),
            onPressed: () async {
              context.pop();
            },
          ),
          title: Text(
            'Behavioural HR Interview Questions',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: 'Outfit',
                  color: Colors.white,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                ),
          ),
          actions: const [],
          centerTitle: true,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: ListView(
            padding: const EdgeInsets.symmetric(vertical: 12.0),
            scrollDirection: Axis.vertical,
            children: [
              Container(
                width: 100.0,
                height: 6000.0,
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryBackground,
                ),
                child: Align(
                  alignment: const AlignmentDirectional(0.0, -1.0),
                  child: Text(
                    '1. What Are These Behavioural Questions\nThese questions are mostly of the format “Tell me about a time…” where you would be asked to share your experience based on certain scenarios which would help the interviewer judge how well you handled various work situations thereby reflecting your skills, capacity, and personality.\n\nAlways answer such types of questions using the STAR format to provide structured answers. STAR has the following questions to be answered in the same order:\n\nSituation: What was the situation/event?\nTask: What were the tasks involved in the above-mentioned situation?\nAction: What did you do to complete the goal?\nResult: What was the result of the actions? This is the most important part which conveys if you were successful or not.\nAvoid bragging and exaggerating at all costs.\n\n\n\n------------------------------------\n\n\n\n2. Tell me about a time when you were not satisfied with your performance?\nHere, the interviewer gets to know the extent of ownership you take while performing any task. It also reflects how well you care about the job and the company.\n\nSample answer:\n\nWhen I initially joined my job right after college, there was a point where I was constantly becoming dependent on the team members to get work done. I did not like this as I wanted to carry out my responsibilities in an independent manner along with working in a team. I wasted no time and quickly learned the working dynamics of the project and received various assignments related to the project. The more assignments I worked on with minimal help, the more confident I became and the more sense of ownership is provided. I felt more independent and I was lauded multiple times for my dedication, my sense of ownership, and how quickly I was able to adapt to the project.\n\n\n\n__________________________\n\n\n\n3. Tell me about a time when you were made to work under close supervision.\nHere, the interviewer evaluates how well you work in a team and how well you can work independently.\n\nSample answer:\n\nIn my previous job, I was working under the close supervision of my manager. It felt very overwhelming as the manager watched everything that I do throughout the day and I felt like he/she was virtually sitting by me at all times. I was uncomfortable with this because of the constant pressure involved. But then, I found out that the manager did not trust me enough to do my job alone as I was very new to it. So I worked on building her trust by working very diligently without any complaints in the projects and once I felt the manager was convinced of my abilities, I discussed with her to hand me a project which didn’t involve such close supervision. The manager gave me one such project reluctantly and I made sure I gave my best to it and the project was launched successfully which is how I gained her complete trust.\n\n\n\n_________________________________\n\n\n\n4. Can you tell me about a time where you were happy with your work and what was your reaction?\nBy asking this question, the interviewer wants to understand what success means to you and what feeling it brings out in you. By this, they can assess your concerns for the growth of the company along with your personal growth.\n\nSample answer:\n\nThere was a time in my previous company where I was handling a project related to blogging that would potentially inspire a lot of people. So I worked on researching what topics would people get inspiration from and what would help them be better. I also conducted a survey which I shared with my friends, neighbors and relatives to get better insights about this. When we published the blog, the recognition that we got was tremendous. People loved how relatable the posts were and this turned out to be a significant reason behind the 90% sales of our products. I was very happy with my work as I did my part in contributing to company profits as well as providing a platform to people where they can get inspiration from.\n\n\n\n_______________________________\n\n\n\n5. Tell me about a time where you experienced difficulty at work while working on a project.\nNow, this is a broad question as difficulty can be of any type. This question is asked to assess what are the things that you consider as difficult and how you go about solving that difficulty. While answering this:\n\nFocus on describing a problem that was related to your work using the STAR approach.\nDo not answer negatively or bad mouth any supervisor or any company.\nThe interviewer should be made to understand the cause of the problem.\nAvoid bringing up personal problems in your life.\nFocus on the learnings of the problem rather than dwelling too much on the damage.\nSample answer:\n\nThere was a time in my current company when I received a bug report from our client which stated that the databases were performing below the mark when a complex query was called excessively from the interface.\n\nThe first thing I did was checking the logs to perform the root cause analysis. Doing this gave me a rough idea regarding where the bug started appearing. I reproduced the bug only on the production server and I tried replicating the same on my local system. While debugging, I found out that there was a bug in the Java code where some lines were commented out by the developers who had already left this company.\n\nI fixed this code quickly and did a round of performance testing on the application to ensure that this doesn’t occur again. The issue was fixed at the end of the day and we were able to get the server up and running with enhanced performance. We learnt an important lesson to perform regression testing after every phase of releases to ensure the old functionalities were working fine along with the newly developed ones.\n\n\n\n__________________________________\n\n\n\n6. Tell me about a time where you displayed leadership skills.\nThis question is asked to check how competent you are in a particular situation. You have to ensure that you are not sounding lazy or unprofessional.\n\nSample answer:\n\nI remember this event. Every year, my company used to organize a summer barbeque, and this year, the person who was supposed to organize had left for a new job. I used to volunteer for this before so I volunteered myself for organizing the barbeque this year.\n\nThe annual barbeque was a potluck event with some fun activities planned throughout the day. I conducted a survey amongst the employees to see what kind of activities they were interested in. I made a list of those activities and created teams dedicated to conducting each of them. I also ensured that activities did not cross the budget allocated and took care of sending out regular reminders to track the progress of the team. I sent out posters and went through the office floors with a team of people to make sure people are aware of what exciting things we have planned for them and ensure that they arrive at the venue on time. The day of the event was an amazing one. As we had everything planned, the event went on smoothly and everyone had loads of fun.\n\nI received great appreciation from the higher management for my organizational skills and everyone said that they had a great time.\n\n\n\n____________________________\n\n\n\n7. Was there any point in your career where you made any mistake? Tell me about it.\nNow here is a tricky behavioral question and if you don’t answer this carefully, you would be digging your own grave. The interviewer wants to understand what kind of mistakes you made, how did you approach it and how well you would perform if you are hired for the job. Some tips to answer the question:\n\nTalk about a mistake you made which you were able to rectify and which didn’t cause any critical damage to your organization.\nTalk about what you learned while working on fixing the mistake.\nAvoid any mistake that represents any flaw in your personality.\nSample answer:\n\nI remember an instance when I joined my first company. I was asked to work on two projects simultaneously and I accepted it even though I knew I would not be able to handle it. I did not want to tell my manager that I cannot handle it as I did not want him to think less of me. I was not supposed to tell either of clients that I was working on another project which caused me double stress due to which I was not able to meet the deadlines for the assignments. I realized I should have clearly communicated this with my manager and then my manager understood the situation and allocated a new resource to work with me to complete the project delivery. I learned the importance of keeping my supervisors updated with any task and being open to them if I am facing any roadblocks.\n\n\n\n______________________________\n\n\n\n8. How did you handle disagreements with your manager?\nThe interviewers want to know how well you deal when your ideas are disagreed by your manager/supervisor. Disagreements are part and parcel of working in a team. Hence, the recruiter wants to know if you are capable of handling such disagreements and how well you plan to develop the relationship with the manager.\n\nSome tips to answer this question:\n\nExplain what the disagreement was.\nHow did you overcome that?\nWhat was your learning outcome?\nDo not speak ill or abuse your manager.\nYou can not tell that you never had a disagreement before as it would just prove that you do not have a sense of leadership or you lack creativity.\nSample answer:\n\nThis reminds me of an instance where I and my manager had a disagreement on why a certain feature has to be included in the product and he was against it. We had lots of discussions regarding the pros and cons of that feature. During this, I explained to him why adding that feature to our website would be the best thing to do and how it would make the lives of our users easier. I gave him various scenarios and good reasons why that feature would be a great idea. My manager was convinced as he felt the reasons were good enough and we got his green signal to work on it. In the end, when we unveiled this feature to our client, the clients were indeed very happy and praised us all as we went out of our way to add this feature. My manager was very happy with the result. I learned that effective and graceful communication is the ultimate key. Ideas should be respectfully conveyed to people when there are disagreements as we belong to a team and the collective vision of the team is to launch the project successfully. In case my manager’s idea was best for the project, then I would gracefully accept that too.\n\n\n\n________________________________\n\n\n\n\n\n9. Tell me how you will handle it if suddenly the priorities of a project were changed?\nHere, the interviewers want to know how the candidate will act in the situation when priorities are changed. This will also reflect the candidate’s ability to handle stress and solve problems.\n\nSome tips to answer this question:\n\nMake sure that you convey the right things to the interviewer.\nGive instances of how well you are capable of handling pressure and stress.\nAvoid boasting and no matter how frustrated you were during these situations, do not tell the interviewer.\nSample answer:\n\nI certainly understand that there might be valid reasons for a company to change the priority of a project. The vision of a project at one particular point of time would change at another time due to various conditions. If the priority of the task that I work on gets changed, I will put efforts into understanding why this happened and I will consider that it is in the best interest of the company and start to work on the new task of higher priority rather than crib about it. The ultimate goal is to achieve big things by putting in my best efforts.\n\n\n\n\n\n____________________________',
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Readex Pro',
                          letterSpacing: 0.0,
                        ),
                  ),
                ),
              ),
            ].divide(const SizedBox(height: 12.0)),
          ),
        ),
      ),
    );
  }
}
