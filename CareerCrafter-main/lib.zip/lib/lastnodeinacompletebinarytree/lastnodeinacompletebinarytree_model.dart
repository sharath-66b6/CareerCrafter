import '/flutter_flow/flutter_flow_util.dart';
import 'lastnodeinacompletebinarytree_widget.dart'
    show LastnodeinacompletebinarytreeWidget;
import 'package:flutter/material.dart';

class LastnodeinacompletebinarytreeModel
    extends FlutterFlowModel<LastnodeinacompletebinarytreeWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
