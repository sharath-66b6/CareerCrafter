import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'lastnodeinacompletebinarytree_model.dart';
export 'lastnodeinacompletebinarytree_model.dart';

class LastnodeinacompletebinarytreeWidget extends StatefulWidget {
  const LastnodeinacompletebinarytreeWidget({super.key});

  @override
  State<LastnodeinacompletebinarytreeWidget> createState() =>
      _LastnodeinacompletebinarytreeWidgetState();
}

class _LastnodeinacompletebinarytreeWidgetState
    extends State<LastnodeinacompletebinarytreeWidget> {
  late LastnodeinacompletebinarytreeModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => LastnodeinacompletebinarytreeModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Last Node in a Complete Binary Tree',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2100.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nYou are given the root of a complete binary tree A.\n\nYou have to return the value of the rightmost node in the last level of the binary tree.\n\nTry to find a solution with a better time complexity than O(N).\n\n\n\nProblem Constraints\n1 <= Number of nodes in the binary tree <= 105\n\n\nInput Format\nThe first argument is the root of a binary tree A.\n\n\nOutput Format\nReturn a single integer denoting the value of the rightmost node in the last level of the binary tree.\n\n\nExample Input\nInput 1:\nA = \n    1\n   /\n  2\nInput 2:\n\nA = \n    1\n   / \\\n  2   3\n\n\nExample Output\nOutput 1:\n2\nOutput 2:\n\n3\n\n\nExample Explanation\nExplanation 1:\nThere is only a single node in the last level of the binary tree.\nTherefore, the answer is 2.\nExplanation 2:\n\nThere a two nodes in the last level of the tree.\nThe rightmost nodes is 3.\n\n\n\nAnswer :-\n/**\n * Definition for binary tree\n * struct TreeNode {\n *     int val;\n *     struct TreeNode *left;\n *     struct TreeNode *right;\n * };\n * \n * typedef struct TreeNode treenode;\n * \n * treenode* treenode_new(int val) {\n *     treenode* node = (treenode *) malloc(sizeof(treenode));\n *     node->val = val;\n *     node->left = NULL;\n *     node->right = NULL;\n *     return node;\n * }\n */\n/**\n * @input A : Root pointer of the tree \n * \n * @Output Integer\n */\n int ans;\n int l;\n void solve(treenode* root,int level)\n {\n     if(!root)\n     return;\n     solve(root->right,level+1);\n     solve(root->left,level+1);\n     if(ans==-1 || level>l)\n     {\n         ans=root->val;\n         l=level;\n     }\n     return ;\n\n }\nint lastNode(treenode* root) {\n    ans=-1;\n    l=-1;\n    solve(root,0);\n    return ans;\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=olbiZ-EOSig&pp=ygUwaW50ZXJ2aWV3Yml0IGxhc3Qgbm9kZSBpbiBhIGNvbXBsZXRlIGJpbmFyeSB0cmVl',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
