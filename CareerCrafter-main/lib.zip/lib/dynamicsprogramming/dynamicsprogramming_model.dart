import '/flutter_flow/flutter_flow_util.dart';
import 'dynamicsprogramming_widget.dart' show DynamicsprogrammingWidget;
import 'package:flutter/material.dart';

class DynamicsprogrammingModel
    extends FlutterFlowModel<DynamicsprogrammingWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
