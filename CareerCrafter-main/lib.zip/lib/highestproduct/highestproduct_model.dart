import '/flutter_flow/flutter_flow_util.dart';
import 'highestproduct_widget.dart' show HighestproductWidget;
import 'package:flutter/material.dart';

class HighestproductModel extends FlutterFlowModel<HighestproductWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
