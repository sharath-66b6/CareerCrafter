import '/flutter_flow/flutter_flow_util.dart';
import 'codenationquestion_widget.dart' show CodenationquestionWidget;
import 'package:flutter/material.dart';

class CodenationquestionModel
    extends FlutterFlowModel<CodenationquestionWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
