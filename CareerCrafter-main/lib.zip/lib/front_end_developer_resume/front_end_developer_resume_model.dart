import '/flutter_flow/flutter_flow_util.dart';
import 'front_end_developer_resume_widget.dart'
    show FrontEndDeveloperResumeWidget;
import 'package:flutter/material.dart';

class FrontEndDeveloperResumeModel
    extends FlutterFlowModel<FrontEndDeveloperResumeWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
