import '/flutter_flow/flutter_flow_util.dart';
import 'ebayquestions_widget.dart' show EbayquestionsWidget;
import 'package:flutter/material.dart';

class EbayquestionsModel extends FlutterFlowModel<EbayquestionsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
