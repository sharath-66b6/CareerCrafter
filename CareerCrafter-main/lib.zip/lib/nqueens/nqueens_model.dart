import '/flutter_flow/flutter_flow_util.dart';
import 'nqueens_widget.dart' show NqueensWidget;
import 'package:flutter/material.dart';

class NqueensModel extends FlutterFlowModel<NqueensWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
