import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'nqueens_model.dart';
export 'nqueens_model.dart';

class NqueensWidget extends StatefulWidget {
  const NqueensWidget({super.key});

  @override
  State<NqueensWidget> createState() => _NqueensWidgetState();
}

class _NqueensWidgetState extends State<NqueensWidget> {
  late NqueensModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => NqueensModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'NQueens',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2000.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \nThe n-queens puzzle is the problem of placing n queens on an n×n chessboard such that no two queens attack each other.\nGiven an integer n, return all distinct solutions to the n-queens puzzle.\n\nEach solution contains a distinct board configuration of the n-queens’ placement, where \'Q\' and \'.\' both indicate a queen and an empty space respectively.\n\nFor example,\n\nThere exist two distinct solutions to the 4-queens puzzle:\n\n[\n [\".Q..\",  // Solution 1\n  \"...Q\",\n  \"Q...\",\n  \"..Q.\"],\n\n [\"..Q.\",  // Solution 2\n  \"Q...\",\n  \"...Q\",\n  \".Q..\"]\n]\n\n\n\nAnswer :-\n/**\n * @input A : Integer\n * \n * @Output 2D string array. You need to malloc memory. Fill in len1 as row, len2 as columns. All strings should end with \'\\0\'. \n * For example, a valid output : [[\"..Q.\",\"Q...\", \"...Q\", \".Q..\" ], [\".Q..\", \"...Q\", \"Q...\", \"..Q.\"]] \n * len1 = 2, len2 = 4. \n */\nint RecPlaceQueen(int A, char ** cur,int row,int count,char  *** out);\nvoid copyBoard(char ** out, char ** cur, int A);\nint isValid(char ** cur, int row, int col, int A);\nchar*** solveNQueens(int A, int *len1, int *len2) {\n    char *** out = (char ***)malloc(sizeof(char **)* 1000);\n    char ** cur = (char **)(malloc(sizeof(int *)* A));\n    int i;\n    for(i=0;i<A;i++)\n        cur[i]=(char *)malloc(sizeof(int)*A);\n        \n    int count = RecPlaceQueen(A,cur,0,0,out);\n    *len1=count;\n    *len2=A;\n    return out;\n}\n\nint RecPlaceQueen(int A, char ** cur, int row, int count, char ***out){\n    int col;\n    int i,j,k;\n    if(row==A){\n        out[count]=(char **)(malloc(sizeof(char*) * A));\n        copyBoard(out[count],cur,A);\n        count=count+1;\n        return count;\n        \n    }\n    for(col=0;col<A;col++)\n        if(isValid(cur,row,col,A))\n            count=RecPlaceQueen(A,cur,row+1,count,out);\n    return count;\n}\n\nvoid copyBoard(char ** out, char ** cur, int A){\n    int i,j;\n    for(i=0;i<A;i++){\n        out[i]=(char *)malloc(sizeof(char)*A);\n        for(j=0;j<A;j++)\n            out[i][j]=cur[i][j];\n        \n    }\n}\nint isValid(char ** cur, int row, int col, int A){\n    int i,j, diff;\n    for(i=0;i<row;i++){\n        for(j=0;j<A;j++)\n            if(cur[i][j]==\'Q\')\n                break;\n        if(j==col)\n            return 0;\n        diff=j-col;\n        if(diff<0)\n            diff=diff*(-1);\n        if(row-i == diff)\n            return 0;\n    }\n    for(i=0;i<A;i++)\n        cur[row][i]=\'.\';\n    cur[row][col]=\'Q\';\n    return 1;\n            \n    }\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=i05Ju7AftcM&pp=ygUUaW50ZXJ2aWV3Yml0IG5xdWVlbnM%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
