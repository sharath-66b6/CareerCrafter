import '/flutter_flow/flutter_flow_util.dart';
import 'googlequestion_widget.dart' show GooglequestionWidget;
import 'package:flutter/material.dart';

class GooglequestionModel extends FlutterFlowModel<GooglequestionWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
