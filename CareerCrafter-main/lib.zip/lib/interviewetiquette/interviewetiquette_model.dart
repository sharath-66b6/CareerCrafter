import '/flutter_flow/flutter_flow_util.dart';
import 'interviewetiquette_widget.dart' show InterviewetiquetteWidget;
import 'package:flutter/material.dart';

class InterviewetiquetteModel
    extends FlutterFlowModel<InterviewetiquetteWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
