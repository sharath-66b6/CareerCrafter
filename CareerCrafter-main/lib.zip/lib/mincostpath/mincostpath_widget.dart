import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'mincostpath_model.dart';
export 'mincostpath_model.dart';

class MincostpathWidget extends StatefulWidget {
  const MincostpathWidget({super.key});

  @override
  State<MincostpathWidget> createState() => _MincostpathWidgetState();
}

class _MincostpathWidgetState extends State<MincostpathWidget> {
  late MincostpathModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MincostpathModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Min Cost Path',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2700.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nYou are given a AB character matrix named C. Every cell in C has a character U,R,L or D indicating up,right,left and down.\n\nYour target is to go from top left corner to the bottom right corner of the matrix.\n\nBut there are some restrictions while moving along the matrix:\n\nIf you follow what is written in the cell then you can move freely.\nBut if you don\'t follow what is written in the cell then you have to pay 1 unit of cost.\nLike: If a cell contains character U and you go right instead of Up you have to pay 1 unit of cost.\n\nSo your task is to find the minimum cost to go from top-left corner to the bottom-right corner.\n\n\n\nProblem Constraints\n1 <= A,B <= 103\nC[i][j] can be either U,R,L or D.\n\n\nInput Format\nFirst Argument represents a integer A (number of rows).\nSecond Argument represents a integer B (number of columns).\nThird Argument represents a string array C which contains A strings each of length B.\n\n\nOutput Format\n Return an integer denoting the minimum cost to travel from top-left corner to bottom-right corner.\n\n\n\nExample Input\nInput:1\n\n A = 3\n B = 3\n C = [\"RRR\",\"DDD\",\"UUU\"]\nInput:2\n\n A = 1\n B = 4\n C = [\"LLLL\"]\n\n\nExample Output\nOutput-1 :\n\n 1\nOutput-2 :\n\n 3\n\n\nExample Explanation*\nExplanation for Input-1:\n\n Matrix looks like: RRR\n                    DDD\n                    UUU\n We go right two times and down two times.\n So from top-right cell we are going down though right is given so this incurs a cost of 1.\nExplanation for Input-2:\n\n Matrix looks like: LLLL\n We go right three times.\n\n\n\nAnswer :-\nimport collections\nclass Solution:\n    # @param A : integer\n    # @param B : integer\n    # @param C : list of strings\n    # @return an integer\n    def solve(self, A, B, C):\n        queue = collections.deque([])\n        queue.append((0,0,0))\n        #answer = 999\n        completed = [[False for i in range(B)] for j in range(A)]\n        \n        while(len(queue) != 0):\n            i,j,cost = queue.popleft()\n            if(completed[i][j] == True):\n                continue\n            \n            completed[i][j] = True\n            \n            if(i == A-1 and j == B-1):\n                return cost\n            \n            if(j+1<B and not completed[i][j+1]):\n            \n                \n                if(C[i][j] == \'R\'):\n                    queue.appendleft(( i, j+1,cost))\n                else:\n                    queue.append(( i, j+1,cost+1))\n        \n            \n            if(i+1<A and not completed[i+1][j]):\n            \n                \n                if(C[i][j] == \'D\'):\n                    queue.appendleft(( i+1, j,cost))\n                else:\n                    queue.append(( i+1, j,cost+1))\n        \n            \n            if(j-1>=0 and not completed[i][j-1]):\n            \n                \n                if(C[i][j] == \'L\'):\n                    queue.appendleft(( i, j-1,cost))\n                else:\n                    queue.append(( i, j-1,cost+1))\n        \n            if(i-1>=0 and not completed[i-1][j]):\n                \n                if(C[i][j] == \'U\' ):\n                    queue.appendleft(( i-1, j,cost))\n                else:\n                    queue.append(( i-1, j,cost+1))\n            \n        \n            \n        return cost\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=VSKkW1JsXr0&pp=ygUaaW50ZXJ2aWV3Yml0IG1pbiBjb3N0IHBhdGg%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
