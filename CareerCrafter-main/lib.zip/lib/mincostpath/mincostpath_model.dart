import '/flutter_flow/flutter_flow_util.dart';
import 'mincostpath_widget.dart' show MincostpathWidget;
import 'package:flutter/material.dart';

class MincostpathModel extends FlutterFlowModel<MincostpathWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
