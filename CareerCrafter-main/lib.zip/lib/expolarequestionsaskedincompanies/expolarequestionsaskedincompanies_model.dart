import '/flutter_flow/flutter_flow_util.dart';
import 'expolarequestionsaskedincompanies_widget.dart'
    show ExpolarequestionsaskedincompaniesWidget;
import 'package:flutter/material.dart';

class ExpolarequestionsaskedincompaniesModel
    extends FlutterFlowModel<ExpolarequestionsaskedincompaniesWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
