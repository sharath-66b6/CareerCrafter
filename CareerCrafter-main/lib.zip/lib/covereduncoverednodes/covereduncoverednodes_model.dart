import '/flutter_flow/flutter_flow_util.dart';
import 'covereduncoverednodes_widget.dart' show CovereduncoverednodesWidget;
import 'package:flutter/material.dart';

class CovereduncoverednodesModel
    extends FlutterFlowModel<CovereduncoverednodesWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
