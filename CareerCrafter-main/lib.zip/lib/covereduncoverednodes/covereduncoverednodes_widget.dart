import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'covereduncoverednodes_model.dart';
export 'covereduncoverednodes_model.dart';

class CovereduncoverednodesWidget extends StatefulWidget {
  const CovereduncoverednodesWidget({super.key});

  @override
  State<CovereduncoverednodesWidget> createState() =>
      _CovereduncoverednodesWidgetState();
}

class _CovereduncoverednodesWidgetState
    extends State<CovereduncoverednodesWidget> {
  late CovereduncoverednodesModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CovereduncoverednodesModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Covered / Uncovered Nodes',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 3500.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nYou are given the root of a binary tree A, you need to return the absolute difference between sum of all covered elements and the sum of all uncovered elements.\n\nIn a binary tree, a node is called Uncovered if it appears either on left boundary or right boundary. Rest of the nodes are called covered.\n\n\n\nProblem Constraints\n1 <= Number of nodes in the binary tree <= 105\n\n\nInput Format\nThe first argument is the root of the binary tree A.\n\n\nOutput Format\nReturn a single integer denoting the absolute difference of the sum of covered and uncovered nodes.\n\n\nExample Input\nInput 1:\n    2\n   / \\\n  1   4\n /   / \\\n6  10   5\nInput 2:\n\n      1\n     /\n    2\n   /\n  3\n\n\nExample Output\nOutput 1:\n8\nOutput 2:\n\n6\n\n\nExample Explanation\nExplanation 1:\nThe node with value 10 is the only covered node. All other nodes are uncovered.\nTherefore, the absolute difference is |(10) - (2 + 1 + 4 + 6 + 5)| = 8\nExplanation 2:\n\nAll the given nodes are uncovered. Hence, the answer is sum of given nodes - 6.\n\n\n\nAnswer :-\n/**\n * Definition for binary tree\n * struct TreeNode {\n *     int val;\n *     struct TreeNode *left;\n *     struct TreeNode *right;\n * };\n * \n * typedef struct TreeNode treenode;\n * \n * treenode* treenode_new(int val) {\n *     treenode* node = (treenode *) malloc(sizeof(treenode));\n *     node->val = val;\n *     node->left = NULL;\n *     node->right = NULL;\n *     return node;\n * }\n */\n/**\n * @input A : Root pointer of the tree \n * \n * @Output Long\n */\n// long long findSumLeftUncovered(treenode* root){\n//     if(root==NULL){return 0;}\n//     if(root->left==NULL){return findSumLeftUncovered(root->right) + (long long)root->val;}\n//     return findSumLeftUncovered(root->left) + (long long)root->val;\n// }\n\n// long long findSumRightUncovered(treenode* root){\n//     if(root==NULL){return 0;}\n//     if(root->right==NULL){return findSumRightUncovered(root->left) + (long long)root->val;}\n//     return findSumRightUncovered(root->right) + (long long)root->val;\n// }\n\n// long long findSumAllNodes(treenode* root){\n//     if(root==NULL){return 0;}\n//     return findSumAllNodes(root->left) + findSumAllNodes(root->right) + (long long)root->val;\n// }\n\n// long long int absolute(long long val){return val > 0 ? val : 0;}\n\n// long long coveredNodes(treenode* A) {\n//     if(A==NULL){return 0;}\n//     long long sumLeftUncovered = findSumLeftUncovered(A);\n//     long long sumRightUncovered = findSumRightUncovered(A);\n//     long long sumUncovered = sumLeftUncovered + sumRightUncovered - A->val;\n//     long long sumAll = findSumAllNodes(A);\n//     long long sumCovered = sumAll - sumUncovered;\n//     printf(\"[sumLeftUncovered:%d] [sumRightUncovered:%d] [sumUncovered:%d] [sumAll:%d] [sumCovered:%d]\",\n//     sumLeftUncovered, sumRightUncovered, sumUncovered, sumAll, sumCovered);\n//     return absolute(sumCovered - sumUncovered);\n// }\n\nlong long int absolute(long long val){return val > 0 ? val : 0  - val;}\n\nint findNumNodes(treenode* root){\n    if(root==NULL){return 0;}\n    return findNumNodes(root->left) + findNumNodes(root->right) + 1;\n}\n\nlong long coveredNodes(treenode* A) {\n    int currLvlSt=0, currLvlEn=0;\n    int numNodes = findNumNodes(A);\n    treenode** levelOrderNodeArray = (treenode**) malloc(2 * numNodes * sizeof(treenode*));\n    levelOrderNodeArray[0] = A;\n    numNodes = 1;\n    int i =  0;\n    long long coveredSum = 0, uncoveredSum = 0;\n    while(numNodes!=0){\n        // printf(\"%d\\n\", levelOrderNodeArray[currLvlSt]->val);\n        // if(currLvlSt!=currLvlEn){printf(\"%d\\n\", levelOrderNodeArray[currLvlEn]->val);}\n        // printf(\"coveredSum = %d, uncoveredSum = %d\\n\", coveredSum, uncoveredSum);\n        numNodes = 0;\n        for(i=currLvlSt; i<=currLvlEn; i++){\n            if(i==currLvlSt || i==currLvlEn){uncoveredSum+=levelOrderNodeArray[i]->val;}\n            else{coveredSum+=levelOrderNodeArray[i]->val;}\n            \n            if(levelOrderNodeArray[i]->left!=NULL){\n                numNodes += 1;\n                levelOrderNodeArray[currLvlEn+numNodes]=levelOrderNodeArray[i]->left;\n            }\n            if(levelOrderNodeArray[i]->right!=NULL){\n                numNodes += 1;\n                levelOrderNodeArray[currLvlEn+numNodes]=levelOrderNodeArray[i]->right;\n            }\n        }\n        currLvlSt = i;\n        currLvlEn += numNodes;\n    }\n    return absolute(coveredSum - uncoveredSum);\n}\n    \n    \n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=hRk4in1Rg_M&pp=ygUkaW50ZXJ2aWV3Yml0IGNvdmVyZWQvdW5jb3ZlcmVkIG5vZGVz',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
