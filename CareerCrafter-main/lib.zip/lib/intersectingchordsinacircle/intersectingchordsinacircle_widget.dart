import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'intersectingchordsinacircle_model.dart';
export 'intersectingchordsinacircle_model.dart';

class IntersectingchordsinacircleWidget extends StatefulWidget {
  const IntersectingchordsinacircleWidget({super.key});

  @override
  State<IntersectingchordsinacircleWidget> createState() =>
      _IntersectingchordsinacircleWidgetState();
}

class _IntersectingchordsinacircleWidgetState
    extends State<IntersectingchordsinacircleWidget> {
  late IntersectingchordsinacircleModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => IntersectingchordsinacircleModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Intersecting Chords in a Circle',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1700.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \nGiven a number A, return number of ways you can draw A chords in a circle with 2 x A points such that no 2 chords intersect.\n\nTwo ways are different if there exists a chord which is present in one way and not in other.\n\nReturn the answer modulo 109 + 7.\n\n\n\nInput Format:\n\nThe first and the only argument contains the integer A.\nOutput Format:\n\nReturn an integer answering the query as described in the problem statement.\nConstraints:\n\n1 <= A <= 1000\nExamples:\n\nInput 1:\n    A = 1\n\nOutput 1:\n    1\n\nExplanation 1:\n    If points are numbered 1 to 2 in clockwise direction, then different ways to draw chords are:\n    {(1-2)} only.\n    So, we return 1.\n\nInput 2:\n    A = 2\n\nOutput 2:\n    2\n\nExplanation 2:\n    If points are numbered 1 to 4 in clockwise direction, then different ways to draw chords are:\n    {(1-2), (3-4)} and {(1-4), (2-3)}.\n    So, we return 2.\n\n\n\n\n\n\nAnswer :-\n/**\n * @input A : Integer\n * \n * @Output Integer\n */\n\n#define CACHE_SIZE (1001)\n#define MOD (1000000007)\n\n\nint chordCnt(int A) {\n    if (A <= 1) return 1;\n    if (A == 2) return 2;\n    \n    static int cache[CACHE_SIZE] = {};\n\n    if (A < CACHE_SIZE && cache[A]) return cache[A];\n    int k;\n    int Cn = 0;\n    for (k = 0; k < A; k++) {\n        Cn += ((int64_t)chordCnt(k))*chordCnt(A-1-k)%MOD;\n        Cn%=MOD;\n    }\n    cache[A] = Cn;\n    return Cn;\n\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=zx6_ypjbstk&pp=ygUsaW50ZXJ2aWV3Yml0IGludGVyc2VjdGluZyBjaG9yZHMgaW4gYSBjaXJjbGU%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
