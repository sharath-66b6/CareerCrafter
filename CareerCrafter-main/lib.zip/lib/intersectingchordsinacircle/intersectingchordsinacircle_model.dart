import '/flutter_flow/flutter_flow_util.dart';
import 'intersectingchordsinacircle_widget.dart'
    show IntersectingchordsinacircleWidget;
import 'package:flutter/material.dart';

class IntersectingchordsinacircleModel
    extends FlutterFlowModel<IntersectingchordsinacircleWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
