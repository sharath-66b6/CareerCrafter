import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'longestcommonprefix_model.dart';
export 'longestcommonprefix_model.dart';

class LongestcommonprefixWidget extends StatefulWidget {
  const LongestcommonprefixWidget({super.key});

  @override
  State<LongestcommonprefixWidget> createState() =>
      _LongestcommonprefixWidgetState();
}

class _LongestcommonprefixWidgetState extends State<LongestcommonprefixWidget> {
  late LongestcommonprefixModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => LongestcommonprefixModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Longest Common Prefix',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1500.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Given the array of strings A, you need to find the longest string S which is the prefix of ALL the strings in the array.\n\nLongest common prefix for a pair of strings S1 and S2 is the longest string S which is the prefix of both S1 and S2.\n\nFor Example: longest common prefix of \"abcdefgh\" and \"abcefgh\" is \"abc\".\n\n\n\nProblem Constraints\n0 <= sum of length of all strings <= 1000000\n\n\n\nInput Format\nThe only argument given is an array of strings A.\n\n\n\nOutput Format\nReturn the longest common prefix of all strings in A.\n\n\n\nExample Input\nInput 1:\n\nA = [\"abcdefgh\", \"aefghijk\", \"abcefgh\"]\nInput 2:\n\nA = [\"abab\", \"ab\", \"abcd\"];\n\n\nExample Output\nOutput 1:\n\n\"a\"\nOutput 2:\n\n\"ab\"\n\n\nExample Explanation\nExplanation 1:\n\nLongest common prefix of all the strings is \"a\".\nExplanation 2:\n\nLongest common prefix of all the strings is \"ab\".\n\n\n\nAnswer :-\n/**\n * @input A : array of strings termination by \'\\0\'\n * @input n1 : number of strings in array A\n * \n * @Output string. Make sure the string ends with null character\n */\nchar* longestCommonPrefix(char** A, int n1) {\n    int i=strlen(A[0]),j=1,k=0,l;\n    for(j=1;j<n1;j++){\n        for(k=0;k<(l>i)?i:(l=strlen(A[j]));k++)\n            if(A[j-1][k]!=A[j][k]) break;\n        i=(i<=k)?i:k;\n    }\n    char *B=(char *)malloc(i*sizeof(char));\n    for(k=0;k<i;k++)  B[k]=A[0][k]; B[k]=\'\\0\';\n     return B;\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=7T8STO3wE5o&pp=ygUgaW50ZXJ2aWV3Yml0IGxvbmdlc3Rjb21tb25wcmVmaXg%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
