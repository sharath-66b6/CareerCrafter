import '/flutter_flow/flutter_flow_util.dart';
import 'longestcommonprefix_widget.dart' show LongestcommonprefixWidget;
import 'package:flutter/material.dart';

class LongestcommonprefixModel
    extends FlutterFlowModel<LongestcommonprefixWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
