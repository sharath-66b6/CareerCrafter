import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'gasstation_model.dart';
export 'gasstation_model.dart';

class GasstationWidget extends StatefulWidget {
  const GasstationWidget({super.key});

  @override
  State<GasstationWidget> createState() => _GasstationWidgetState();
}

class _GasstationWidgetState extends State<GasstationWidget> {
  late GasstationModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => GasstationModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Gas Station',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1800.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven two integer arrays A and B of size N. There are N gas stations along a circular route, where the amount of gas at station i is A[i].\n\nYou have a car with an unlimited gas tank and it costs B[i] of gas to travel from station i to its next station (i+1). You begin the journey with an empty tank at one of the gas stations.\n\nReturn the minimum starting gas station\'s index if you can travel around the circuit once, otherwise return -1.\n\nYou can only travel in one direction. i to i+1, i+2, ... n-1, 0, 1, 2.. Completing the circuit means starting at i and ending up at i again.\n\n\nProblem Constraints\n1 <= |A| <= 5 * 105\n|A| == |B|\n0 <= Ai <= 5 * 103\n0 <= Bi <= 5 * 103\n\n\nInput Format\nThe first argument given is the integer array A. The second argument given is the integer array B.\n\n\nOutput Format\nReturn the minimum starting gas station\'s index if you can travel around the circuit once, otherwise return -1.\n\n\nExample Input\nA = [1, 2]\nB = [2, 1]\n\n\nExample Output\n1\n\n\nExample Explanation\nIf you start from index 0, you can fill in A[0] = 1 amount of gas.\nNow your tank has 1 unit of gas. But you need B[0] = 2 gas to travel to station 1.\n\nIf you start from index 1, you can fill in A[1] = 2 amount of gas.\nNow your tank has 2 units of gas. You need B[1] = 1 gas to get to station 0.\nSo, you travel to station 0 and still have 1 unit of gas left over.\nYou fill in A[0] = 1 unit of additional gas, making your current gas = 2. It costs you B[0] = 2 to get to station 1, which you do and complete the circuit.\n\n\n\nAnswer :-\n/**\n * @input gas : Read only ( DON\'T MODIFY ) Integer array\n * @input n1 : Integer array\'s ( gas ) length\n * @input cost : Read only ( DON\'T MODIFY ) Integer array\n * @input n2 : Integer array\'s ( cost ) length\n * \n * @Output Integer\n */\nint canCompleteCircuit(const int* gas, int n1, const int* cost, int n2) {\n        int N = n1;\n        int gasLeft = 0;\n        int startStation = 0,i;\n        for (i = 0; i < 2 * N; i++) {\n            int k = i % N;\n            gasLeft = gasLeft + gas[k] - cost[k];\n            if (gasLeft < 0) {\n                startStation = (i + 1) % N;\n                gasLeft = 0;\n            }\n            else {\n                if (startStation == (i + 1) % N)\n                    return startStation;\n            }\n        }\n        return -1;\n    }\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=MWTHTDIBN0s&pp=ygUYaW50ZXJ2aWV3Yml0IGdhcyBzdGF0aW9u',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
