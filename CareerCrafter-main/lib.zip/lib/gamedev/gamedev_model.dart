import '/flutter_flow/flutter_flow_util.dart';
import 'gamedev_widget.dart' show GamedevWidget;
import 'package:flutter/material.dart';

class GamedevModel extends FlutterFlowModel<GamedevWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
