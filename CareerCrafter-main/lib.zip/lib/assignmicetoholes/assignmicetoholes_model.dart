import '/flutter_flow/flutter_flow_util.dart';
import 'assignmicetoholes_widget.dart' show AssignmicetoholesWidget;
import 'package:flutter/material.dart';

class AssignmicetoholesModel extends FlutterFlowModel<AssignmicetoholesWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
