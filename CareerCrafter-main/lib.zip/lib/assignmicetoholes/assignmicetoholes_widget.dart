import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'assignmicetoholes_model.dart';
export 'assignmicetoholes_model.dart';

class AssignmicetoholesWidget extends StatefulWidget {
  const AssignmicetoholesWidget({super.key});

  @override
  State<AssignmicetoholesWidget> createState() =>
      _AssignmicetoholesWidgetState();
}

class _AssignmicetoholesWidgetState extends State<AssignmicetoholesWidget> {
  late AssignmicetoholesModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => AssignmicetoholesModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Assign Mice to Holes',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2000.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nThere are N Mice and N holes that are placed in a straight line. Each hole can accomodate only 1 mouse.\n\nThe positions of Mice are denoted by array A and the position of holes are denoted by array B.\n\nA mouse can stay at his position, move one step right from x to x + 1, or move one step left from x to x − 1. Any of these moves consumes 1 minute.\n\nAssign mice to holes so that the time when the last mouse gets inside a hole is minimized.\n\n\n\nProblem Constraints\n1 <= N <= 105\n\n-109 <= A[i], B[i] <= 109\n\n\n\nInput Format\nFirst argument is an integer array A.\n\nSecond argument is an integer array B.\n\n\n\nOutput Format\nReturn an integer denoting the minimum time when the last nouse gets inside the holes.\n\n\n\nExample Input\nInput 1:\n\n A = [-4, 2, 3]\n B = [0, -2, 4]\nInput 2:\n\n A = [-2]\n B = [-6]\n\n\nExample Output\nOutput 1:\n\n 2\nOutput 2:\n\n 4\n\n\nExample Explanation\nExplanation 1:\n\n Assign the mouse at position (-4 to -2), (2 to 0) and (3 to 4).\n The number of moves required will be 2, 2 and 1 respectively.\n So, the time taken will be 2.\nExplanation 2:\n\n Assign the mouse at position -2 to -6.\n The number of moves required will be 4.\n So, the time taken will be 4.\n\n\n\n\n\nAnswer :-\n/**\n * @input A : Integer array\n * @input n1 : Integer array\'s ( A ) length\n * @input B : Integer array\n * @input n2 : Integer array\'s ( B ) length\n * \n * @Output Integer\n */\n int compare(const void *a, const void *b)\n {\n     return (*(int *)a - *(int *)b);\n }\nint mice(int* a, int n1, int* b, int n2) {\n    int i;\n    qsort(a,n1,sizeof(int),compare);\n    qsort(b,n2,sizeof(int),compare);\n    int maxi=(a[0]>b[0])?(a[0]-b[0]):(b[0]-a[0]);\n    for(i=1;i<n1 && i<n2;i++)\n    {\n        int z=(a[i]>b[i])?(a[i]-b[i]):(b[i]-a[i]);\n        if(z>maxi)\n        maxi=z;\n    }\n    return maxi;\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=KcYt_p-GOXQ&pp=ygUhaW50ZXJ2aWV3Yml0IGFzc2lnbiBtaWNlIHRvIGhvbGVz',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
