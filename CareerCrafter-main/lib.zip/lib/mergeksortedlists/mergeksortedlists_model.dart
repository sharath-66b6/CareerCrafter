import '/flutter_flow/flutter_flow_util.dart';
import 'mergeksortedlists_widget.dart' show MergeksortedlistsWidget;
import 'package:flutter/material.dart';

class MergeksortedlistsModel extends FlutterFlowModel<MergeksortedlistsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
