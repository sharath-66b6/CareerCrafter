import '/flutter_flow/flutter_flow_util.dart';
import 'adobeprinciple_widget.dart' show AdobeprincipleWidget;
import 'package:flutter/material.dart';

class AdobeprincipleModel extends FlutterFlowModel<AdobeprincipleWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
