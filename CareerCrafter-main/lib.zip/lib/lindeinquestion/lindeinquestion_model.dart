import '/flutter_flow/flutter_flow_util.dart';
import 'lindeinquestion_widget.dart' show LindeinquestionWidget;
import 'package:flutter/material.dart';

class LindeinquestionModel extends FlutterFlowModel<LindeinquestionWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
