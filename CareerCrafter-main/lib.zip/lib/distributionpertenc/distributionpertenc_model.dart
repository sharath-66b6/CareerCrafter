import '/flutter_flow/flutter_flow_util.dart';
import 'distributionpertenc_widget.dart' show DistributionpertencWidget;
import 'package:flutter/material.dart';

class DistributionpertencModel
    extends FlutterFlowModel<DistributionpertencWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
