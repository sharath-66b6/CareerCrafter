import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'evenreverse_model.dart';
export 'evenreverse_model.dart';

class EvenreverseWidget extends StatefulWidget {
  const EvenreverseWidget({super.key});

  @override
  State<EvenreverseWidget> createState() => _EvenreverseWidgetState();
}

class _EvenreverseWidgetState extends State<EvenreverseWidget> {
  late EvenreverseModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => EvenreverseModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Even Reverse',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2200.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nGiven a linked list A , reverse the order of all nodes at even positions.\n\n\n\nProblem Constraints\n1 <= Size of linked list <= 100000\n\n\n\nInput Format\nFirst and only argument is the head of the Linked-List A.\n\n\n\nOutput Format\nReturn the head of the new linked list.\n\n\n\nExample Input\nInput 1:\n\nA = 1 -> 2 -> 3 -> 4\nInput 2:\n\nA = 1 -> 2 -> 3\n\n\nExample Output\nOutput 1:\n\n 1 -> 4 -> 3 -> 2\nOutput 2:\n\n 1 -> 2 -> 3\n\n\nExample Explanation\nExplanation 1:\n\nNodes are positions 2 and 4 have been swapped.\nExplanation 2:\n\nNo swapping neccassary here.\n\n\n\nAnswer :-\n\n/**\n * Definition for singly-linked list.\n * struct ListNode {\n *     int val;\n *     struct ListNode *next;\n * };\n * \n * typedef struct ListNode listnode;\n * \n * listnode* listnode_new(int val) {\n *     listnode* node = (listnode *) malloc(sizeof(listnode));\n *     node->val = val;\n *     node->next = NULL;\n *     return node;\n * }\n */\n/**\n * @input A : Head pointer of linked list \n * \n * @Output head pointer of list.\n */\n\nint findlen(listnode* head)\n{\n    int count=0;\n    listnode *temp=head;\n    while(temp)\n    {\n        count++;\n        temp=temp->next;\n    }\n    return count;\n}\n \n \nlistnode* solve(listnode* A) {\n    int size=findlen(A),evens[size/2],i=(size/2)-1,count=0,j=0;\n    listnode *temp=A;\n    count=0;\n    for(j=0;j<size/2 && temp;)\n    {\n        count++;\n        if(count%2==0)\n        {\n            evens[j]=temp->val;\n            j++;\n        }\n        temp=temp->next;\n    }\n    count=0;temp=A;\n    while(temp)\n    {\n        count++;\n        if(count%2==0)\n        {\n            temp->val=evens[i];\n            i--;\n        }\n        temp=temp->next;\n    }\n    return A;\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=SX5zx4cPLoM&pp=ygUZaW50ZXJ2aWV3Yml0IGV2ZW4gcmV2ZXJzZQ%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
