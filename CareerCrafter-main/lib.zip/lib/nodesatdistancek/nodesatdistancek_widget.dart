import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'nodesatdistancek_model.dart';
export 'nodesatdistancek_model.dart';

class NodesatdistancekWidget extends StatefulWidget {
  const NodesatdistancekWidget({super.key});

  @override
  State<NodesatdistancekWidget> createState() => _NodesatdistancekWidgetState();
}

class _NodesatdistancekWidgetState extends State<NodesatdistancekWidget> {
  late NodesatdistancekModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => NodesatdistancekModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Nodes at Distance K',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven the root of a binary tree A, the value of a target node B, and an integer C, return an array of the values of all nodes that have a distance C from the target node.\n\nYou can return the answer in any order.\n\n\nProblem Constraints\n1 ≤ N ≤ 105 (N is the number of nodes in the binary tree)\n1 ≤ Ai ≤ N (Ai denotes the values of the nodes in the tree)\nAll the values in the nodes are unique.\n1 ≤ C ≤ 104\n\n\nInput Format\nThe first argument is the root node of the binary tree A.\nThe second argument is an integer B denoting the label of the target node.\nThe third argument is an integer C denoting the distance.\n\n\nOutput Format\nReturn an array of integers denoting the nodes which are at a distance C from the node B.\n\n\nExample Input\nInput 1:\nA =     1\n       / \\\n      2   3\n     / \\\n    4   5\n\n\nB = 2\nC = 1\n\nInput 2:\n\nA =     1\n       / \\\n      2   3\n     / \\\n    4   5\n\n\nB = 2\nC = 2\n\n\n\nExample Output\nOutput 1:\n[1, 4, 5]\nOutput 2:\n\n[3]\n\n\nExample Explanation\nExplanation 1: \n\nFor the given tree, we have target node as 2.\n\nAll the nodes with are at distance 1, meaning the adjacent nodes are [1, 4, 5].\n\nExplanation 2:\n\nThe given tree is same, and [3] is the only node with distance 2.\n\n\n\n\nAnswer :-\n# Definition for a  binary tree node\n# class TreeNode:\n#     def __init__(self, x):\n#         self.val = x\n#         self.left = None\n#         self.right = None\n\nfrom collections import deque\n\nclass Solution:\n    target = None\n    def dfs(self, node, par = None):\n        if node:\n            node.par = par\n            self.dfs(node.left, node)\n            self.dfs(node.right, node)\n    \n    def bfs(self, src, x):\n        if(src):\n            if(src.val == x):\n                self.target = src\n            self.bfs(src.left, x)\n            self.bfs(src.right, x)\n    def distanceK(self, A, B, C):\n        root = A\n        self.dfs(root)\n        self.bfs(root, B)\n        if(self.target == None):\n            print(B)\n        queue = deque([(self.target, 0)])\n        seen = {self.target, None}\n        while queue:\n            if queue[0][1] == C:\n                return [node.val for node, d in queue]\n            node, d = queue.popleft()\n            for nei in (node.left, node.right, node.par):\n                if nei and nei not in seen:\n                    seen.add(nei)\n                    queue.append((nei, d+1))\n        return []',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=f-oTsCUCiXk&pp=ygUgaW50ZXJ2aWV3Yml0IG5vZGVzIGF0IGRpc3RhbmNlIGs%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
