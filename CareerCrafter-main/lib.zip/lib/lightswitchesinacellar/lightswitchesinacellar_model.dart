import '/flutter_flow/flutter_flow_util.dart';
import 'lightswitchesinacellar_widget.dart' show LightswitchesinacellarWidget;
import 'package:flutter/material.dart';

class LightswitchesinacellarModel
    extends FlutterFlowModel<LightswitchesinacellarWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
