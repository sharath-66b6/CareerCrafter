import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'lightswitchesinacellar_model.dart';
export 'lightswitchesinacellar_model.dart';

class LightswitchesinacellarWidget extends StatefulWidget {
  const LightswitchesinacellarWidget({super.key});

  @override
  State<LightswitchesinacellarWidget> createState() =>
      _LightswitchesinacellarWidgetState();
}

class _LightswitchesinacellarWidgetState
    extends State<LightswitchesinacellarWidget> {
  late LightswitchesinacellarModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => LightswitchesinacellarModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Light Switches in the Cellar',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 600.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'In your cellar there are three light switches in the OFF position. Each switch controls one of three light bulbs on floor above. \n\nYou may move any of the switches but you may only go upstairs to inspect the bulbs. \n\nWhen upstairs, you cannot access the switches. What is the minimum number of times you need to go upstairs to determine the switch for each bulb?\n\nSince your answer is a integer, just put the number without any decimal places if its an integer. If the answer is Infinity, output Infinity.\n\n\n\nAnswer :-\nTurn light switch 1 to the ON position for a few minutes, then turn it off. Then turn on switch 2, and go upstairs. The light bulb that is off and hot is attached to switch 1. The one that is on is attached to switch 2, and the one that is off and cold is attached to switch 3.',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=vhoS0-ooIGg&pp=ygUwaW50ZXJ2aWV3Yml0IHB1enpsZSBsaWdodCBzd2l0Y2hlcyBpbiB0aGUgY2VsbGFy',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
