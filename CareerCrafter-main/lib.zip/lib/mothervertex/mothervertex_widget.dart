import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'mothervertex_model.dart';
export 'mothervertex_model.dart';

class MothervertexWidget extends StatefulWidget {
  const MothervertexWidget({super.key});

  @override
  State<MothervertexWidget> createState() => _MothervertexWidgetState();
}

class _MothervertexWidgetState extends State<MothervertexWidget> {
  late MothervertexModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MothervertexModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Mother Vertex',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2000.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nYou are given a directed graph with A vertices and M edges.\n\nYou are given an array B with dimensions M x 2, where each row denotes a directed edge from Bi, 0 to Bi, 1.\n\nYou need to find if there exists a mother vertex in the given graph. Return 1 if it exists, otherwise 0.\n\nA mother vertex is defined as a vertex from which all the vertices in the graph are accessible by a directed path.\n\n\n\nProblem Constraints\n1 <= A <= 105\n1 <= M <= 2 * 105\n1 <= Bi, 0, Bi, 1 <= A\nThere can be duplicate edges or self loops in the input graph.\n\n\nInput Format\nThe first argument is the integer A. The second argument is the 2D integer array B.\n\n\nOutput Format\nReturn a single integer 1 if a mother vertex exists, otherwise 0.\n\n\nExample Input\nInput 1:\nA = 3\nB = [[1, 3], [2, 3], [1, 3]]\nInput 2:\n\nA = 3\nB = [[1, 3], [2, 3], [3, 2]]\n\n\nExample Output\nOutput 1:\n0\nOutput 2:\n\n1\n\n\nExample Explanation\nExplanation 1:\nThere is no vertex from which all the other vertices are accessible.\nNote there can be duplicate edges.\nExplanation 2:\n\nVertex 1 is the mother vertex. We can reach 2 using 1 -> 3 -> 2. We can reach 3 using 1 -> 3\n\n\nAnswer :-\nsys.setrecursionlimit(200000)\nadj = [[]]\ndef DFS(src, vis): \n    vis[src] = True\n    for x in adj[src]: \n        if (vis[x]==False):\n            DFS(x, vis)\n\nclass Solution:\n    # @param A : integer\n    # @param B : list of list of integers\n    # @return an integer\n    def motherVertex(self, A, B):\n        global adj\n        adj = []\n        for i in range(A+1):\n            adj.append([])\n        vis = [False]*(A+1)\n        check = [False]*(A+1)\n        for i in range(len(B)):\n            adj[B[i][0]].append(B[i][1])\n            \n        mother = 0\n        for i in range(1, A+1):\n            if(vis[i]==False):\n                mother = i\n                DFS(i, vis)\n                \n        DFS(mother, check)\n        for i in range(1, A+1):\n            if(check[i]==False):\n                return 0\n        return 1\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=gNn0L18DUvg&pp=ygUaaW50ZXJ2aWV3Yml0IG1vdGhlciB2ZXJ0ZXg%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
