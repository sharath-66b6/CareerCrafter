import '/flutter_flow/flutter_flow_util.dart';
import 'mothervertex_widget.dart' show MothervertexWidget;
import 'package:flutter/material.dart';

class MothervertexModel extends FlutterFlowModel<MothervertexWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
