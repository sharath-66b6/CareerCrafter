import '/flutter_flow/flutter_flow_util.dart';
import 'hrquestions_widget.dart' show HrquestionsWidget;
import 'package:flutter/material.dart';

class HrquestionsModel extends FlutterFlowModel<HrquestionsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
