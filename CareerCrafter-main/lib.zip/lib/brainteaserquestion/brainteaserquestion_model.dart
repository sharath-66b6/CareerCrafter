import '/flutter_flow/flutter_flow_util.dart';
import 'brainteaserquestion_widget.dart' show BrainteaserquestionWidget;
import 'package:flutter/material.dart';

class BrainteaserquestionModel
    extends FlutterFlowModel<BrainteaserquestionWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
