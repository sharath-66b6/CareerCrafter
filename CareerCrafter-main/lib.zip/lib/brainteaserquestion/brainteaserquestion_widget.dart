import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'brainteaserquestion_model.dart';
export 'brainteaserquestion_model.dart';

class BrainteaserquestionWidget extends StatefulWidget {
  const BrainteaserquestionWidget({super.key});

  @override
  State<BrainteaserquestionWidget> createState() =>
      _BrainteaserquestionWidgetState();
}

class _BrainteaserquestionWidgetState extends State<BrainteaserquestionWidget> {
  late BrainteaserquestionModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => BrainteaserquestionModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).primary,
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30.0,
            borderWidth: 1.0,
            buttonSize: 60.0,
            icon: const Icon(
              Icons.arrow_back_rounded,
              color: Colors.white,
              size: 30.0,
            ),
            onPressed: () async {
              context.pop();
            },
          ),
          title: Text(
            'Brainteasers HR Interview Questions',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: 'Outfit',
                  color: Colors.white,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                ),
          ),
          actions: const [],
          centerTitle: true,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: ListView(
            padding: const EdgeInsets.symmetric(vertical: 12.0),
            scrollDirection: Axis.vertical,
            children: [
              Container(
                width: 100.0,
                height: 1800.0,
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryBackground,
                ),
                child: Align(
                  alignment: const AlignmentDirectional(0.0, -1.0),
                  child: Text(
                    '1. What do you think is better - being perfect and delivering late or being good and delivering on time?\nBack up your opinion with certain examples and answer what according to you is right.\n\nHere is one possible answer:\n\nI believe that it is always better to be good and deliver on time. Time is money to the organization. If we are good and on time, then there is always room for improvement and enhancements. But if we deliver it late, then no amount of perfection can make up for the time lost.\n\n\n\n\n______________________________\n\n\n\n2. Judy’s mother had 4 children. The eldest one was April, the second child was May and the third child was June. What was the name of the fourth child?\nThis is a very simple question. Yet some people find it confusing when they hear it for the first time or possibly due to the stress of interviews. Think twice before answering. Never say that you do not know. At least try solving.\n\nThe answer is Judy.\n\n\n\n________________________________\n\n\n\n\n3. How many times in a day does the clock’s hand overlap?\nWhile hearing this question for the first time, it might sound very simple but it could also be complex. Interviewers do not generally look for the correct answers. They would just want to see how well you are capable of analyzing a problem and what is your thought process to approach a problem.\n\nSome tips to answer this question:\n\nTake time to analyze the answer.\nNote down your thought process while answering.\nShow that you are actually in the process of solving a problem.\nDo not blurt out answers without thinking.\nDo not say I don’t know without even trying.\nSample answer:\n\nWe know that we have 24 hours in a day. The hand first overlaps at 12:00, then at 1:05, 2:10, 3.15, 4:20, 5:25, 6:30, 7:35, 8:40, 9:45 and 10:50 two times in a day. There will be no overlap at 11:55 because the hour hand is moving towards 12 while the minute hand is at 11. This sums up the result to 22.\n\n\n\n________________________________\n\n\n\n4. You have only two vessels of 3l and 5l volume and you are given an unending supply of water. Can you find out how to get 4l of water just by using these two vessels?\nTake time to analyze the question. Do not think silently. Let the interviewer know of your thought process.\n\nThe answer to this question is:\n\nFirst, fill the 3l vessel with water.\nTransfer all the water from the 3l vessel into the 5l vessel.\nRefill the 3l vessel again and pour it off into 5l vessel jug till it is full.\nIn the 3l vessel, we now have 1-litre of water available.\nEmpty the water from the 5l vessel completely.\nPour the 1-litre water from 3l vessel to 5l vessel.\nFill the 3l vessel with water and pour this into the 5l vessel. We now have 4l of water in the 5l vessel.\n\n\n\n\n_____________________________________',
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Readex Pro',
                          letterSpacing: 0.0,
                        ),
                  ),
                ),
              ),
            ].divide(const SizedBox(height: 12.0)),
          ),
        ),
      ),
    );
  }
}
