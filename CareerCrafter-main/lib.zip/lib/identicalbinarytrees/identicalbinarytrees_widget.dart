import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'identicalbinarytrees_model.dart';
export 'identicalbinarytrees_model.dart';

class IdenticalbinarytreesWidget extends StatefulWidget {
  const IdenticalbinarytreesWidget({super.key});

  @override
  State<IdenticalbinarytreesWidget> createState() =>
      _IdenticalbinarytreesWidgetState();
}

class _IdenticalbinarytreesWidgetState
    extends State<IdenticalbinarytreesWidget> {
  late IdenticalbinarytreesModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => IdenticalbinarytreesModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Identical Binary Trees',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 800.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \nGiven two binary trees, write a function to check if they are equal or not.\n\nTwo binary trees are considered equal if they are structurally identical and the nodes have the same value.\n\nReturn  0 / 1  ( 0 for false, 1 for true ) for this problem\n\nExample :\n\nInput : \n\n   1       1\n  / \\     / \\\n 2   3   2   3\n\nOutput : \n  1 \n\n\n\n\nAnswer :-\nint isSameTree(treenode* A, treenode* B) {\n    if(A==NULL && B== NULL) return 1;\n    if(A!=NULL && B==NULL) return 0;\n    if(A==NULL && B!=NULL) return 0;\n    if(A->val==B->val && isSameTree(A->left,B->left) && isSameTree(A->right,B->right)) return 1;\n    else return 0;\n    \n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=PaRF7tRQ79c&pp=ygUjaW50ZXJ2aWV3Yml0IGlkZW50aWNhbCBiaW5hcnkgdHJlZXM%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
