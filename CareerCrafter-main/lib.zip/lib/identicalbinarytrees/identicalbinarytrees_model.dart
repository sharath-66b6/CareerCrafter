import '/flutter_flow/flutter_flow_util.dart';
import 'identicalbinarytrees_widget.dart' show IdenticalbinarytreesWidget;
import 'package:flutter/material.dart';

class IdenticalbinarytreesModel
    extends FlutterFlowModel<IdenticalbinarytreesWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
