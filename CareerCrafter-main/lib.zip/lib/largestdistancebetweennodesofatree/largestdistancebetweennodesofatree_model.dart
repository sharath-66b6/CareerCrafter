import '/flutter_flow/flutter_flow_util.dart';
import 'largestdistancebetweennodesofatree_widget.dart'
    show LargestdistancebetweennodesofatreeWidget;
import 'package:flutter/material.dart';

class LargestdistancebetweennodesofatreeModel
    extends FlutterFlowModel<LargestdistancebetweennodesofatreeWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
