import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'largestdistancebetweennodesofatree_model.dart';
export 'largestdistancebetweennodesofatree_model.dart';

class LargestdistancebetweennodesofatreeWidget extends StatefulWidget {
  const LargestdistancebetweennodesofatreeWidget({super.key});

  @override
  State<LargestdistancebetweennodesofatreeWidget> createState() =>
      _LargestdistancebetweennodesofatreeWidgetState();
}

class _LargestdistancebetweennodesofatreeWidgetState
    extends State<LargestdistancebetweennodesofatreeWidget> {
  late LargestdistancebetweennodesofatreeModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model =
        createModel(context, () => LargestdistancebetweennodesofatreeModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Largest Distance between nodes of a Tree\n',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1500.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nGiven an arbitrary unweighted rooted tree which consists of N nodes.\n\nThe goal of the problem is to find largest distance between two nodes in a tree.\n\nDistance between two nodes is a number of edges on a path between the nodes (there will be a unique path between any pair of nodes since it is a tree).\n\nThe nodes will be numbered 0 through N - 1.\n\nThe tree is given as an array A, there is an edge between nodes A[i] and i (0 <= i < N). Exactly one of the i\'s will have A[i] equal to -1, it will be root node.\n\n\n\nProblem Constraints\n1 <= N <= 40000\n\n\n\nInput Format\nFirst and only argument is an integer array A of size N.\n\n\n\nOutput Format\nReturn a single integer denoting the largest distance between two nodes in a tree.\n\n\n\nExample Input\nInput 1:\n\n A = [-1, 0, 0, 0, 3]\n\n\nExample Output\nOutput 1:\n\n 3\n\n\nExample Explanation\nExplanation 1:\n\n node 0 is the root and the whole tree looks like this: \n          0\n       /  |  \\\n      1   2   3\n               \\\n                4\n\n One of the longest path is 1 -> 0 -> 3 -> 4 and its length is 3, thus the answer is 3.\n\n\n\nAnswer :-\n/**\n * @input A : Integer array\n * @input n1 : Integer array\'s ( A ) length\n * \n * @Output Integer\n */\nint solve(int* A, int n1) {\n    \n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=Fowv133r2Z4&pp=ygUtaW50ZXJ2aWV3Yml0IGxhcmdlc3QgZGlzdGFuY2Ugbm9kZXMgb2YgYSB0cmVl',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
