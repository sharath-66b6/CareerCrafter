import '/flutter_flow/flutter_flow_util.dart';
import 'colorofabean_widget.dart' show ColorofabeanWidget;
import 'package:flutter/material.dart';

class ColorofabeanModel extends FlutterFlowModel<ColorofabeanWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
