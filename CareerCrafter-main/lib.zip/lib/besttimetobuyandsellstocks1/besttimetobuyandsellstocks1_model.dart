import '/flutter_flow/flutter_flow_util.dart';
import 'besttimetobuyandsellstocks1_widget.dart'
    show Besttimetobuyandsellstocks1Widget;
import 'package:flutter/material.dart';

class Besttimetobuyandsellstocks1Model
    extends FlutterFlowModel<Besttimetobuyandsellstocks1Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
