import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'besttimetobuyandsellstocks1_model.dart';
export 'besttimetobuyandsellstocks1_model.dart';

class Besttimetobuyandsellstocks1Widget extends StatefulWidget {
  const Besttimetobuyandsellstocks1Widget({super.key});

  @override
  State<Besttimetobuyandsellstocks1Widget> createState() =>
      _Besttimetobuyandsellstocks1WidgetState();
}

class _Besttimetobuyandsellstocks1WidgetState
    extends State<Besttimetobuyandsellstocks1Widget> {
  late Besttimetobuyandsellstocks1Model _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => Besttimetobuyandsellstocks1Model());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Best Time to Buy and Sell Stocks I',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1500.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nSay you have an array, A, for which the ith element is the price of a given stock on day i.\nIf you were only permitted to complete at most one transaction (i.e, buy one and sell one share of the stock), design an algorithm to find the maximum profit.\n\nReturn the maximum possible profit.\n\n\n\nProblem Constraints\n0 <= len(A) <= 7e5\n\n1 <= A[i] <= 1e7\n\n\n\nInput Format\nThe first and the only argument is an array of integers, A.\n\n\n\nOutput Format\nReturn an integer, representing the maximum possible profit.\n\n\n\nExample Input\nInput 1:\n\n A = [1, 2]\nInput 2:\n\n A = [1, 4, 5, 2, 4]\n\n\nExample Output\nOutput 1:\n 1\nOutput 2:\n\n 4\n\n\nExample Explanation\nExplanation 1:\n\n Buy the stock on day 0, and sell it on day 1.\nExplanation 2:\n\n Buy the stock on day 0, and sell it on day 2.\n\n\n\n\nAnswer :-\nint maxProfit(const int* a, int n) {\n    \n      int min=0,max=0,i;\n      for(i=1;i<n;i++)\n      {\n          if(a[i]>=a[min])\n          max=max>a[i]-a[min]?max:a[i]-a[min];\n          else\n           min=i;\n      }\n      return max;\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=34WE6kwq49U&pp=ygUqaW50ZXJ2aWV3Yml0IGJlc3QgdG8gYnV5IGFuZCBzZWxsIHN0b2NrcyAx',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
