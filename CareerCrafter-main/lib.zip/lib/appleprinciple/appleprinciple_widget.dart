import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'appleprinciple_model.dart';
export 'appleprinciple_model.dart';

class AppleprincipleWidget extends StatefulWidget {
  const AppleprincipleWidget({super.key});

  @override
  State<AppleprincipleWidget> createState() => _AppleprincipleWidgetState();
}

class _AppleprincipleWidgetState extends State<AppleprincipleWidget> {
  late AppleprincipleModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => AppleprincipleModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).primary,
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30.0,
            borderWidth: 1.0,
            buttonSize: 60.0,
            icon: const Icon(
              Icons.arrow_back_rounded,
              color: Colors.white,
              size: 30.0,
            ),
            onPressed: () async {
              context.pop();
            },
          ),
          title: Text(
            'Apple Principles',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: 'Outfit',
                  color: Colors.white,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                ),
          ),
          actions: const [],
          centerTitle: true,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: ListView(
            padding: const EdgeInsets.symmetric(vertical: 12.0),
            scrollDirection: Axis.vertical,
            children: [
              Container(
                width: 100.0,
                height: 700.0,
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryBackground,
                ),
                child: Align(
                  alignment: const AlignmentDirectional(0.0, -1.0),
                  child: Text(
                    'Overview\nWebsite\napple.com\nFounded\n1976\n# Employees\n10K+\nAbout Apple\nApple is an American multinational technology company that specializes in consumer electronics, software, and online services. They offer a wide range of products/services in terms of hardware and software. \n\nMission and Vision of Apple\nApple\'s mission is to bring the best user experience to its customers through its innovative hardware, software, and services.\n\nValues and Principles of Apple\nAccessibility\nTechnology is most powerful when everyone can make their mark.\n\nEnvironment\nOur goal is to leave the planet better than we found it.\n\nPrivacy\nWe design Apple products to protect your privacy and give you control over your information.\n\nSupplier Responsibility\nWe believe in a safe, respectful, and supportive workplace for everyone.',
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Readex Pro',
                          letterSpacing: 0.0,
                        ),
                  ),
                ),
              ),
            ].divide(const SizedBox(height: 12.0)),
          ),
        ),
      ),
    );
  }
}
