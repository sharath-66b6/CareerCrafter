import '/flutter_flow/flutter_flow_util.dart';
import 'expediaquestion_widget.dart' show ExpediaquestionWidget;
import 'package:flutter/material.dart';

class ExpediaquestionModel extends FlutterFlowModel<ExpediaquestionWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
