import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'countandsay_model.dart';
export 'countandsay_model.dart';

class CountandsayWidget extends StatefulWidget {
  const CountandsayWidget({super.key});

  @override
  State<CountandsayWidget> createState() => _CountandsayWidgetState();
}

class _CountandsayWidgetState extends State<CountandsayWidget> {
  late CountandsayModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CountandsayModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Count And Say',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1200.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nThe count-and-say sequence is the sequence of integers beginning as follows: \n1, 11, 21, 1211, 111221, ...\n1 is read off as one 1 or 11. 11 is read off as two 1s or 21.\n21 is read off as one 2, then one 1 or 1211.\n\nGiven an integer n, generate the nth sequence.\n\nNote: The sequence of integers will be represented as a string.\n\nExample:\n\nif n = 2, the sequence is 11.\n\n\nAnswer :-\n/**\n * @input A : Integer\n * \n * @Output string. Make sure the string ends with null character\n */\nchar* countAndSay(int n) {\n    int i;\n     if( n == 1 ) return \"1\";\n    char *cur = malloc(2), *tmp;\n    cur[0] = \'1\';\n    cur[1] = 0;\n\n    int len, idx, j, count;\n    for(i = 2; i <= n; ++i)\n    {\n        len = strlen(cur);\n        tmp = malloc(len * 3);\n        memset(tmp, 0, len * 3);\n        count = 1;\n        for(idx = 1, j = 0; idx < len; ++idx)\n        {\n            if(cur[idx] == cur[idx-1])\n            {\n                ++count;\n            }\n            else\n            {\n                tmp[j++] = \'0\' + count;\n                tmp[j++] = cur[idx-1];\n                count = 1;\n            }\n        }//end of for\n        tmp[j++] = \'0\' + count;\n        tmp[j++] = cur[len-1];\n        free(cur);\n        cur = tmp;\n    }   \n    return cur;\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=INl9Ha294E0&pp=ygUaaW50ZXJ2aWV3Yml0IGNvdW50IGFuZCBzYXk%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
