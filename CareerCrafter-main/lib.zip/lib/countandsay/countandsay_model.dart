import '/flutter_flow/flutter_flow_util.dart';
import 'countandsay_widget.dart' show CountandsayWidget;
import 'package:flutter/material.dart';

class CountandsayModel extends FlutterFlowModel<CountandsayWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
