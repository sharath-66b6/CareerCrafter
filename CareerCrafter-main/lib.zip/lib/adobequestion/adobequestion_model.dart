import '/flutter_flow/flutter_flow_util.dart';
import 'adobequestion_widget.dart' show AdobequestionWidget;
import 'package:flutter/material.dart';

class AdobequestionModel extends FlutterFlowModel<AdobequestionWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
