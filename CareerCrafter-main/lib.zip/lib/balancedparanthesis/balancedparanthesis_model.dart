import '/flutter_flow/flutter_flow_util.dart';
import 'balancedparanthesis_widget.dart' show BalancedparanthesisWidget;
import 'package:flutter/material.dart';

class BalancedparanthesisModel
    extends FlutterFlowModel<BalancedparanthesisWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
