import '/flutter_flow/flutter_flow_util.dart';
import 'mooonfroglabsquestions_widget.dart' show MooonfroglabsquestionsWidget;
import 'package:flutter/material.dart';

class MooonfroglabsquestionsModel
    extends FlutterFlowModel<MooonfroglabsquestionsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
