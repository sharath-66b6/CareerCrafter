import '/flutter_flow/flutter_flow_util.dart';
import 'minstack_widget.dart' show MinstackWidget;
import 'package:flutter/material.dart';

class MinstackModel extends FlutterFlowModel<MinstackWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
