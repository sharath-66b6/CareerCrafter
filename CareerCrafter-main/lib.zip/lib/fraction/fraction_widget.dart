import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'fraction_model.dart';
export 'fraction_model.dart';

class FractionWidget extends StatefulWidget {
  const FractionWidget({super.key});

  @override
  State<FractionWidget> createState() => _FractionWidgetState();
}

class _FractionWidgetState extends State<FractionWidget> {
  late FractionModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => FractionModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Fraction',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven two integers representing the numerator and denominator of a fraction, return the fraction in string format.\n\nIf the fractional part is repeating, enclose the repeating part in parentheses.\n\n\nProblem Constraints\nINTMIN <= A, B <= INTMAX\n\n\nInput Format\nThe first integer A represents the numerator.\nThe second integer B represents the denominator.\n\n\nOutput Format\nReturn a string\n\n\nExample Input\nInput 1:\nA = 1\nB = 2\nInput 2:\nA = 2\nB = 1\nInput 3:\nA = 2\nB = 3\n\n\nExample Output\nOutput 1:\n\"0.5\"\nOutput 2:\n\"2\"\nOutput 3:\n\"0.(6)\"\n\n\nExample Explanation\nExplanation 1:\nGiven numerator = 1, denominator = 2, return \"0.5\"\nExplanation 1:\nGiven numerator = 2, denominator = 1, return \"2\"\nExplanation 1:\nGiven numerator = 2, denominator = 3, return \"0.(6)\"\n\n\n\n\nAnswer :-\n/**\n * @input A : Integer\n * @input B : Integer\n * \n * @Output string. Make sure the string ends with null character\n */\n\nunsigned int next(unsigned int p, unsigned int q) {\n    return (p*10ull)%q;\n}\n\nchar* fractionToDecimal(int numerator_, int denominator)\n{\n    int si = 0,i;\n    unsigned int q = denominator, numerator = numerator_;\n    if (!numerator_) return \"0\";\n    if (numerator_ < 0) numerator = -numerator_, si = 1-si;\n    if (denominator < 0) q = -q, si = 1-si;\n    unsigned int r0 = numerator % q;\n    unsigned int r1 = next(r0, q);\n    while (r0 != r1) {\n        r0 = next(r0, q);\n        r1 = next(r1, q);\n        r1 = next(r1, q);\n    }\n    int clen = 0;\n    if (r0) {\n        do {\n            r0 = next(r0, q); clen++;\n        } while (r0 != r1);\n    }\n    r0 = numerator % q;\n    r1 = clen ? r0 : 0;\n    for ( i = 0; i < clen; i++) r1 = next(r1, q);\n    int fralen = 0;\n    while (r0 != r1) {\n        fralen++;\n        r0 = next(r0, q);\n        r1 = next(r1, q);\n    }\n    char *s = (char *)malloc(20 + fralen + clen);\n    int slen = 0;\n    if (si) s[slen++] = \'-\';\n    slen += sprintf(s+slen, \"%u\", numerator / q);\n    r0 = numerator % q;\n    if (r0 == 0) return s;\n    s[slen++] = \'.\';\n    for (i = 0; i < fralen; i++) {\n        s[slen++] = (r0 * 10ull)/q + \'0\';\n        r0 = next(r0, q);\n    }\n    if (!clen) { s[slen++] = 0; return s; }\n    s[slen++]=\'(\';\n    for (i = 0; i < clen; i++) {\n        s[slen++] = (r0 * 10ull)/q + \'0\';\n        r0 = next(r0, q);\n    }\n    s[slen++]=\')\';\n    s[slen++]=0;\n    return s;\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=2cRS9dNa780&pp=ygUdaW50ZXJ2aWV3Yml0IGZyYWN0aW9uIGhhc2hpbmc%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
