import '/flutter_flow/flutter_flow_util.dart';
import 'fraction_widget.dart' show FractionWidget;
import 'package:flutter/material.dart';

class FractionModel extends FlutterFlowModel<FractionWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
