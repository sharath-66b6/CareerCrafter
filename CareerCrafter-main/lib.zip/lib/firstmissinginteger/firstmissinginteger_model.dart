import '/flutter_flow/flutter_flow_util.dart';
import 'firstmissinginteger_widget.dart' show FirstmissingintegerWidget;
import 'package:flutter/material.dart';

class FirstmissingintegerModel
    extends FlutterFlowModel<FirstmissingintegerWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
