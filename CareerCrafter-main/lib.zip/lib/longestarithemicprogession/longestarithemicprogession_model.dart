import '/flutter_flow/flutter_flow_util.dart';
import 'longestarithemicprogession_widget.dart'
    show LongestarithemicprogessionWidget;
import 'package:flutter/material.dart';

class LongestarithemicprogessionModel
    extends FlutterFlowModel<LongestarithemicprogessionWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
