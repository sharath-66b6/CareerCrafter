import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'longestarithemicprogession_model.dart';
export 'longestarithemicprogession_model.dart';

class LongestarithemicprogessionWidget extends StatefulWidget {
  const LongestarithemicprogessionWidget({super.key});

  @override
  State<LongestarithemicprogessionWidget> createState() =>
      _LongestarithemicprogessionWidgetState();
}

class _LongestarithemicprogessionWidgetState
    extends State<LongestarithemicprogessionWidget> {
  late LongestarithemicprogessionModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => LongestarithemicprogessionModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Longest Arithmetic Progression',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2100.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nFind the longest Arithmetic Progression in an integer array A of size N, and return its length.\n\nMore formally, find longest sequence of indices, 0 < i1 < i2 < … < ik < ArraySize(0-indexed) such that sequence A[i1], A[i2], …, A[ik] is an Arithmetic Progression.\n\nArithmetic Progression is a sequence in which all the differences between consecutive pairs are the same, i.e sequence B[0], B[1], B[2], …, B[m - 1] of length m is an Arithmetic Progression if and only if B[1] - B[0] == B[2] - B[1] == B[3] - B[2] == … == B[m - 1] - B[m - 2]\n\nNote: The common difference can be positive, negative, or 0.\n\n\nProblem Constraints\n1 <= N <= 1000\n1 <= A[i] <= 1e9\n\n\nInput Format\nThe first and only argument of input contains an integer array, A.\n\n\nOutput Format\nReturn an integer, representing the length of the longest possible arithmetic progression.\n\n\nExample Input\nInput 1:\n A = [3, 6, 9, 12]\nInput 2:\n A = [9, 4, 7, 2, 10]\n\n\nExample Output\nOutput 1:\n4\nOutput 2:\n3\n\n\nExample Explanation\nExplanation 1:\n[3, 6, 9, 12] form an arithmetic progression.\nExplanation 1:\n[4, 7, 10] form an arithmetic progression.\n\n\n\n\nAnswer :-\n/**\n * @input A : Read only ( DON\'T MODIFY ) Integer array\n * @input n1 : Integer array\'s ( A ) length\n * \n * @Output Integer\n */\n\nint solve(const int* A, int n1) {\n \n   int table[n1][n1];\n   int i,j,k;\n   int pos;\n   int max_len=2;\n   \n   \n   if(n1<=1)\n    return n1;\n    \n   for(i=0; i<n1-1; i++)\n   {\n       for(j=i+1; j<n1; j++)\n       {\n           table[i][j]=2;\n           pos=-1;\n           for(k=i-1; k>=0; k--)\n           {\n               if(A[k]==(2*A[i]-A[j]))\n               {\n                pos=k;\n                break;\n               }\n           }\n           if(pos!=-1)\n           {\n               if(table[i][j]<(table[pos][i]+1))\n               {\n                    table[i][j]=table[pos][i]+1;\n                    if(max_len<table[i][j])\n                        max_len=table[i][j];\n               }\n           }\n       }\n   }\n   \n   return max_len;\n    \n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=YaMcX7sem70&pp=ygUraW50ZXJ2aWV3Yml0IGxvbmdlc3QgYXJpdGhtZXRpYyBwcm9ncmVzc2lvbg%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
