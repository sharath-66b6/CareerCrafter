import '/flutter_flow/flutter_flow_util.dart';
import 'minsumpathinmatrix_widget.dart' show MinsumpathinmatrixWidget;
import 'package:flutter/material.dart';

class MinsumpathinmatrixModel
    extends FlutterFlowModel<MinsumpathinmatrixWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
