import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'minsumpathinmatrix_model.dart';
export 'minsumpathinmatrix_model.dart';

class MinsumpathinmatrixWidget extends StatefulWidget {
  const MinsumpathinmatrixWidget({super.key});

  @override
  State<MinsumpathinmatrixWidget> createState() =>
      _MinsumpathinmatrixWidgetState();
}

class _MinsumpathinmatrixWidgetState extends State<MinsumpathinmatrixWidget> {
  late MinsumpathinmatrixModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MinsumpathinmatrixModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Min Sum Path in Matrix',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1700.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven a 2D integer array A of size M x N, you need to find a path from top left to bottom right which minimizes the sum of all numbers along its path.\n\nNOTE: You can only move either down or right at any point in time. \n\n\n\nInput Format\nFirst and only argument is an 2D integer array A of size M x N.\n\n\n\nOutput Format\nReturn a single integer denoting the minimum sum of a path from cell (1, 1) to cell (M, N).\n\n\n\nExample Input\nInput 1:\n\n A = [  [1, 3, 2]\n        [4, 3, 1]\n        [5, 6, 1]\n     ]\n\n\nExample Output\nOutput 1:\n\n 8\n\n\nExample Explanation\nExplanation 1:\n\n The path is 1 -> 3 -> 2 -> 1 -> 1\n So ( 1 + 3 + 2 + 1 + 1) = 8\n\n\n\nAnswer:-\n/**\n * @input A : 2D integer array \n * @input n11 : Integer array\'s ( A ) rows\n * @input n12 : Integer array\'s ( A ) columns\n * \n * @Output Integer\n */\nint minPathSum(int** A, int n11, int n12) {\n    int dp[n11][n12];\n    int i,j;for(i = 0;i<n11;i++)\n    for(j = 0;j<n12;j++)\n    {\ndp[i][j] = A[i][j];\nif(i==0 && j==0)continue;\nint m = INT_MAX ,n = INT_MAX;\nif(i>0)\nm = dp[i-1][j];\nif(j>0)\nn =  dp[i][j-1];\nif(m>n)\ndp[i][j] = dp[i][j]+n;\nelse\n        dp[i][j] = dp[i][j]+ m;\n        \n    }\n    return dp[n11-1][n12-1];\n    \n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=BzTIOsC0xWM&pp=ygUjaW50ZXJ2aWV3Yml0IG1pbiBzdW0gcGF0aCBpbiBtYXRyaXg%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
