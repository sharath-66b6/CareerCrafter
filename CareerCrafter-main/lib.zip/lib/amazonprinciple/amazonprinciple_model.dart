import '/flutter_flow/flutter_flow_util.dart';
import 'amazonprinciple_widget.dart' show AmazonprincipleWidget;
import 'package:flutter/material.dart';

class AmazonprincipleModel extends FlutterFlowModel<AmazonprincipleWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
