import '/flutter_flow/flutter_flow_util.dart';
import 'combinationsum2_widget.dart' show Combinationsum2Widget;
import 'package:flutter/material.dart';

class Combinationsum2Model extends FlutterFlowModel<Combinationsum2Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
