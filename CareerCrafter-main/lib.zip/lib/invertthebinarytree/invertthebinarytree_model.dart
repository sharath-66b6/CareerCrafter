import '/flutter_flow/flutter_flow_util.dart';
import 'invertthebinarytree_widget.dart' show InvertthebinarytreeWidget;
import 'package:flutter/material.dart';

class InvertthebinarytreeModel
    extends FlutterFlowModel<InvertthebinarytreeWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
