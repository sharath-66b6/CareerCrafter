import '/flutter_flow/flutter_flow_util.dart';
import 'developerrelation_widget.dart' show DeveloperrelationWidget;
import 'package:flutter/material.dart';

class DeveloperrelationModel extends FlutterFlowModel<DeveloperrelationWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
