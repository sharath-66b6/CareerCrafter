import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'copylist_model.dart';
export 'copylist_model.dart';

class CopylistWidget extends StatefulWidget {
  const CopylistWidget({super.key});

  @override
  State<CopylistWidget> createState() => _CopylistWidgetState();
}

class _CopylistWidgetState extends State<CopylistWidget> {
  late CopylistModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CopylistModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Copy List',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1400.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n\nA linked list is given such that each node contains an additional random pointer which could point to any node in the list or NULL.\n\nReturn a deep copy of the list.\n\nExample\n\nGiven list\n\n   1 -> 2 -> 3\nwith random pointers going from\n\n  1 -> 3\n  2 -> 1\n  3 -> 1\nYou should return a deep copy of the list. The returned answer should not contain the same node as the original list, but a copy of them. The pointers in the returned list should not link to any node in the original input list.\n\n\nAnswer :-\n/**\n * Definition for singly-linked list with a random pointer.\n * struct RandomListNode {\n *     int label;\n *     struct RandomListNode *next;\n *     struct RandomListNode *random;\n * };\n */\nstruct RandomListNode *copyRandomList(struct RandomListNode *head) {\n    struct RandomListNode *temp1,*temp2,*head2=NULL;\n    temp1 = head;\n    while(temp1!=NULL){\n    \ttemp2 = (struct RandomListNode*)(malloc(sizeof(struct RandomListNode)));\n    \ttemp2->label=temp1->label;\n    \ttemp2->next=temp1->random;\n    \ttemp2->random=NULL;\n    \ttemp1->random=temp2;\n    \ttemp1=temp1->next; \n    }\n    temp1=head;\n    while(temp1!=NULL){\n    \ttemp2 = temp1->random;\n    \tif(temp2->next!=NULL)\n    \t\ttemp2->random=temp2->next->random;\n    \telse\n    \t\ttemp2->random=NULL;\n    \ttemp1=temp1->next; \n    }\n    temp1=head;\n    if(temp1!=NULL)\n    \thead2 = temp1->random;\n    while(temp1!=NULL){\n    \t//printf(\"%d->\",temp1->random->next->label );\n    \ttemp2=temp1->random;\n    \ttemp1->random=temp1->random->next;\n    \tif(temp1->next!=NULL)\n    \t\ttemp2->next=temp1->next->random;\n    \telse\n    \t\ttemp2->next=NULL;\n    \ttemp1=temp1->next;\n    }\n    return head2;\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=4apaOcK586U&pp=ygUpaW50ZXJ2aWV3Yml0IGNvcHkgbGlzdCAoaGFzaGluZyBxdWVzdGlvbik%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
