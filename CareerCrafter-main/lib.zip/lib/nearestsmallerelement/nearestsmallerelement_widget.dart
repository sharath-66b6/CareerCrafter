import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'nearestsmallerelement_model.dart';
export 'nearestsmallerelement_model.dart';

class NearestsmallerelementWidget extends StatefulWidget {
  const NearestsmallerelementWidget({super.key});

  @override
  State<NearestsmallerelementWidget> createState() =>
      _NearestsmallerelementWidgetState();
}

class _NearestsmallerelementWidgetState
    extends State<NearestsmallerelementWidget> {
  late NearestsmallerelementModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => NearestsmallerelementModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Nearest Smaller Element',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2400.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \nGiven an array, find the nearest smaller element G[i] for every element A[i] in the array such that the element has an index smaller than i.\n\nMore formally,\n\n    G[i] for an element A[i] = an element A[j] such that \n    j is maximum possible AND \n    j < i AND\n    A[j] < A[i]\nElements for which no smaller element exist, consider next smaller element as -1.\n\nInput Format\n\nThe only argument given is integer array A.\nOutput Format\n\nReturn the integar array G such that G[i] contains nearest smaller number than A[i].If no such element occurs G[i] should be -1.\nFor Example\n\nInput 1:\n    A = [4, 5, 2, 10, 8]\nOutput 1:\n    G = [-1, 4, -1, 2, 2]\nExplaination 1:\n    index 1: No element less than 4 in left of 4, G[1] = -1\n    index 2: A[1] is only element less than A[2], G[2] = A[1]\n    index 3: No element less than 2 in left of 2, G[3] = -1\n    index 4: A[3] is nearest element which is less than A[4], G[4] = A[3]\n    index 4: A[3] is nearest element which is less than A[5], G[5] = A[3]\n    \nInput 2:\n    A = [3, 2, 1]\nOutput 2:\n    [-1, -1, -1]\nExplaination 2:\n    index 1: No element less than 3 in left of 3, G[1] = -1\n    index 2: No element less than 2 in left of 2, G[2] = -1\n    index 3: No element less than 1 in left of 1, G[3] = -1\n\n\n\n\n\nAnswer :-\n/**\n * @input A : Integer array\n * @input n1 : Integer array\'s ( A ) length\n * \n * @Output Integer array. You need to malloc memory, and fill the length in len1\n */\nint* prevSmaller(int* A, int n1, int *len1) {\n    *len1 = n1;\n    int i,j,arr[n1];\n    int stac[n1];\n    int idx = 0;\n    arr[0] = -1;\n    for(i=1;i<n1;i++)\n    {\n        j = i - 1;\n        if(A[i] > A[j])\n        {\n            arr[i] = A[j];\n            if(idx > 0)\n            {\n                idx --;\n                while(stac[idx] > A[j] && idx > 0)\n                {\n                    idx--;\n                }\n                idx++;\n            }\n            stac[idx] = A[j];\n            idx++;\n        }\n        else\n        {\n            if(idx==0)\n            {\n                arr[i] = -1;\n                stac[idx] = A[j];\n                idx++;\n            }\n            else\n            {\n                idx--;\n                while(stac[idx]>=A[i] && idx >= 0)\n                {\n                    idx--;\n                }\n                if(idx<0)\n                {\n                    arr[i] = -1;\n                }\n                else\n                {\n                    arr[i] = stac[idx];\n                }\n                idx++;\n                stac[idx] = A[j];\n                idx++;\n            }\n        }\n    }\n    for(i=0;i<n1;i++)\n    {\n        A[i] = arr[i];\n    }\n    return A;\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=496MkZvlWac&pp=ygUkaW50ZXJ2aWV3Yml0IG5lYXJlc3Qgc21hbGxlciBlbGVtZW50',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
