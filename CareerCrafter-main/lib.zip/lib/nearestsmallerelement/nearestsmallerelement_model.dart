import '/flutter_flow/flutter_flow_util.dart';
import 'nearestsmallerelement_widget.dart' show NearestsmallerelementWidget;
import 'package:flutter/material.dart';

class NearestsmallerelementModel
    extends FlutterFlowModel<NearestsmallerelementWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
