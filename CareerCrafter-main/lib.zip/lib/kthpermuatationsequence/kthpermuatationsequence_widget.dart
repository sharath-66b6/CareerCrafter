import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'kthpermuatationsequence_model.dart';
export 'kthpermuatationsequence_model.dart';

class KthpermuatationsequenceWidget extends StatefulWidget {
  const KthpermuatationsequenceWidget({super.key});

  @override
  State<KthpermuatationsequenceWidget> createState() =>
      _KthpermuatationsequenceWidgetState();
}

class _KthpermuatationsequenceWidgetState
    extends State<KthpermuatationsequenceWidget> {
  late KthpermuatationsequenceModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => KthpermuatationsequenceModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Kth Permutation Sequence',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2200.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\nThe set [1,2,3,…,n] contains a total of n! unique permutations.\n\nBy listing and labeling all of the permutations in order,\n\nWe get the following sequence (ie, for n = 3 ) :\n\n1. \"123\"\n2. \"132\"\n3. \"213\"\n4. \"231\"\n5. \"312\"\n6. \"321\"\nGiven n and k, return the kth permutation sequence.\n\nFor example, given n = 3, k = 4, ans = \"231\"\n\nGood questions to ask the interviewer :\n\nWhat if n is greater than 10. How should multiple digit numbers be represented in string?\nIn this case, just concatenate the number to the answer.\n\n so if n = 11, k = 1, ans = \"1234567891011\"\n\nWhats the maximum value of n and k?\nIn this case, k will be a positive integer thats less than INT_MAX.\n\nn is reasonable enough to make sure the answer does not bloat up a lot.\n\n\n\n\nAnswer :-\n/**\n * @input n : Integer\n * @input k : Integer\n * \n * @Output string. Make sure the string ends with null character\n */\n\n#include <stdio.h>\n#include <string.h>\n#include <stdlib.h>\n//#include <cstdlib>\nchar* itoa(int val){\n\t\n\tchar *str=malloc(sizeof(char)*10);\n\tint c=0,num=val,i;\n\twhile (num)\n\t    {\n\t        str[c++]=(char)((num%10)+48);\n\t        num=num/10;\n\t    }\n\tfor (i=0;i<c/2;i++)\n\t    {\n\t        char temp=str[0];\n\t        str[0]=str[c-1-i];\n\t        str[c-1-i]=temp;\n\t    }\n\treturn str;\n\t\n}\nint get(int *list,int n,int x)\n{\n\tint i,c=0;\n\tfor (i=0;i<n;i++)\n\t\t{\n\t\t\tif (list[i]!=0 && c==x)\n\t\t\t\t{\n\t\t\t\t\tlist[i]=0;\n\t\t\t\t\treturn i+1;\n\t\t\t\t}\n\t\t\t\t\n\t\t\telse\n\t\t\t\t{\n\t\t\t\t\tif (list[i]!=0)\n\t\t\t\t\t\tc++;\n\t\t\t\t}\n\t\t\t\t\n\t\t}\n\treturn 0;\n}\t\nint fact(int n)\n{\n    if (n>=12)\n        return INT_MAX;\n\tif (n<=1)\n\t\treturn 1;\n\telse return n*fact(n-1);\n}\nchar* getPermutation(int n, int k) {\n\tint val=k-1;\n\tint *list=(int*)malloc(sizeof(int)*n);\n\tint i;\n\tfor (i=0;i<n;i++)\n\t\tlist[i]=i+1;\n\tchar *result=(char *)malloc(sizeof(char)*100000);\n\tfor (i=0;i<n;i++)\n\t\t{\n\t\t\tint temp=val;\n\t\t\ttemp=(val)/fact(n-1-i);\n\t\t\tint num=get(list,n,temp);\n\t\t\tchar *str=(char*)malloc(sizeof(char)*100000);\n\t\t\tstr=itoa(num);\n\t\t\tstrcat(result,str);\n\t\t\t//printf(\"%d \",num);\n\t\t\tval=val%fact(n-1-i);\n\t\t}\n\treturn result;\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=wT7gcXLYoao&pp=ygUmaW50ZXJ2aWV3Yml0IGt0aCBwZXJtdWF0YXRpb24gc2VxdWVuY2U%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
