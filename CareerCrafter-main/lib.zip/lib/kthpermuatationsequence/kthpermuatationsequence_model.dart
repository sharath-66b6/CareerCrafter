import '/flutter_flow/flutter_flow_util.dart';
import 'kthpermuatationsequence_widget.dart' show KthpermuatationsequenceWidget;
import 'package:flutter/material.dart';

class KthpermuatationsequenceModel
    extends FlutterFlowModel<KthpermuatationsequenceWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
