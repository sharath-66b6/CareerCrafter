import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'matrixsearch_model.dart';
export 'matrixsearch_model.dart';

class MatrixsearchWidget extends StatefulWidget {
  const MatrixsearchWidget({super.key});

  @override
  State<MatrixsearchWidget> createState() => _MatrixsearchWidgetState();
}

class _MatrixsearchWidgetState extends State<MatrixsearchWidget> {
  late MatrixsearchModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MatrixsearchModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Matrix Search',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2400.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven a matrix of integers A of size N x M and an integer B. Write an efficient algorithm that searches for integer B in matrix A. \n\nThis matrix A has the following properties:\n\nIntegers in each row are sorted from left to right.\nThe first integer of each row is greater than or equal to the last integer of the previous row.\nReturn 1 if B is present in A, else return 0.\n\nNOTE: Rows are numbered from top to bottom, and columns are from left to right.\n\n\n\nProblem Constraints\n1 <= N, M <= 1000\n\n1 <= A[i][j], B <= 106\n\n\n\nInput Format\nThe first argument given is the integer matrix A.\n\nThe second argument given is the integer B.\n\n\n\nOutput Format\nReturn 1 if B is present in A else, return 0.\n\n\n\nExample Input\nInput 1: \n\nA = [ \n      [1,   3,  5,  7]\n      [10, 11, 16, 20]\n      [23, 30, 34, 50]\n\n    ]\nB = 3\nInput 2:\n\nA = [\n\n      [5, 17, 100, 111]\n      [119, 120, 127, 131]\n\n    ]\nB = 3\n\n\nExample Output\nOutput 1: \n\n1\nOutput 2:\n\n0\n\n\nExample Explanation\nExplanation 1: \n\n 3 is present in the matrix at A[0][1] position so return 1.\nExplanation 2:\n\n 3 is not present in the matrix so return 0.\n\n\n\nAnswer :- \n/**\n * @input A : 2D integer array \' * @input n11 : Integer array\'s ( A ) rows\n * @input n12 : Integer array\'s ( A ) columns\n * @input B : Integer\n * \n * @Output Integer\n */\nint searchMatrix(int** A, int n11, int n12, int B) {\n    int low=0,high=n11-1,row=-1,col=-1;\n\twhile ( low <= high ) {\n\t\tint mid=(low+high)/2;\n\t\t//cout<<\" low : \"<<low<<\" high : \"<<high<<\" mid : \"<<mid<<\" B: \"<<B<<\" A[mid][0]: \"<<A[mid][0]<<\" A[mid][n12-1] : \"<<A[mid][n12-1]<<endl;\n\t\tif(A[mid][0]<=B && B<=A[mid][n12-1]) {\n\t\t\t//cout<<\" row found \"<<row<<endl;\n\t\t\trow=mid;\n\t\t\tbreak;\n\t\t}\n\t\telse if(A[mid][0]>B)\n\t\t\thigh=mid-1;\n\t\telse\n\t\t\tlow=mid+1;\n\t}\n\tif(row==-1) \n\t    return 0;\n\tlow=0,high=n12-1;\n\twhile( low <= high ) {\n\t\tint mid=(low+high)/2;\n\t\t//cout<<\" low : \"<<low<<\" high : \"<<high<<\" mid : \"<<mid<<\" B: \"<<B<<\" A[row][low]: \"<<A[row][low]<<\" A[row][n12-1] : \"<<A[row][high]<<endl;\n\t\tif(A[row][mid]==B) {\n\t\t\tcol=mid;\n\t\t\tbreak;\n\t\t}\n\t\telse if(A[row][mid]>B)\n\t\t\thigh=mid-1;\n\t\telse\n\t\t\tlow=mid+1;\n\t}\n\tif(col==-1) \n\t    return 0;\n\treturn 1;\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=zIZMABzz8rg&pp=ygUZaW50ZXJ2aWV3Yml0IG1hdHJpeHNlYXJjaA%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
