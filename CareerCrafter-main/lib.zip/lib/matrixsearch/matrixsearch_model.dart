import '/flutter_flow/flutter_flow_util.dart';
import 'matrixsearch_widget.dart' show MatrixsearchWidget;
import 'package:flutter/material.dart';

class MatrixsearchModel extends FlutterFlowModel<MatrixsearchWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
