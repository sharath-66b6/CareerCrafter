import '/flutter_flow/flutter_flow_util.dart';
import 'knighonchessboard_widget.dart' show KnighonchessboardWidget;
import 'package:flutter/material.dart';

class KnighonchessboardModel extends FlutterFlowModel<KnighonchessboardWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
