import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'knighonchessboard_model.dart';
export 'knighonchessboard_model.dart';

class KnighonchessboardWidget extends StatefulWidget {
  const KnighonchessboardWidget({super.key});

  @override
  State<KnighonchessboardWidget> createState() =>
      _KnighonchessboardWidgetState();
}

class _KnighonchessboardWidgetState extends State<KnighonchessboardWidget> {
  late KnighonchessboardModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => KnighonchessboardModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Knight On Chess Board',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 3500.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven any source point, (C, D) and destination point, (E, F) on a chess board, we need to find whether Knight can move to the destination or not.\n\nKnight\'s movements on a chess board\n\nThe above figure details the movements for a knight ( 8 possibilities ).\n\nIf yes, then what would be the minimum number of steps for the knight to move to the said point.\n\nIf knight can not move from the source point to the destination point, then return -1.\n\nNote: A knight cannot go out of the board.\n\n\n\nInput Format:\n\nThe first argument of input contains an integer A.\nThe second argument of input contains an integer B.\n    => The chessboard is of size A x B.\nThe third argument of input contains an integer C.\nThe fourth argument of input contains an integer D.\n    => The Knight is initially at position (C, D).\nThe fifth argument of input contains an integer E.\nThe sixth argument of input contains an integer F.\n    => The Knight wants to reach position (E, F).\nOutput Format:\n\nIf it is possible to reach the destination point, return the minimum number of moves.\nElse return -1.\nConstraints:\n\n1 <= A, B <= 500\nExample\n\nInput 1:\n    A = 8\n    B = 8\n    C = 1\n    D = 1\n    E = 8\n    F = 8\n    \nOutput 1:\n    6\n\nExplanation 1:\n    The size of the chessboard is 8x8, the knight is initially at (1, 1) and the knight wants to reach position (8, 8).\n    The minimum number of moves required for this is 6.\n\n\n\n\nAnswer :-\n/**\n * @input N : Integer\n * @input M : Integer\n * @input x1 : Integer\n * @input y1 : Integer\n * @input x2 : Integer\n * @input y2 : Integer\n * \n * @Output Integer\n */\ntypedef struct {\n    int x;\n    int y;\n} point;\n\nint knight(int N, int M, int x1, int y1, int x2, int y2) {\n    point q[100000];\n    int **v;\n    int i, j;\n    int cur = 0, max = 0;\n    int move = 0;\n    int ret = -1;\n    \n    v = (int **)calloc(1, sizeof(int*)*M);\n    for (i=0; i<M; i++) {\n        v[i] = (int*)calloc(1, sizeof(int)*N);\n    }\n    \n    x1--;y1--;x2--;y2--;\n    \n    q[max].x = x1;\n    q[max].y = y1;\n    v[y1][x1] = 1;\n    max++;\n    \n    int curstep = 1;\n    while (cur < max) {\n        while (curstep == v[q[cur].y][q[cur].x]) {\n        point *p = &q[cur];\n        int curx, cury;\n        \n        //printf(\"[(c%d/%d,%d m%d)]\", curstep, p->x, p->y, v[p->y][p->x], v[p->y][p->x]-1);\n        \n        if (p->x == x2 && p->y == y2) {\n            return v[p->y][p->x]-1;\n        }\n        \n        \n        curx = p->x - 2; cury = p->y - 1;\n        if (curx >= 0 && cury >= 0 && !v[cury][curx]) {\n            q[max].x = curx;\n            q[max].y = cury;\n            v[cury][curx] = v[p->y][p->x]+1;\n            max++;\n            if (max >= 100000) return -1;\n        }\n        curx = p->x - 1; cury = p->y - 2;\n        if (curx >= 0 && cury >= 0 && !v[cury][curx]) {\n            q[max].x = curx;\n            q[max].y = cury;\n            v[cury][curx] = v[p->y][p->x]+1;\n            max++;\n            if (max >= 100000) return -1;\n        }\n        curx = p->x + 1; cury = p->y - 2;\n        if (curx < N && cury >= 0 && !v[cury][curx]) {\n            q[max].x = curx;\n            q[max].y = cury;\n            v[cury][curx] = v[p->y][p->x]+1;\n            max++;\n            if (max >= 100000) return -1;\n        }\n        curx = p->x + 2; cury = p->y - 1;\n        if (curx < N && cury >= 0 && !v[cury][curx]) {\n            q[max].x = curx;\n            q[max].y = cury;\n            v[cury][curx] = v[p->y][p->x]+1;\n            max++;\n            if (max >= 100000) return -1;\n        }\n        curx = p->x + 2; cury = p->y + 1;\n        if (curx < N && cury < M && !v[cury][curx]) {\n            q[max].x = curx;\n            q[max].y = cury;\n            v[cury][curx] = v[p->y][p->x]+1;\n            max++;\n            if (max >= 100000) return -1;\n        }\n        curx = p->x + 1; cury = p->y + 2;\n        if (curx < N && cury < M && !v[cury][curx]) {\n            q[max].x = curx;\n            q[max].y = cury;\n            v[cury][curx] = v[p->y][p->x]+1;\n            max++;\n            if (max >= 100000) return -1;\n        }\n        curx = p->x - 1; cury = p->y + 2;\n        if (curx >= 0 && cury < M && !v[cury][curx]) {\n            q[max].x = curx;\n            q[max].y = cury;\n            v[cury][curx] = v[p->y][p->x]+1;\n            max++;\n            if (max >= 100000) return -1;\n        }\n        curx = p->x - 2; cury = p->y + 1;\n        if (curx >= 0 && cury < M && !v[cury][curx]) {\n            q[max].x = curx;\n            q[max].y = cury;\n            v[cury][curx] = v[p->y][p->x]+1;\n            max++;\n            if (max >= 100000) return -1;\n        }\n        \n        //curmax = max;\n        move++;\n        cur++;\n        }\n        curstep++;\n    }\n    return ret;\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=FhwNdxnb738&pp=ygUiaW50ZXJ2aWV3Yml0IGtuaWdodCBvbiBjaGVzcyBib2FyZA%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
