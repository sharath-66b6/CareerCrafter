import '/flutter_flow/flutter_flow_util.dart';
import 'monkeyandoor_widget.dart' show MonkeyandoorWidget;
import 'package:flutter/material.dart';

class MonkeyandoorModel extends FlutterFlowModel<MonkeyandoorWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
