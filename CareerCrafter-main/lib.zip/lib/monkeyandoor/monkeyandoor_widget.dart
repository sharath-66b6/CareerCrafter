import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'monkeyandoor_model.dart';
export 'monkeyandoor_model.dart';

class MonkeyandoorWidget extends StatefulWidget {
  const MonkeyandoorWidget({super.key});

  @override
  State<MonkeyandoorWidget> createState() => _MonkeyandoorWidgetState();
}

class _MonkeyandoorWidgetState extends State<MonkeyandoorWidget> {
  late MonkeyandoorModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MonkeyandoorModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Monkeys and Doors',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 900.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'There are 100 doors, all closed. \n\nIn a nearby cage are 100 monkeys.\n\nThe first monkey is let out and runs along the doors opening every one. \n\nThe second monkey is then let out and runs along the doors closing the 2nd, 4th, 6th,…  - all the even-numbered doors. \n\nThe third monkey is let out. He attends only to the 3rd, 6th, 9th,… doors (every third door, in other words), closing any that is open and opening any that is closed, and so on. \n\nAfter all 100 monkeys have done their work in this way, what state are the doors in after the last pass?\n\nAnswer with the number of open doors.\n\nAnswer is an integer.  Just put the number without any decimal places if it’s an integer. If the answer is Infinity, output Infinity.\n\nFeel free to get in touch with us if you have any questions\n\n\n\n\nAnswer :-\nConsider door number 56. Monkeys will visit it for every divisor it has. So 56 has 1 & 56, 2 & 28, 4 & 14, 7 & 8.\nSo on pass 1 1st monkey will open the door, pass 2 2nd one will close it, pass 4 open, pass 7 close, pass 8 open, pass 14 close, pass 28 open, pass 56 close. \nFor every pair of divisors, the door will end up back in its initial state. But there are cases in which the pair of divisors has the same number, for example, door number 16. 16 has the divisors 1 & 16, 2 & 8, 4&4. \nBut 4 is repeated because 16 is a perfect square, so you will only visit door number 16, on passes 1, 2, 4, 8, and 16, leaving it open at the end. So only perfect square doors will be open at the end.',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=eB4Ix5NTGCU&pp=ygUdaW50ZXJ2aWV3Yml0IG1vbmtleSBhbmQgZG9vcnM%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
