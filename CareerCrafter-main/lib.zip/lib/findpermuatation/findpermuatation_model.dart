import '/flutter_flow/flutter_flow_util.dart';
import 'findpermuatation_widget.dart' show FindpermuatationWidget;
import 'package:flutter/material.dart';

class FindpermuatationModel extends FlutterFlowModel<FindpermuatationWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
