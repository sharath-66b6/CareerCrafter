import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'deserialize_model.dart';
export 'deserialize_model.dart';

class DeserializeWidget extends StatefulWidget {
  const DeserializeWidget({super.key});

  @override
  State<DeserializeWidget> createState() => _DeserializeWidgetState();
}

class _DeserializeWidgetState extends State<DeserializeWidget> {
  late DeserializeModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => DeserializeModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Deserialize',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1500.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nYou are given a string A which is a serialized string. You have to restore the original array of strings.\n\nThe string in the output array should only have lowercase english alphabets.\n\nSerialization: Scan each element in a string, calculate its length and append it with a string and a element separator or deliminator (the deliminator is ~). We append the length of the string so that we know the length of each element.\n\nFor example, for a string \'interviewbit\', its serialized version would be \'interviewbit12~\'.\n\n\n\nProblem Constraints\n1 <= |A| <= 106\n\n\nInput Format\nThe first argument is the string A.\n\n\nOutput Format\nReturn an array of strings which are deserialized.\n\n\nExample Input\nInput 1:\nA = \'scaler6~academy7~\'\nInput 2:\n\nA = \'interviewbit12~\'\n\n\nExample Output\nOutput 1:\n[\'scaler\', \'academy\']\nOutput 2:\n\n[\'interviewbit\']\n\n\nExample Explanation\nExplanation 1:\nLength of \'scaler\' is 6 and academy is 7. So, the resulting string is scaler6~academy7~.\nWe hve to reverse the process.\nExplanation 2:\n\nExplained in the description above.\n\nAnswer :-\nclass Solution:\n    # @param A : string\n    # @return a list of strings\n    def deserialize(self, A):\n        ans = []\n        i = -1\n        j = 0\n        while (j < len(A)):\n            while(ord(A[j]) <= 122 and ord(A[j]) >= 97):\n                j+=1\n            \n            ans.append(A[i + 1: j])\n            while(j < len(A) and A[j] != \'~\'):\n                j+=1\n            \n            i = j\n            j += 1\n        \n        return ans\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=u4JAi2JJhI8&pp=ygUfaW50ZXJ2aWV3Yml0IHNlcmlhbGl6ZSBzb2x1dGlvbg%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
