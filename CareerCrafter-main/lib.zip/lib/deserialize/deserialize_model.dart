import '/flutter_flow/flutter_flow_util.dart';
import 'deserialize_widget.dart' show DeserializeWidget;
import 'package:flutter/material.dart';

class DeserializeModel extends FlutterFlowModel<DeserializeWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
