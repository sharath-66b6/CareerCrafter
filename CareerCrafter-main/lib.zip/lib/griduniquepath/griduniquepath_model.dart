import '/flutter_flow/flutter_flow_util.dart';
import 'griduniquepath_widget.dart' show GriduniquepathWidget;
import 'package:flutter/material.dart';

class GriduniquepathModel extends FlutterFlowModel<GriduniquepathWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
