import '/flutter_flow/flutter_flow_util.dart';
import 'deletededge_widget.dart' show DeletededgeWidget;
import 'package:flutter/material.dart';

class DeletededgeModel extends FlutterFlowModel<DeletededgeWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
