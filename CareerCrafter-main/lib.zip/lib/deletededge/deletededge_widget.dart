import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'deletededge_model.dart';
export 'deletededge_model.dart';

class DeletededgeWidget extends StatefulWidget {
  const DeletededgeWidget({super.key});

  @override
  State<DeletededgeWidget> createState() => _DeletededgeWidgetState();
}

class _DeletededgeWidgetState extends State<DeletededgeWidget> {
  late DeletededgeModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => DeletededgeModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Delete Edge!',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2500.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven an undirected tree with N nodes labeled from 1 to N.\n\nEach node has a certain weight assigned to it given by an integer array A of size N.\n\nYou need to delete an edge in such a way that the Product between the sum of weights of nodes in one subtree with the sum of weights of nodes in other subtree is maximized.\n\nReturn this maximum possible product modulo 109 + 7.\n\nNOTE:\n\nThe tree is rooted at a node labeled with 1.\nYou need to return the maximum possible product, then take its mod.\n\n\nProblem Constraints\n2 <= N <= 105\n\n1 <= A[i] <= 103\n\n\n\nInput Format\nFirst argument is an integer array A of size N denoting the weight of each node.\n\nSecond argument is a 2-D array B of size (N-1) x 2 denoting the edge of the tree.\n\n\n\nOutput Format\nReturn a single integer denoting the maximum product prossible of sum of weights of nodes in the two subtrees formed by deleting an edge with modulo 109 + 7.\n\n\n\nExample Input\nInput 1:\n\n A = [10, 5, 12, 6]\n B = [\n\n        [1, 2]\n        [1, 4]\n        [4, 3]\n     ]\nInput 2:\n\n A = [11, 12]\n B = [\n\n        [1, 2]\n     ]\n\n\nExample Output\nOutput 1:\n\n 270\nOutput 2:\n\n 132\n\n\nExample Explanation\nExplanation 1:\n\n Removing edge (1, 4) created two subtrees.\n Subtree-1 contains nodes (1, 2) and Subtree-2 contains nodes (3, 4)\n So product will be = (A[1] + A[2]) * (A[3] + A[4]) = 15 * 18 = 270\nExplanation 2:\n\n Removing edge (1, 2) created two subtrees.\n Subtree-1 contains node (1) and Subtree-2 contains node (3)\n So product will be = (A[1]) * (A[2]) = 11 * 12 = 132\n\n\n\nAnswer :-\nimport sys\nsys.setrecursionlimit(200000)\nadj = []\ns = 0\nmaxe = 0\nmod = 1000000007\n\n\ndef dfs(u, p, A):\n    global adj, s, maxe, mod\n    val = A[u - 1]\n    for v in adj[u]:\n        if v == p:\n            continue\n        val += dfs(v, u, A)\n    res = val * ((s - val)) % mod\n    maxe = max(maxe, res)\n    return val\n\n\nclass Solution:\n\n    # @param A : list of integers\n    # @param B : list of list of integers\n    # @return an integer\n\n    def deleteEdge(self, A, B):\n        global adj, s, maxe, mod\n        s = 0\n        maxe = 0\n        adj = [[] for i in range(100009)]\n        for a in A:\n            s += a\n        for edge in B:\n            adj[edge[0]].append(edge[1])\n            adj[edge[1]].append(edge[0])\n        dfs(1, 0, A)\n        return maxe',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=NzEzJ6Rmv2Q&pp=ygUdaW50ZXJ2aWV3Yml0IGRlbGV0ZSBlZGdlIGNvZGU%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
