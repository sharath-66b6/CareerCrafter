import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'findthedefectiveball_model.dart';
export 'findthedefectiveball_model.dart';

class FindthedefectiveballWidget extends StatefulWidget {
  const FindthedefectiveballWidget({super.key});

  @override
  State<FindthedefectiveballWidget> createState() =>
      _FindthedefectiveballWidgetState();
}

class _FindthedefectiveballWidgetState
    extends State<FindthedefectiveballWidget> {
  late FindthedefectiveballModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => FindthedefectiveballModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Find the Defective Ball',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1500.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'You have 12 balls all look identical (in shape, color etc.). \n\nAll of them have same weight except one defective ball. \n\nYou don’t know that the defective one is heavier or lighter than other balls. You can use a two sided balance system (not the electronic one).\n\nFind the minimum no. of measures required to separate the defective ball.\n\nAnswer is a integer.  Just put the number without any decimal places if its an integer. If the answer is Infinity, output Infinity.\n\n\nAnswer :-\nDivide the balls into 3 groups of 4 balls.\n\nFirst weigh :\n\nWeigh 2 groups, one on each side.\n\nThere will be two cases :\n\nThe weight on both side is equal i. e. these two groups don’t have the defective ball.\nOne side has less weight than the other side.\nCase 1 : You know 8 balls are of equal weight and one of the remaining 4 balls have a defective one. Name these four as B1, B2, B3, B4.\n\n** Second weigh :**\n\nTake B1, B2 and weight them.\n\nIf they are unequal then either B1 is defective or B2. Compare B1 with one of eight balls. If B1 is equal to that then B2 is defective otherwise B1.\nTotal measurements in this case : 1 (first weigh) + 1 (second weigh) + 1 (B1 with other ball) = 3\nIf B1 and B2 are equal then either B3 is defective or B4. Compare B3 with one of eight balls. If B3 is equal to that then B4 is defective otherwise B3.\nTotal measurements in this case : 1 (first weigh) + 1 (second weigh) + 1 (B3 with other ball) = 3\nCase 2 : Mark the balls in the side with less weight as L and with more weight as M. We get 4L and 4M.\n\nSecond weigh :\n\nTake 2L and 1M in One side say A and take 2L and 1M in Other side say B of balance system. 1M and 1L are reserved for now.\n\nIf side A is down and next side goes up then it has two possibilities.\nOne of 2L in A has less weight than other 7 balls\nThe 1M in B has more weight\nIf side B is down then it also has two possibilities.\nOne of 2L in A has less weight than other 7 balls\nOne of 1M in B has more weight than other 7 balls\nBoth sides are balanced\nThird weigh :\n\nIn cases (i) or (ii) we will get 3 balls (2L and 1M) after the second weigh.\n\nFor case (i) and (ii)of (b) :\n\nWeigh two L balls with each other, if they are equal then the 1M is heavier and if they are not then the ball with less weight is defective.\n\nFor case (iii) of (b) :\n\nIn this case one of the two reserved balls is defective. We have 2M balls. Weigh them, the one which is heavier is defectives.',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=91b7bWlNmm8&pp=ygUkaW50ZXJ2aWV3Yml0IGZpbmQgdGhlIGRlZmVjdGl2ZSBiYWxs',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
