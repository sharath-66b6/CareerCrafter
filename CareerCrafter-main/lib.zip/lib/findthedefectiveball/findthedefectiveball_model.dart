import '/flutter_flow/flutter_flow_util.dart';
import 'findthedefectiveball_widget.dart' show FindthedefectiveballWidget;
import 'package:flutter/material.dart';

class FindthedefectiveballModel
    extends FlutterFlowModel<FindthedefectiveballWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
