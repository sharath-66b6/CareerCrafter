import '/flutter_flow/flutter_flow_util.dart';
import 'mergetwobinarytree_widget.dart' show MergetwobinarytreeWidget;
import 'package:flutter/material.dart';

class MergetwobinarytreeModel
    extends FlutterFlowModel<MergetwobinarytreeWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
