import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'cognizantquestions_model.dart';
export 'cognizantquestions_model.dart';

class CognizantquestionsWidget extends StatefulWidget {
  const CognizantquestionsWidget({super.key});

  @override
  State<CognizantquestionsWidget> createState() =>
      _CognizantquestionsWidgetState();
}

class _CognizantquestionsWidgetState extends State<CognizantquestionsWidget> {
  late CognizantquestionsModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CognizantquestionsModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).primary,
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30.0,
            borderWidth: 1.0,
            buttonSize: 60.0,
            icon: const Icon(
              Icons.arrow_back_rounded,
              color: Colors.white,
              size: 30.0,
            ),
            onPressed: () async {
              context.pop();
            },
          ),
          title: Text(
            'Cognizant Interview Questions',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: 'Outfit',
                  color: Colors.white,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                ),
          ),
          actions: const [],
          centerTitle: true,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: ListView(
            padding: const EdgeInsets.symmetric(vertical: 12.0),
            scrollDirection: Axis.vertical,
            children: [
              Container(
                width: 100.0,
                height: 1500.0,
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryBackground,
                ),
                child: Align(
                  alignment: const AlignmentDirectional(0.0, -1.0),
                  child: Text(
                    'ROUND 3: HR Interview\n\nThis is the most important round of the interview process. During this round, many in-tenders are rejected. The goal is to maintain a pleasant and confident demeanor. Interviews can be long and tedious, so remember to smile!\n\nDuring the HR phase, the interview panel will ask you questions about your personality, family background, education, interests, internships, work experience (if applicable), and other topics. Make preparations to answer questions on internships, projects, volunteerism, and extracurricular activities mentioned in your CV. There can be questions related to the company - what are the products/services the company offers, what are its core values, when it was formed, its organizational structure, and so on.\n\nYou can never be too prepared when it comes to HR interview questions and responses. The greatest thing you can do is develop a list of the most popular HR interview questions and practice answering them. You should have the answers to these questions at your fingertips. Another crucial thing to keep in mind while going for an interview is to look and behave confidently. Keep in mind that you should not lie or be overconfident. Having excellent body language can make all the difference.\n\nCognizant Company HR  interview questions For Freshers and Experienced-\n\nTell me something about yourself. (Start with your academics, projects, achievements, other curriculum activities, and your strengths if you are a beginner. Also, tell them about your hobbies, background, and so on. If you\'re an experienced professional, start with your present position, achievements, previous work history, and then academic and personal information.)\nAre you willing to relocate to different parts of India?\nWhat are your strengths?\nWhy should we hire you?\nWhat are some of the characteristics of this profession that you enjoy?\nDescribe your Final Year Project. What new ideas did you bring to the table for this project?\nWhy are you looking for a job change? (If you\'re an experienced professional seeking a change, this is a common question. The easiest method to respond to this question is to state that you are leaving your current work in order to advance your career. Make sure you don\'t criticize or speak poorly about the company where you now work.)\nWhat is your expected salary? (This is a difficult question to answer. It is generally asked from experienced employees. You may inquire about the company\'s standard raise for employees.)',
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Readex Pro',
                          letterSpacing: 0.0,
                        ),
                  ),
                ),
              ),
            ].divide(const SizedBox(height: 12.0)),
          ),
        ),
      ),
    );
  }
}
