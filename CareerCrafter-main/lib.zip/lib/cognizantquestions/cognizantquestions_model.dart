import '/flutter_flow/flutter_flow_util.dart';
import 'cognizantquestions_widget.dart' show CognizantquestionsWidget;
import 'package:flutter/material.dart';

class CognizantquestionsModel
    extends FlutterFlowModel<CognizantquestionsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
