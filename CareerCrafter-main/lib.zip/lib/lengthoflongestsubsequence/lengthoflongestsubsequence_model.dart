import '/flutter_flow/flutter_flow_util.dart';
import 'lengthoflongestsubsequence_widget.dart'
    show LengthoflongestsubsequenceWidget;
import 'package:flutter/material.dart';

class LengthoflongestsubsequenceModel
    extends FlutterFlowModel<LengthoflongestsubsequenceWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
