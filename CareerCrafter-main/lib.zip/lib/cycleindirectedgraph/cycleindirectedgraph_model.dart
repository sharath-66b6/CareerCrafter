import '/flutter_flow/flutter_flow_util.dart';
import 'cycleindirectedgraph_widget.dart' show CycleindirectedgraphWidget;
import 'package:flutter/material.dart';

class CycleindirectedgraphModel
    extends FlutterFlowModel<CycleindirectedgraphWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
