import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'cycleindirectedgraph_model.dart';
export 'cycleindirectedgraph_model.dart';

class CycleindirectedgraphWidget extends StatefulWidget {
  const CycleindirectedgraphWidget({super.key});

  @override
  State<CycleindirectedgraphWidget> createState() =>
      _CycleindirectedgraphWidgetState();
}

class _CycleindirectedgraphWidgetState
    extends State<CycleindirectedgraphWidget> {
  late CycleindirectedgraphModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CycleindirectedgraphModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Cycle in Directed Graph',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 3500.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nGiven an directed graph having A nodes. A matrix B of size M x 2 is given which represents the M edges such that there is a edge directed from node B[i][0] to node B[i][1].\n\nFind whether the graph contains a cycle or not, return 1 if cycle is present else return 0.\n\nNOTE:\n\nThe cycle must contain atleast two nodes.\nThere are no self-loops in the graph.\nThere are no multiple edges between two nodes.\nThe graph may or may not be connected.\nNodes are numbered from 1 to A.\nYour solution will run on multiple test cases. If you are using global variables make sure to clear them.\n\n\nProblem Constraints\n2 <= A <= 105\n\n1 <= M <= min(200000,A(A-1))\n\n1 <= B[i][0], B[i][1] <= A\n\n\n\nInput Format\nThe first argument given is an integer A representing the number of nodes in the graph.\n\nThe second argument given a matrix B of size M x 2 which represents the M edges such that there is a edge directed from node B[i][0] to node B[i][1].\n\n\n\nOutput Format\nReturn 1 if cycle is present else return 0.\n\n\n\nExample Input\nInput 1:\n\n A = 5\n B = [  [1, 2] \n        [4, 1] \n        [2, 4] \n        [3, 4] \n        [5, 2] \n        [1, 3] ]\nInput 2:\n\n A = 5\n B = [  [1, 2]\n        [2, 3] \n        [3, 4] \n        [4, 5] ]\n\n\nExample Output\nOutput 1:\n\n 1\nOutput 2:\n\n 0\n\n\nExample Explanation*\nExplanation 1:\n\n The given graph contain cycle 1 -> 3 -> 4 -> 1 or the cycle 1 -> 2 -> 4 -> 1\nExplanation 2:\n\n The given graph doesn\'t contain any cycle.\n\n\n\n\nAnswer :-\n/**\n * @input A : Integer\n * @input B : 2D integer array \n * @input n21 : Integer array\'s ( B ) rows\n * @input n22 : Integer array\'s ( B ) columns\n * \n * @Output Integer\n */\n \n int visit[200000];\n \n \n struct node\n {\n     int dst;\n     struct node * next;\n };\n \n \n struct node * CreateNode (int dst)\n {\n    struct node * tmp = (struct node *) calloc (1, sizeof(struct node));\n    tmp->dst = dst;\n    return tmp;\n }\n \n int find_cycle(struct node ** Graph, int src)\n {\n\n    if (visit[src])\n        return 0;\n        \n    struct node * cnode = Graph[src];\n    \n    int ret = 1;\n\n    \n    visit[src] = 1;\n    while (cnode)\n    {\n        ret = find_cycle (Graph, cnode->dst);\n        \n        if (!ret)\n            break;\n        \n        cnode = cnode->next;\n    }\n    visit[src] = 0;\n         \n    return ret;     \n }\n \n void insert_node (struct node ** Graph, int src, int dst)\n {\n    struct node * tmp = CreateNode(dst);\n    \n    if (Graph[src])\n    {\n        tmp->next = Graph[src];\n    }\n    \n    Graph[src] = tmp;\n }\n \nint solve(int A, int** B, int n21, int n22) {\n    \n    \n    int i=0;\n    \n    struct node **Graph;\n    \n    \n    \n    for (i=0; i<=A; i++)\n        visit[i] = 0;\n        \n    Graph = (struct node **) calloc (A+2, sizeof(struct node *));    \n    \n    for (i=0; i<n21; i++)\n    {\n        int src = B[i][0];\n        int dst = B[i][1];\n        \n        insert_node (Graph, src, dst);\n        \n    }\n    \n    for (i=0; i<A; i++)\n    {\n        if (!find_cycle (Graph, i))\n            return 1;\n    }\n\n    return 0;\n    \n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=6zVWOfwT0Dw&pp=ygUkaW50ZXJ2aWV3Yml0IGN5Y2xlIGluIGRpcmVjdGVkIGdyYXBo',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
