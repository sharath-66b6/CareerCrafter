import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'equal_model.dart';
export 'equal_model.dart';

class EqualWidget extends StatefulWidget {
  const EqualWidget({super.key});

  @override
  State<EqualWidget> createState() => _EqualWidgetState();
}

class _EqualWidgetState extends State<EqualWidget> {
  late EqualModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => EqualModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).primary,
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30.0,
            borderWidth: 1.0,
            buttonSize: 60.0,
            icon: const Icon(
              Icons.arrow_back_rounded,
              color: Colors.white,
              size: 30.0,
            ),
            onPressed: () async {
              context.pop();
            },
          ),
          title: Text(
            'Equal',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: 'Outfit',
                  color: Colors.white,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                ),
          ),
          actions: const [],
          centerTitle: true,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: ListView(
            padding: const EdgeInsets.symmetric(vertical: 12.0),
            scrollDirection: Axis.vertical,
            children: [
              Container(
                width: 100.0,
                height: 2200.0,
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryBackground,
                ),
                child: Align(
                  alignment: const AlignmentDirectional(0.0, -1.0),
                  child: Text(
                    'Problem Description\n \n \n\nGiven an array A of N integers, find the index of values that satisfy P + Q = R + S, where P, Q, R & S are integers values in the array\n\nExpected time complexity O(N2)\n\nNOTE:\n1) Return the indices A1 B1 C1 D1, so that \n  A[A1] + A[B1] = A[C1] + A[D1]\n  A1 < B1, C1 < D1\n  A1 < C1, B1 != D1, B1 != C1 \n2) If there are more than one solutions,\n   then return the tuple of values which are lexicographical smallest. \n\nAssume we have two solutions\nS1 : A1 B1 C1 D1 ( these are values of indices in the array )\nS2 : A2 B2 C2 D2\n\nS1 is lexicographically smaller than S2 if:\n  A1 < A2 OR\n  A1 = A2 AND B1 < B2 OR\n  A1 = A2 AND B1 = B2 AND C1 < C2 OR \n  A1 = A2 AND B1 = B2 AND C1 = C2 AND D1 < D2\nIf no solution is possible, return an empty list.\n\n\nProblem Constraints\n1 <= N <= 1000\n\n0 <= A[i] <= 1000\n\n\n\nInput Format\nFirst and only argument is an integer array A of length N.\n\n\n\nOutput Format\nReturn an array of size four which contains indices of values P, Q, R, and S.\n\n\n\nExample Input\nInput 1:\n\n A = [3, 4, 7, 1, 2, 9, 8]\nInput 2:\n\n A = [2, 5, 1, 6]\n\n\nExample Output\nOutput 1:\n\n [0, 2, 3, 5]\nOutput 2:\n\n [0, 1, 2, 3]\n\n\nExample Explanation\nExplanation 1:\n\n A[0] + A[2] = A[3] + A[5]\n Note: indexes returned should be 0-based.\nExplanation 2:\n\n A[0] + A[1] = A[2] + A[3]\n\n\n\nAnswer :-\n/**\n * @input A : Integer array\n * @input n1 : Integer array\'s ( A ) length\n * \n * @Output Integer array. You need to malloc memory, and fill the length in len1\n */\nint* equal(int* a, int n, int *len) {\n    int i,j,k,l ;\n    int * res = malloc(sizeof(int)*4);\n    for(i=0;i<n;i++)\n    {\n        for(j=i+1;j<n;j++)\n        {\n            for(k=i+1;k<n;k++)\n            {\n                if (k==j)\n                continue ;\n                for(l=k+1;l<n;l++)\n                {\n                    if (l==j)\n                    continue ;\n                    if ((a[i]+a[j])==(a[k]+a[l]))\n                    {\n                        res[0] = i;\n                        res[1] = j ;\n                        res[2] = k ;\n                        res[3] = l;\n                        *len =4 ;\n                        return res ;\n                    }\n                }\n            }\n        }\n    }\n    *len = 0 ;\n    return NULL ;\n}\n',
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Readex Pro',
                          letterSpacing: 0.0,
                        ),
                  ),
                ),
              ),
            ].divide(const SizedBox(height: 12.0)),
          ),
        ),
      ),
    );
  }
}
