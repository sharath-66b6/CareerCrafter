import '/flutter_flow/flutter_flow_util.dart';
import 'equal_widget.dart' show EqualWidget;
import 'package:flutter/material.dart';

class EqualModel extends FlutterFlowModel<EqualWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
