import '/flutter_flow/flutter_flow_util.dart';
import 'increasingpathinmatrix_widget.dart' show IncreasingpathinmatrixWidget;
import 'package:flutter/material.dart';

class IncreasingpathinmatrixModel
    extends FlutterFlowModel<IncreasingpathinmatrixWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
