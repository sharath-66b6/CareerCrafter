import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'increasingpathinmatrix_model.dart';
export 'increasingpathinmatrix_model.dart';

class IncreasingpathinmatrixWidget extends StatefulWidget {
  const IncreasingpathinmatrixWidget({super.key});

  @override
  State<IncreasingpathinmatrixWidget> createState() =>
      _IncreasingpathinmatrixWidgetState();
}

class _IncreasingpathinmatrixWidgetState
    extends State<IncreasingpathinmatrixWidget> {
  late IncreasingpathinmatrixModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => IncreasingpathinmatrixModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Increasing Path in Matrix',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven a 2D integer matrix A of size N x M.\n\nFrom A[i][j] you can move to A[i+1][j], if A[i+1][j] > A[i][j], or can move to A[i][j+1] if A[i][j+1] > A[i][j].\n\nThe task is to find and output the longest path length possible if we start from the cell (0, 0) and want to reach cell (N - 1, M - 1).\n\nNOTE:\n\nIf there doesn\'t exist a path return -1.\n\n\nProblem Constraints\n1 <= N, M <= 103\n\n1 <= A[i][j] <= 108\n\n\n\nInput Format\nFirst and only argument is an 2D integer matrix A of size N x M.\n\n\n\nOutput Format\nReturn a single integer denoting the length of longest path in the matrix if no such path exists return -1.\n\n\n\nExample Input\nInput 1:\n\n A = [  [1, 2]\n        [3, 4]\n     ]\nInput 2:\n\n A = [  [1, 2, 3, 4]\n        [2, 2, 3, 4]\n        [3, 2, 3, 4]\n        [4, 5, 6, 7]\n     ]\n\n\nExample Output\nOutput 1:\n\n 3\nOutput 2:\n\n 7\n\n\nExample Explanation\nExplanation 1:\n\n Longest path is either 1 2 4 or 1 3 4.\nExplanation 2:\n\n Longest path is 1 2 3 4 5 6 7.\n\n\n\n\n\n\nAnswer :-\n/**\n * @input A : 2D integer array \n * @input n11 : Integer array\'s ( A ) rows\n * @input n12 : Integer array\'s ( A ) columns\n * \n * @Output Integer\n */\n int max1(int a1,int b)\n {\n     if(a1<b)\n     return b;\n     else\n     return a1;\n }\nint solve(int** a, int m, int n) {\n    int i=0,j=0,f=0,max=-1;\n    int dp[m][n];\n    dp[0][0]=1;\n    for(i=1;i<m;i++)\n    {if(a[i][0]>a[i-1][0]&&dp[i-1][0]!=0)\n     dp[i][0]=dp[i-1][0]+1;\n     else\n     dp[i][0]=0;\n    }\n     for(i=1;i<n;i++)\n    {if(a[0][i]>a[0][i-1]&&dp[0][i-1]!=0)\n     dp[0][i]=dp[0][i-1]+1;\n     else\n     dp[0][i]=0;\n     }\n     for(i=1;i<m;i++)\n     for(j=1;j<n;j++)\n     {\n         if(a[i][j]>a[i-1][j]&&a[i][j]>a[i][j-1]&&(dp[i][j-1]||dp[i-1][j]))\n           dp[i][j]=max1(dp[i-1][j],dp[i][j-1])+1;\n           else if(a[i][j]>a[i-1][j]&&dp[i-1][j]!=0)\n           dp[i][j]=dp[i-1][j]+1;\n           else if(a[i][j]>a[i][j-1]&&dp[i][j-1]!=0)\n           dp[i][j]=dp[i][j-1]+1;\n           else\n           dp[i][j]=0;\n     }\n    if(dp[m-1][n-1]==0)\n    return -1;\n    else\n    return dp[m-1][n-1];\n    \n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=wCc_nd-GiEc&pp=ygUmaW50ZXJ2aWV3Yml0IGluY3JlYXNpbmcgcGF0aCBpbiBtYXRyaXg%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
