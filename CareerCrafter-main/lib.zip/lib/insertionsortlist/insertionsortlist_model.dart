import '/flutter_flow/flutter_flow_util.dart';
import 'insertionsortlist_widget.dart' show InsertionsortlistWidget;
import 'package:flutter/material.dart';

class InsertionsortlistModel extends FlutterFlowModel<InsertionsortlistWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
