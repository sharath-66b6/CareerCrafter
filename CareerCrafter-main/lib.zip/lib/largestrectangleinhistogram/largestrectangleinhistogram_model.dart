import '/flutter_flow/flutter_flow_util.dart';
import 'largestrectangleinhistogram_widget.dart'
    show LargestrectangleinhistogramWidget;
import 'package:flutter/material.dart';

class LargestrectangleinhistogramModel
    extends FlutterFlowModel<LargestrectangleinhistogramWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
