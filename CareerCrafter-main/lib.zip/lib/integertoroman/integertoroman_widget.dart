import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'integertoroman_model.dart';
export 'integertoroman_model.dart';

class IntegertoromanWidget extends StatefulWidget {
  const IntegertoromanWidget({super.key});

  @override
  State<IntegertoromanWidget> createState() => _IntegertoromanWidgetState();
}

class _IntegertoromanWidgetState extends State<IntegertoromanWidget> {
  late IntegertoromanModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => IntegertoromanModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Integer To Roman',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1900.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \nAnother question which belongs to the category of questions which are intentionally stated vaguely. \n\nExpectation is that you will ask for correct clarification or you will state your assumptions before you start coding.\n\nGiven an integer A, convert it to a roman numeral, and return a string corresponding to its roman numeral version\n\nNote : This question has a lot of scope of clarification from the interviewer. Please take a moment to think of all the needed clarifications and see the expected response using “See Expected Output”\n\nFor the purpose of this question, https://projecteuler.net/about=roman_numerals has very detailed explanations.\n\n\n\n\nInput Format\n\nThe only argument given is integer A.\nOutput Format\n\nReturn a string denoting roman numeral version of A.\nConstraints\n\n1 <= A <= 3999\nFor Example\n\nInput 1:\n    A = 5\nOutput 1:\n    \"V\"\n\nInput 2:\n    A = 14\nOutput 2:\n    \"XIV\"\n\n\n\nAnswer :- \n/**\n * @input A : Integer\n * \n * @Output string. Make sure the string ends with null character\n */\nchar* intToRoman(int A) {\n    \n    char *h[] = {\"\", \"C\", \"CC\", \"CCC\", \"CD\", \"D\", \"DC\", \"DCC\", \"DCCC\", \"CM\"};\n    char *t[] = {\"\", \"X\", \"XX\", \"XXX\", \"XL\", \"L\", \"LX\", \"LXX\", \"LXXX\", \"XC\"};\n    char *o[] = {\"\", \"I\", \"II\", \"III\", \"IV\", \"V\", \"VI\", \"VII\", \"VIII\", \"IX\"};\n    int s[10]={0,1,2,3,2,1,2,3,4,2};\n    \n    char *res = (char *)malloc(100*sizeof(char));\n    char *send = res;\n    int i=0;\n    \n  if(A<10) {\n       strcpy(res,o[A]);\n       res+=s[A];\n       *res=\'\\0\';\n       return send;\n    }\n \n    while(A>=1000) {\n        *res++ = \'M\';\n        A-=1000;\n    }\n    \n    if(A>=100) {\n    i=A/100;\n    strcpy(res,h[i]);\n    res+=s[i]; \n    A=A%100;\n    }\n    if(A>=10) {\n    i=A/10;\n    strcpy(res,t[i]);\n    res+=s[i]; \n    A=A%10;\n    }\n    strcpy(res,o[A]);\n    res+=s[A];\n    //printf(\"\\n%d\\n\",s[i]);\n   *res=\'\\0\';\n    \n    return send;\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=Rsq1ObYg6ak&pp=ygUdaW50ZXJ2aWV3Yml0IGludGVnZXIgdG8gcm9tb24%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
