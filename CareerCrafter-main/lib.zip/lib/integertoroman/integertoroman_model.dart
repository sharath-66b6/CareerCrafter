import '/flutter_flow/flutter_flow_util.dart';
import 'integertoroman_widget.dart' show IntegertoromanWidget;
import 'package:flutter/material.dart';

class IntegertoromanModel extends FlutterFlowModel<IntegertoromanWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
