import '/flutter_flow/flutter_flow_util.dart';
import 'maxdepthofbinarytree_widget.dart' show MaxdepthofbinarytreeWidget;
import 'package:flutter/material.dart';

class MaxdepthofbinarytreeModel
    extends FlutterFlowModel<MaxdepthofbinarytreeWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
