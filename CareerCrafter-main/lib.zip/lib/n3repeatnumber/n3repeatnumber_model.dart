import '/flutter_flow/flutter_flow_util.dart';
import 'n3repeatnumber_widget.dart' show N3repeatnumberWidget;
import 'package:flutter/material.dart';

class N3repeatnumberModel extends FlutterFlowModel<N3repeatnumberWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
