import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'n3repeatnumber_model.dart';
export 'n3repeatnumber_model.dart';

class N3repeatnumberWidget extends StatefulWidget {
  const N3repeatnumberWidget({super.key});

  @override
  State<N3repeatnumberWidget> createState() => _N3repeatnumberWidgetState();
}

class _N3repeatnumberWidgetState extends State<N3repeatnumberWidget> {
  late N3repeatnumberModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => N3repeatnumberModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'N/3 Repeat Number',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1400.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nYou\'re given a read-only array of N integers. Find out if any integer occurs more than N/3 times in the array in linear time and constant additional space.\nIf so, return the integer. If not, return -1.\n\nIf there are multiple solutions, return any one.\n\n\n\nProblem Constraints\n1 <= N <= 7*105\n1 <= A[i] <= 109\n\n\nInput Format\nThe only argument is an integer array A.\n\n\nOutput Format\nReturn an integer.\n\n\nExample Input\n[1 2 3 1 1]\n\n\nExample Output\n1\n\n\nExample Explanation\n1 occurs 3 times which is more than 5/3 times.\n\n\nAnswer :-\n/**\n * @input A : Read only ( DON\'T MODIFY ) Integer array\n * @input n1 : Integer array\'s ( A ) length\n * \n * @Output Integer\n */\nstruct record{\n  int e;\n  int c;\n};\nint repeatedNumber(const int* A, int n1) {\n    struct record rec[2];\n    int i,j,ac;\n    rec[0].c=0; rec[1].c=0;\n    for(i=0;i<n1;i++){\n        if(rec[0].c!=0 && A[i]==rec[0].e) rec[0].c++;\n        else if(rec[1].c!=0 && A[i]==rec[1].e) rec[1].c++;\n        else if(rec[0].c==0) { rec[0].c=1; rec[0].e=A[i]; }\n        else if(rec[1].c==0) { rec[1].c=1; rec[1].e=A[i]; }\n        else { rec[0].c--; rec[1].c--; }\n    }\n    for(i=0;i<2;i++){\n        ac=0;\n        for(j=0;j<n1;j++){\n            if(A[j]==rec[i].e)\n                ac++;\n        }\n        if(ac > n1/3)\n            return rec[i].e;\n    }\n    return -1;\n}',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=3lh0j3YRH50&pp=ygUhaW50ZXJ2aWV3Yml0IG4vMyByZXBlYWRlZCBudW1iZXJz',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
