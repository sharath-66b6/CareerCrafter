import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'distribtecandy_model.dart';
export 'distribtecandy_model.dart';

class DistribtecandyWidget extends StatefulWidget {
  const DistribtecandyWidget({super.key});

  @override
  State<DistribtecandyWidget> createState() => _DistribtecandyWidgetState();
}

class _DistribtecandyWidgetState extends State<DistribtecandyWidget> {
  late DistribtecandyModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => DistribtecandyModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Distribute Candy',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1800.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nN children are standing in a line. Each child is assigned a rating value.\n\nYou are giving candies to these children subjected to the following requirements:\n\nEach child must have at least one candy.\nChildren with a higher rating get more candies than their neighbors.\nWhat is the minimum number of candies you must give?\n\n\n\nProblem Constraints\n1 <= N <= 105\n\n-109 <= A[i] <= 109\n\n\n\n\nInput Format\nThe first and only argument is an integer array A representing the rating of children.\n\n\n\nOutput Format\nReturn an integer representing the minimum candies to be given.\n\n\n\nExample Input\nInput 1:\n\n A = [1, 2]\nInput 2:\n\n A = [1, 5, 2, 1]\n\n\nExample Output\nOutput 1:\n\n 3\nOutput 2:\n\n 7\n\n\nExample Explanation\nExplanation 1:\n\n The candidate with 1 rating gets 1 candy and candidate with rating 2 cannot get 1 candy as 1 is its neighbor. \n So rating 2 candidate gets 2 candies. In total, 2 + 1 = 3 candies need to be given out.\nExplanation 2:\n\n Candies given = [1, 3, 2, 1]\n\n\n\n\nAnswer :-\n/**\n * @input ratings : Integer array\n * @input n1 : Integer array\'s ( A ) length\n * \n * @Output Integer\n */\nint candy(int* ratings, int n1) {\n    int candy[n1],i,sum=0;\n    for(i=0;i<n1;i++)\n        candy[i]=1;\n    for(i=1;i<n1;i++)\n        if(ratings[i]>ratings[i-1])  \n            candy[i]=candy[i-1]+1;\n    for(i=n1-1;i>0;i--)\n        if(ratings[i-1]>ratings[i] && candy[i-1]<=candy[i])\n            candy[i-1]=candy[i]+1;\n    for(i=0;i<n1;i++)\n        sum+=candy[i];\n    return sum;\n    \n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=PzBYQA6FshA&pp=ygUdaW50ZXJ2aWV3Yml0IGRpc3RyaWJ1dGUgY2FuZHk%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
