import '/flutter_flow/flutter_flow_util.dart';
import 'distribtecandy_widget.dart' show DistribtecandyWidget;
import 'package:flutter/material.dart';

class DistribtecandyModel extends FlutterFlowModel<DistribtecandyWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
