import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'commutableislands_model.dart';
export 'commutableislands_model.dart';

class CommutableislandsWidget extends StatefulWidget {
  const CommutableislandsWidget({super.key});

  @override
  State<CommutableislandsWidget> createState() =>
      _CommutableislandsWidgetState();
}

class _CommutableislandsWidgetState extends State<CommutableislandsWidget> {
  late CommutableislandsModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CommutableislandsModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Commutable Islands',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2600.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'There are A islands and there are M bridges connecting them. Each bridge has some cost attached to it.\n\nWe need to find bridges with minimal cost such that all islands are connected.\n\nIt is guaranteed that input data will contain at least one possible scenario in which all islands are connected with each other.\n\nInput Format:\n\nThe first argument contains an integer, A, representing the number of islands.\nThe second argument contains an 2-d integer matrix, B, of size M x 3:\n    => Island B[i][0] and B[i][1] are connected using a bridge of cost B[i][2].\nOutput Format:\n\nReturn an integer representing the minimal cost required.\nConstraints:\n\n1 <= A, M <= 6e4\n1 <= B[i][0], B[i][1] <= A\n1 <= B[i][2] <= 1e3\nExamples:\n\nInput 1:\n    A = 4\n    B = [   [1, 2, 1]\n            [2, 3, 4]\n            [1, 4, 3]\n            [4, 3, 2]\n            [1, 3, 10]  ]\n\nOutput 1:\n    6\n\nExplanation 1:\n    We can choose bridges (1, 2, 1), (1, 4, 3) and (4, 3, 2), where the total cost incurred will be (1 + 3 + 2) = 6.\n\nInput 2:\n    A = 4\n    B = [   [1, 2, 1]\n            [2, 3, 2]\n            [3, 4, 4]\n            [1, 4, 3]   ]\n\nOutput 2:\n    6\n\nExplanation 2:\n    We can choose bridges (1, 2, 1), (2, 3, 2) and (1, 4, 3), where the total cost incurred will be (1 + 2 + 3) = 6.\n\n\nAnswer :-\n/**\n * @input A : Integer\n * @input B : 2D integer array \n * @input n21 : Integer array\'s ( B ) rows\n * @input n22 : Integer array\'s ( B ) columns\n * \n * @Output Integer\n */\n typedef struct node{\n     int x,y;\n     int cost;\n }node;\nnode graph[100005];\nint parent[100005],rank[100005];\nint cmp(const void * a, const void * b)\n{\n\n  node *orderA = (node *)a;\n  node *orderB = (node *)b;\n  return ( orderA->cost - orderB->cost );\n}\n\nint find(int x)\n{\n    if(parent[x]!=x)\n\t    parent[x]=find(parent[x]);\n    return parent[x];\n}\nvoid union_set(int x,int y)\n{\n    int xroot=find(x);\n    int yroot=find(y);\n    //Attach smaller rank tree under higher rank tree\n    if(rank[xroot]>rank[yroot])\n\t    parent[yroot]=xroot;\n    else if(rank[yroot]>rank[xroot])\n\t    parent[xroot]=yroot;\n    else\n    {\n\t    parent[xroot]=yroot;\n\t    rank[xroot]++;\n    }\n}\nint kruskal(int R)\n{\n    \n    int ret = 0;\n    qsort(graph,R,sizeof(node),cmp);\n    int i;\n    for(i=0;i<R;i++)\n    {\n\t    int x=find(graph[i].x);\n\t    int y=find(graph[i].y);\n\t    if(x!=y)\n\t    {\n\t        ret += graph[i].cost;\n\t        union_set(x,y);\n\t    } \n    }\n    return ret;\n}\nint solve(int A, int** B, int n21, int n22) {\n    int R = n21, C = n22;\n    int i;\n    for(i=1;i<=A;i++)\n    {\n        parent[i] = i;\n        rank[i] = 0;\n    }\n    for(i=0;i<R;i++)\n    {\n        int u = B[i][0], v = B[i][1], cost = B[i][2];\n        graph[i].x = u, graph[i].y = v, graph[i].cost = cost;\n    }\n    return kruskal(R);\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=nYkglR3Dtwk&pp=ygUfaW50ZXJ2aWV3Yml0IGNvbW11dGFibGUgaXNsYW5kcw%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
