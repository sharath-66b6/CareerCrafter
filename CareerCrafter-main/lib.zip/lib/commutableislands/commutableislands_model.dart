import '/flutter_flow/flutter_flow_util.dart';
import 'commutableislands_widget.dart' show CommutableislandsWidget;
import 'package:flutter/material.dart';

class CommutableislandsModel extends FlutterFlowModel<CommutableislandsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
