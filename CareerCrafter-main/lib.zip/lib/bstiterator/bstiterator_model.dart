import '/flutter_flow/flutter_flow_util.dart';
import 'bstiterator_widget.dart' show BstiteratorWidget;
import 'package:flutter/material.dart';

class BstiteratorModel extends FlutterFlowModel<BstiteratorWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
