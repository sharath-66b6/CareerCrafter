import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'bstiterator_model.dart';
export 'bstiterator_model.dart';

class BstiteratorWidget extends StatefulWidget {
  const BstiteratorWidget({super.key});

  @override
  State<BstiteratorWidget> createState() => _BstiteratorWidgetState();
}

class _BstiteratorWidgetState extends State<BstiteratorWidget> {
  late BstiteratorModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => BstiteratorModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'BST Iterator',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1500.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nImplement an iterator over a binary search tree (BST). Your iterator will be initialized with the root node of a BST.\n\nThe first call to next() will return the smallest number in BST. Calling next() again will return the next smallest number in the BST, and so on.\n\nNote: next() and hasNext() should run in average O(1) time and uses O(h) memory, where h is the height of the tree.\n\nTry to optimize the additional space complexity apart from the amortized time complexity.\n\n\n\n\n\nAnswer :-\n/**\n * Definition for binary tree\n * struct TreeNode {\n *     int val;\n *     struct TreeNode *left;\n *     struct TreeNode *right;\n * };\n * \n * typedef struct TreeNode treenode;\n * \n * treenode* treenode_new(int val) {\n *     treenode* node = (treenode *) malloc(sizeof(treenode));\n *     node->val = val;\n *     node->left = NULL;\n *     node->right = NULL;\n *     return node;\n * }\n */\ntreenode *st[10005];\nint to=0;\nvoid init(treenode* root) {\n     while (root != NULL) {  \n           st[to++]=root;  \n            root = root->left;  \n        }  \n\n}\n\n/** @return 0 / 1 based on whether we have a next smallest number */\nint hasNext() {\nreturn (to!=0);  \n}\n\n/** @return the next smallest number */\nint next() {\n    struct TreeNode* current = st[to-1];  \n    struct    TreeNode* return_current = current;  \n        to--;  \n        current = current->right;  \n        while(current != NULL) {  \n            st[to++]=current;  \n            current = current->left;  \n        }  \n        return return_current->val;  \n\n}\n\n/**\n * Your BSTIterator will be called like this:\n * init(root);\n * while(hasNext()) printf(\"%d \", next());\n */\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=4L5seG1d2dA&pp=ygUZaW50ZXJ2aWV3Yml0IGJzdCBpdGVyYXRvcg%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
