import '/flutter_flow/flutter_flow_util.dart';
import 'longestpalindromesubstring_widget.dart'
    show LongestpalindromesubstringWidget;
import 'package:flutter/material.dart';

class LongestpalindromesubstringModel
    extends FlutterFlowModel<LongestpalindromesubstringWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
