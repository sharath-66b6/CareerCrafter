import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'longestpalindromesubstring_model.dart';
export 'longestpalindromesubstring_model.dart';

class LongestpalindromesubstringWidget extends StatefulWidget {
  const LongestpalindromesubstringWidget({super.key});

  @override
  State<LongestpalindromesubstringWidget> createState() =>
      _LongestpalindromesubstringWidgetState();
}

class _LongestpalindromesubstringWidgetState
    extends State<LongestpalindromesubstringWidget> {
  late LongestpalindromesubstringModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => LongestpalindromesubstringModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Longest Palindromic Substring',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1800.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven a string A of size N, find and return the longest palindromic substring in A.\n\nSubstring of string A is A[i...j] where 0 <= i <= j < len(A)\n\nPalindrome string:\n\nA string which reads the same backwards. More formally, A is palindrome if reverse(A) = A.\n\nIncase of conflict, return the substring which occurs first ( with the least starting index).\n\n\n\nProblem Constraints\n1 <= N <= 6000 \n\n\n\nInput Format\nFirst and only argument is a string A.\n\n\n\nOutput Format\nReturn a string denoting the longest palindromic substring of string A.\n\n\n\nExample Input\nA = \"aaaabaaa\"\n\n\nExample Output\n\"aaabaaa\"\n\n\nExample Explanation\nWe can see that longest palindromic substring is of length 7 and the string is \"aaabaaa\".\n\n\n\nAnswer:-\nchar* longestPalindrome(char* str) {\n    int maxLength = 1;\n    int start = 0;\n    int len = strlen(str);\n    int low, high, i, k;\n    for (i = 1; i < len; ++i) \n    {\n        low = i - 1;\n        high = i;\n        while (low >= 0 && high < len && str[low] == str[high]) \n        {\n            if (high - low + 1 > maxLength) \n            {\n                start = low;\n                maxLength = high - low + 1;\n            }\n            --low;\n            ++high;\n        }\n        low = i - 1;\n        high = i + 1;\n        while (low >= 0 && high < len && str[low] == str[high]) \n        {\n            if (high - low + 1 > maxLength) \n            {\n                start = low;\n                maxLength = high - low + 1;\n            }\n            --low;\n            ++high;\n        }\n    }\n    char * ans = (char*)malloc(sizeof(char) * (maxLength + 2));;\n    k = 0;\n    for (i = start; i < start + maxLength; i++) {\n        ans[k++] = str[i];\n    }\n    ans[k] = \'\\0\';\n    return ans;\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=COu84CHGuM0&pp=ygUpaW50ZXJ2aWV3Yml0IGxvbmdlc3QgcGFsaW5kcm9tZSBzdWJzdHJpbmc%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
