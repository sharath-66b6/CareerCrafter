import '/flutter_flow/flutter_flow_util.dart';
import 'boyorgirlparadox_widget.dart' show BoyorgirlparadoxWidget;
import 'package:flutter/material.dart';

class BoyorgirlparadoxModel extends FlutterFlowModel<BoyorgirlparadoxWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
