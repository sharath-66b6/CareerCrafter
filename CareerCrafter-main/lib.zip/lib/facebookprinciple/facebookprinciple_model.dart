import '/flutter_flow/flutter_flow_util.dart';
import 'facebookprinciple_widget.dart' show FacebookprincipleWidget;
import 'package:flutter/material.dart';

class FacebookprincipleModel extends FlutterFlowModel<FacebookprincipleWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
