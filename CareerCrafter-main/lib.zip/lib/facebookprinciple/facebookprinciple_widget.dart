import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'facebookprinciple_model.dart';
export 'facebookprinciple_model.dart';

class FacebookprincipleWidget extends StatefulWidget {
  const FacebookprincipleWidget({super.key});

  @override
  State<FacebookprincipleWidget> createState() =>
      _FacebookprincipleWidgetState();
}

class _FacebookprincipleWidgetState extends State<FacebookprincipleWidget> {
  late FacebookprincipleModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => FacebookprincipleModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).primary,
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30.0,
            borderWidth: 1.0,
            buttonSize: 60.0,
            icon: const Icon(
              Icons.arrow_back_rounded,
              color: Colors.white,
              size: 30.0,
            ),
            onPressed: () async {
              context.pop();
            },
          ),
          title: Text(
            'Facebook Principles',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: 'Outfit',
                  color: Colors.white,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                ),
          ),
          actions: const [],
          centerTitle: true,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: ListView(
            padding: const EdgeInsets.symmetric(vertical: 12.0),
            scrollDirection: Axis.vertical,
            children: [
              Container(
                width: 100.0,
                height: 1200.0,
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryBackground,
                ),
                child: Align(
                  alignment: const AlignmentDirectional(0.0, -1.0),
                  child: Text(
                    'Overview\nWebsite\nmeta.com\nFounded\n2004\n# Employees\n10K+\nAbout Meta\nMeta builds technologies that help people connect, find communities, and grow businesses. When Facebook launched in 2004, it changed the way people connect. Apps like Messenger, Instagram, and WhatsApp further empowered billions around the world. Now, Meta is moving beyond 2D screens toward immersive experiences like augmented and virtual reality to help build the next evolution in social technology.\n\nMission and Vision of Meta\nMission\nBring people together.\n\nVision\nHelp bring the metaverse to life.\n\nValues and Principles of Meta\nThe core values at Meta are:\n\nBe Bold\nBuilding great things means taking risks. We have a saying: \'The riskiest thing is to take no risks.\' In a world that\'s changing quickly, you\'re guaranteed to fail if you don\'t take any risks.\n\nFocus on Impact\nTo make the most impact, we need to solve the most important problems. We expect Facebook employees to avoid wasting time on minor issues and focus on truly big challenges.\n\nMove Fast\nWe believe that it’s better to move fast and make mistakes than to move slowly and miss opportunities. Doing so enables us to build more things and learn faster.\n\nBe Open\nInformed people make better decisions and make a greater impact — so we work hard to ensure that everyone at Facebook can access as much information about the company as possible.\n\nBuild Social Value\nAt Facebook, we’re trying to bring the world closer together — not just grow our business. Our people focus on creating real value for the world — every day and in everything they do.',
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Readex Pro',
                          letterSpacing: 0.0,
                        ),
                  ),
                ),
              ),
            ].divide(const SizedBox(height: 12.0)),
          ),
        ),
      ),
    );
  }
}
