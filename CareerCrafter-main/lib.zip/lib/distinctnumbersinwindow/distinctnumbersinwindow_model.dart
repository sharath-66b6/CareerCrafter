import '/flutter_flow/flutter_flow_util.dart';
import 'distinctnumbersinwindow_widget.dart' show DistinctnumbersinwindowWidget;
import 'package:flutter/material.dart';

class DistinctnumbersinwindowModel
    extends FlutterFlowModel<DistinctnumbersinwindowWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
