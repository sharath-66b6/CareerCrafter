import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'distinctnumbersinwindow_model.dart';
export 'distinctnumbersinwindow_model.dart';

class DistinctnumbersinwindowWidget extends StatefulWidget {
  const DistinctnumbersinwindowWidget({super.key});

  @override
  State<DistinctnumbersinwindowWidget> createState() =>
      _DistinctnumbersinwindowWidgetState();
}

class _DistinctnumbersinwindowWidgetState
    extends State<DistinctnumbersinwindowWidget> {
  late DistinctnumbersinwindowModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => DistinctnumbersinwindowModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Distinct Numbers in Window',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 4000.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nYou are given an array of N integers, A1, A2 ,..., AN and an integer B. Return the of count of distinct numbers in all windows of size B.\n\nFormally, return an array of size N-B+1 where i\'th element in this array contains number of distinct elements in sequence Ai, Ai+1 ,..., Ai+B-1.\n\nNOTE:  if B > N, return an empty array.\n\n\n\nInput Format\nFirst argument is an integer array A\n\nSecond argument is an integer B.\n\n\n\nOutput Format\nReturn an integer array.\n\n\n\nExample Input\nInput 1:\n\n A = [1, 2, 1, 3, 4, 3]\n B = 3\nInput 2:\n\n A = [1, 1, 2, 2]\n B = 1\n\n\nExample Output\nOutput 1:\n\n [2, 3, 3, 2]\nOutput 2:\n\n [1, 1, 1, 1]\n\n\nExample Explanation\nExplanation 1:\n\n A=[1, 2, 1, 3, 4, 3] and B = 3\n All windows of size B are\n [1, 2, 1]\n [2, 1, 3]\n [1, 3, 4]\n [3, 4, 3]\n So, we return an array [2, 3, 3, 2].\nExplanation 2:\n\n Window size is 1, so the output array is [1, 1, 1, 1].\n\n\nAnswer :-\n/**\n * @input A : Integer array\n * @input n1 : Integer array\'s ( A ) length\n * @input B : Integer\n * \n * @Output Integer array. You need to malloc memory, and fill the length in len1\n */\ntypedef struct hashMap Map;\ntypedef struct List Node;\n\ntypedef struct List {\n        int key;\n        int value;\n        Node *next;\n} Node;\n\ntypedef struct hashMap {\n        int N;\n        Node **buckets;\n        void (*init)(Map *);\n        void (*add)(Map *, long long key, int value);\n        int (*find)(Map *, long long key, int *value, Node **);\n        int (*decrement)(Map *, long long key);\n} Map;\n\nint find(Map *map, long long key, int *value, Node **retnode)\n{\n        Node *node;\n        int N = map->N;\n        int hash;\n        hash = abs(key) % N;\n        node = map->buckets[hash];\n        while (node) {\n                if (node->key == key)  {\n                        if (value)\n                            *value = node->value;\n                        if (retnode)\n                            *retnode = node;\n                        return 1;\n                }\n                node = node->next;\n        }\n        return 0;\n}\n\nvoid add(Map *map, long long key, int value)\n{\n        Node *node;\n        int N = map->N;\n        int tmp;\n        int hash;\n\n        if (find(map, key, &tmp, &node) == 1) {\n                node->value = node->value + value;\n                return;\n        }\n\n        hash = abs(key) % N;\n\n        node = malloc(sizeof(Node));\n        node->key = key;\n        node->value = value;\n        node->next = map->buckets[hash];\n        map->buckets[hash] = node;\n}\n\nint decrement(Map *map, long long key)\n{\n     Node *node; Node *prev;\n        int N = map->N;\n        int hash;\n        hash = abs(key) % N;\n        node = map->buckets[hash];\n        prev = NULL;\n        while (node) {\n                if (node->key == key) {\n                    node->value = node->value - 1;\n                    if (!node->value) {\n                        if (!prev)\n                            map->buckets[hash] = node->next;\n                        else {    \n                            prev->next = node->next;\n                        }\n                        free(node);\n                        return 1;\n                    } else {\n                        break;\n                    }\n                }\n                prev = node;\n                node = node->next;\n        }\n        return 0;\n}\n\nvoid init(Map *map)\n{\n        int i;\n        map->N = 10000;\n        map->add = add;\n        map->find = find;\n        map->decrement = decrement;\n\n        map->buckets = malloc(sizeof(Node *) * map->N);\n        for (i = 0; i < map->N; i++)\n                map->buckets[i] = NULL;\n}\n\nint* dNums(int* A, int n1, int B, int *len1) {\n    int i;\n    int *ret = NULL;\n    int k = 0;\n    int distinct = 0;\n    Map map;\n    map.init = init;\n    \n    \n    *len1 = 0;\n    if (!A)\n        return NULL;\n    if (B > n1)\n        return NULL;\n        \n    *len1 = n1 - B + 1;\n    ret = malloc(sizeof(int) * (*len1));\n    \n    map.init(&map);\n    \n    for (i = 0; i < B; i++) {\n        if (!map.find(&map, A[i], NULL, NULL))\n            distinct++;\n        map.add(&map, A[i], 1);\n    }\n    \n    ret[k++] = distinct;\n    \n    \n    for (i = B; i < n1; i++) {\n        if (map.decrement(&map, A[i-B])) {\n            distinct--;\n        }\n        if (!map.find(&map, A[i], NULL, NULL)) {\n            distinct++;\n        }\n        map.add(&map, A[i], 1);\n        \n        ret[k++] = distinct;\n    }\n    return ret;\n}\n\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=aWC8bJ4GrSI&pp=ygUnaW50ZXJ2aWV3Yml0IGRpc3RpbmN0IG51bWJlcnMgaW4gd2luZG93',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
