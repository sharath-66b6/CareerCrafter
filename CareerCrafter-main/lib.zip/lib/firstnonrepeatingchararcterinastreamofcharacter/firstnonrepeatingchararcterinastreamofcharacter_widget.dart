import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'firstnonrepeatingchararcterinastreamofcharacter_model.dart';
export 'firstnonrepeatingchararcterinastreamofcharacter_model.dart';

class FirstnonrepeatingchararcterinastreamofcharacterWidget
    extends StatefulWidget {
  const FirstnonrepeatingchararcterinastreamofcharacterWidget({super.key});

  @override
  State<FirstnonrepeatingchararcterinastreamofcharacterWidget> createState() =>
      _FirstnonrepeatingchararcterinastreamofcharacterWidgetState();
}

class _FirstnonrepeatingchararcterinastreamofcharacterWidgetState
    extends State<FirstnonrepeatingchararcterinastreamofcharacterWidget> {
  late FirstnonrepeatingchararcterinastreamofcharacterModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(
        context, () => FirstnonrepeatingchararcterinastreamofcharacterModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'First non-repeating character in a stream of characters',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2200.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nGiven a string A denoting a stream of lowercase alphabets. You have to make new string B.\n\nB is formed such that we have to find first non-repeating character each time a character is inserted to the stream and append it at the end to B. If no non-repeating character is found then append \'#\' at the end of B.\n\n\n\nProblem Constraints\n1 <= length of the string <= 100000\n\n\n\nInput Format\nThe only argument given is string A.\n\n\n\nOutput Format\nReturn a string B after processing the stream of lowercase alphabets A.\n\n\n\nExample Input\nInput 1:\n\n A = \"abadbc\"\nInput 2:\n\n A = \"abcabc\"\n\n\nExample Output\nOutput 1:\n\n \"aabbdd\"\nOutput 2:\n\n \"aaabc#\"\n\n\nExample Explanation\nExplanation 1:\n\n    \"a\"      -   first non repeating character \'a\'\n    \"ab\"     -   first non repeating character \'a\'\n    \"aba\"    -   first non repeating character \'b\'\n    \"abad\"   -   first non repeating character \'b\'\n    \"abadb\"  -   first non repeating character \'d\'\n    \"abadbc\" -   first non repeating character \'d\'\nExplanation 2:\n\n    \"a\"      -   first non repeating character \'a\'\n    \"ab\"     -   first non repeating character \'a\'\n    \"abc\"    -   first non repeating character \'a\'\n    \"abca\"   -   first non repeating character \'b\'\n    \"abcab\"  -   first non repeating character \'c\'\n    \"abcabc\" -   no non repeating character so \'#\'\n\n\n\nAnswer :- \n/**\n * @input A : String termination by \'\\0\'\n * \n * @Output string. Make sure the string ends with null character\n */\nchar* solve(char* A) {\n    int len = strlen(A), front = -1, rear = -1;\n    char *B = (char*)malloc(len+1);\n    char NR[len];\n    int hash[26] = {0};\n    char *temp = B;\n    \n    *B = *A;\n    hash[*A - \'a\']++;\n    NR[++rear] = *A;\n    front++;\n    A++;\n    B++;\n\n    while(*A!=\'\\0\') {\n        hash[*A - \'a\']++;\n\n        NR[++rear] = *A;\n        if (front == -1)\n            front = 1;\n        \n        //printf(\"%d\\n\", hash[NR[front] - \'a\']);\n        while(front <= rear && hash[NR[front] - \'a\'] > 1)\n            front++;\n        \n        if (front > rear)\n            *B = \'#\';\n        else\n            *B = NR[front];\n        \n       // printf(\"%c\\n\", *B);\n        A++;\n        B++;\n    }\n    \n    temp[len] = \'\\0\';\n    return temp;\n}\n\n\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=4kqz5e9kIuQ&pp=ygUxaW50ZXJ2aWV3Yml0IGZpcnN0bm9ucmVwZWF0aW5nY2hhcmN0ZXJpbmFzdHJlYW1vZg%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
