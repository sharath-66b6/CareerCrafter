import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'levelorder_model.dart';
export 'levelorder_model.dart';

class LevelorderWidget extends StatefulWidget {
  const LevelorderWidget({super.key});

  @override
  State<LevelorderWidget> createState() => _LevelorderWidgetState();
}

class _LevelorderWidgetState extends State<LevelorderWidget> {
  late LevelorderModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => LevelorderModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Level Order',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2900.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven a binary tree, return the level order traversal of its nodes\' values. (ie, from left to right, level by level).\n\n\n\nProblem Constraints\n 1 <= number of nodes <= 105\n\n\n\nInput Format\nFirst and only argument is root node of the binary tree, A.\n\n\n\nOutput Format\nReturn a 2D integer array denoting the zigzag level order traversal of the given binary tree.\n\n\n\nExample Input\nInput 1:\n\n    3\n   / \\\n  9  20\n    /  \\\n   15   7\nInput 2:\n\n   1\n  / \\\n 6   2\n    /\n   3\n\n\nExample Output\nOutput 1:\n\n [\n   [3],\n   [9, 20],\n   [15, 7]\n ]\nOutput 2:\n\n [ \n   [1]\n   [6, 2]\n   [3]\n ]\n\n\nExample Explanation\nExplanation 1:\n\n Return the 2D array. Each row denotes the traversal of each level.\n\n\nAnswer :-\n/**\n * Definition for binary tree\n * struct TreeNode {\n *     int val;\n *     struct TreeNode *left;\n *     struct TreeNode *right;\n * };\n * \n * typedef struct TreeNode treenode;\n * \n * treenode* treenode_new(int val) {\n *     treenode* node = (treenode *) malloc(sizeof(treenode));\n *     node->val = val;\n *     node->left = NULL;\n *     node->right = NULL;\n *     return node;\n * }\n */\n/**\n * @input A : Root pointer of the tree \n * \n * @Output 2D int array. You need to malloc memory. Fill in len1 as row\n * For each row i, A[i][0] should indicate the number of columns in row i.\n * Then A[i][1] to A[i][col] should have the values in those columns.\n */\n \n int DFS (treenode *n, int **arr, int num[], int level){\n     \n     int rlevel, llevel;\n     \n     if(n == NULL) \n        return (level);\n     \n     if(!arr) {\n        num[level]++;\n     }\n     else {\n        arr[level][num[level]] = n->val; \n        num[level]++;\n     }\n     \n     llevel = DFS(n->left, arr, num, level+1);\n     rlevel = DFS(n->right, arr, num, level+1);\n     \n     return (rlevel > llevel ? rlevel : llevel);\n     \n     \n }\n\nint ** levelOrder(treenode* A, int *len1) {\n    int **arr = NULL;\n    int i, j;\n    int num[1000];\n\n    memset(num, 0, 1000*sizeof(int));\n    //DFS: to get level\n    *len1 = DFS(A, arr, num, 0);\n    \n    if(*len1 == 0) \n        return NULL;\n    \n    arr = (int **)malloc(*len1 * sizeof(int *));\n    for(i=0; i<*len1; i++){\n        arr[i] = malloc(sizeof(int) * (num[i]+1));\n        arr[i][0] = num[i];\n        //printf(\"%d=%d \", i, num[i]);\n        num[i] = 1;\n    }\n    \n    DFS(A, arr, num, 0);\n    \n    return arr;\n    //for(i=0; i< *len1; i++)\n    //    for(j=0; j<num[i]; j++)\n    //    printf(\"%d \", arr[i][j]);\n    \n    //*len1 = 0;\n    //return NULL;\n    \n    \n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=NPkaImYZwfo&pp=ygUYaW50ZXJ2aWV3Yml0IGxldmVsIG9yZGVy',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
