import '/flutter_flow/flutter_flow_util.dart';
import 'levelorder_widget.dart' show LevelorderWidget;
import 'package:flutter/material.dart';

class LevelorderModel extends FlutterFlowModel<LevelorderWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
