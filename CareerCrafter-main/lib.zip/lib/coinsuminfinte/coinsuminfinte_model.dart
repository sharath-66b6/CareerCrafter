import '/flutter_flow/flutter_flow_util.dart';
import 'coinsuminfinte_widget.dart' show CoinsuminfinteWidget;
import 'package:flutter/material.dart';

class CoinsuminfinteModel extends FlutterFlowModel<CoinsuminfinteWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
