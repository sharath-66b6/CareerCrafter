import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'coinsuminfinte_model.dart';
export 'coinsuminfinte_model.dart';

class CoinsuminfinteWidget extends StatefulWidget {
  const CoinsuminfinteWidget({super.key});

  @override
  State<CoinsuminfinteWidget> createState() => _CoinsuminfinteWidgetState();
}

class _CoinsuminfinteWidgetState extends State<CoinsuminfinteWidget> {
  late CoinsuminfinteModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CoinsuminfinteModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Coin Sum Infinite',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1500.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nYou are given a set of coins A. In how many ways can you make sum B assuming you have an infinite amount of each coin in the set.\n\nNote: Coins in set A will be unique. The expected space complexity of this problem is O(B).\nNote that the answer can overflow. So, give us the answer % 1000007\n\n\nProblem Constraints\n1 <= |A| <= 500\n1 <= B <= 5 * 104\n\n\nInput Format\nThe first argument is an integer array A.\nThe second argument is an integer B.\n\n\nOutput Format\nReturn the answer % 1000007\n\n\nExample Input\nA = [1, 2, 3]\nB = 4\n\n\nExample Output\n4\n\n\nExample Explanation\nThe 4 possible ways are\n{1, 1, 1, 1}\n{1, 1, 2}\n{2, 2}\n{1, 3}\n\n\n\n\nAnswer :-\n/**\n * @input A : Integer array\n * @input n1 : Integer array\'s ( A ) length\n * @input B : Integer\n * \n * @Output Integer\n */\nint coinchange2(int* A, int n1, int B) {\n    int n = n1;\n    int *table;\n    table = (int *)calloc(B+1,sizeof(int));\n    table[0] = 1;\n    int i, j;\n    for( i = 0; i < n; i++)\n    {\n        for(j = A[i]; j <= B; j++)\n        {\n            table[j] += table[j-A[i]];\n            table[j] = table[j] % 1000007;\n        }\n    }\n    return table[B];\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=RTpV8H8qYw4&pp=ygUeaW50ZXJ2aWV3Yml0IGNvaW4gc3VtIGluZmluaXRl',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
