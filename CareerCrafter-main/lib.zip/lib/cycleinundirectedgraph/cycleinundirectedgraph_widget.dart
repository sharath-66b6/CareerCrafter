import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'cycleinundirectedgraph_model.dart';
export 'cycleinundirectedgraph_model.dart';

class CycleinundirectedgraphWidget extends StatefulWidget {
  const CycleinundirectedgraphWidget({super.key});

  @override
  State<CycleinundirectedgraphWidget> createState() =>
      _CycleinundirectedgraphWidgetState();
}

class _CycleinundirectedgraphWidgetState
    extends State<CycleinundirectedgraphWidget> {
  late CycleinundirectedgraphModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CycleinundirectedgraphModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Cycle in Undirected Graph',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2400.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nGiven an undirected graph having A nodes labelled from 1 to A with M edges given in a form of matrix B of size M x 2 where (B[i][0], B[i][1]) represents two nodes B[i][0] and B[i][1] connected by an edge.\n\nFind whether the graph contains a cycle or not, return 1 if cycle is present else return 0.\n\nNOTE:\n\nThe cycle must contain atleast three nodes.\nThere are no self-loops in the graph.\nThere are no multiple edges between two nodes.\nThe graph may or may not be connected.\nNodes are numbered from 1 to A.\nYour solution will run on multiple test cases. If you are using global variables make sure to clear them.\n\n\nProblem Constraints\n1 <= A, M <= 3105\n\n1 <= B[i][0], B[i][1] <= A\n\n\n\nInput Format\nThe first argument given is an integer A representing the number of nodes in the graph.\n\nThe second argument given is an matrix B of size M x 2 which represents the M edges such that there is a edge between node B[i][0] and node B[i][1].\n\n\n\nOutput Format\nReturn 1 if cycle is present else return 0.\n\n\n\nExample Input\nInput 1:\n\n A = 5\n B = [  [1. 2]\n        [1, 3]\n        [2, 3]\n        [1, 4]\n        [4, 5]\n     ]\nInput 2:\n\n A = 3\n B = [  [1. 2]\n        [1, 3]\n     ]\n\n\nExample Output\nOutput 1:\n\n 1\nOutput 2:\n\n 0\n\n\nExample Explanation*\nExplanation 1:\n\n There is a cycle in the graph i.e 1 -> 2 -> 3 -> 1 so we will return 1\nExplanation 2:\n\n No cycle present in the graph so we will return 0.\n\n\n\nAnswer :-\nfrom collections import defaultdict\nclass Solution:\n    # @param A : integer\n    # @param B : list of list of integers\n    # @return an integer\n    def dfs(self,node,parent,visited):\n        \n        visited[node]=True\n        \n        for i in self.graph[node]:\n            \n            if visited[i]==True and i!=parent:\n                return True\n                \n            elif visited[i]==False and self.dfs(i,node,visited)==True:\n                return True\n                \n            \n        return False\n        \n    def solve(self, v, a):\n        \n        self.graph=defaultdict(list)\n        visited={}\n        \n        for i in a:\n            self.graph[i[0]].append(i[1])\n            self.graph[i[1]].append(i[0])\n            visited[i[0]]=False\n            visited[i[1]]=False\n            \n        for i in visited.keys():\n            #print(i)\n            if visited[i]==False:\n                if self.dfs(i,-1,visited):\n                    return 1\n        return 0\n            \n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=dwlY2LhOmX0&pp=ygUmaW50ZXJ2aWV3Yml0IGN5Y2xlIGluIHVuZGlyZWN0ZWQgZ3JhcGg%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
