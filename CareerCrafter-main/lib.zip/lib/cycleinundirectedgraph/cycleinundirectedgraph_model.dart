import '/flutter_flow/flutter_flow_util.dart';
import 'cycleinundirectedgraph_widget.dart' show CycleinundirectedgraphWidget;
import 'package:flutter/material.dart';

class CycleinundirectedgraphModel
    extends FlutterFlowModel<CycleinundirectedgraphWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
