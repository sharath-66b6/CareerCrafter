import '/flutter_flow/flutter_flow_util.dart';
import 'capacitytoshipinbdays_widget.dart' show CapacitytoshipinbdaysWidget;
import 'package:flutter/material.dart';

class CapacitytoshipinbdaysModel
    extends FlutterFlowModel<CapacitytoshipinbdaysWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
