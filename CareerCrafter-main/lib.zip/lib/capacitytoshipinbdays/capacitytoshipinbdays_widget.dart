import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'capacitytoshipinbdays_model.dart';
export 'capacitytoshipinbdays_model.dart';

class CapacitytoshipinbdaysWidget extends StatefulWidget {
  const CapacitytoshipinbdaysWidget({super.key});

  @override
  State<CapacitytoshipinbdaysWidget> createState() =>
      _CapacitytoshipinbdaysWidgetState();
}

class _CapacitytoshipinbdaysWidgetState
    extends State<CapacitytoshipinbdaysWidget> {
  late CapacitytoshipinbdaysModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CapacitytoshipinbdaysModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Capacity To Ship Packages Within B Days',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2700.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nA conveyor belt has packages that must be shipped from one port to another within B days.\n\nThe ith package on the conveyor belt has a weight of A[i]. Each day, we load the ship with packages on the conveyor belt (in the order given by weights). We may not load more weight than the maximum weight capacity of the ship.\n\nReturn the least weight capacity of the ship that will result in all the packages on the conveyor belt being shipped within B days.\n\n\n\nProblem Constraints\n1 <= B <= |A| <= 5 * 105\n1 <= A[i] <= 105\n\n\nInput Format\nFirst argument is array of integers A denoting the weights.\n\nSecond argument is the integer B denoting the number of days. \n\n\n\nOutput Format\nReturn the least weight capacity of the ship.\n\n\nExample Input\nInput 1:\nA = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]\nB = 5\nInput 2:\n\nA = [3, 2, 2, 4, 1, 4]\nB = 3\n\n\nExample Output\nOuput 1:\n15\nOuput 2:\n\n6\n\n\nExample Explanation\nExplanation 1:\nA ship capacity of 15 is the minimum to ship all the packages in 5 days like this:\n1st day: 1, 2, 3, 4, 5\n2nd day: 6, 7\n3rd day: 8\n4th day: 9\n5th day: 10\nNote that the cargo must be shipped in the order given, so using a ship of capacity 14 and \nsplitting the packages into parts like (2, 3, 4, 5), (1, 6, 7), (8), (9), (10) is not allowed.\nExplanation 2:\n\nA ship capacity of 6 is the minimum to ship all the packages in 3 days like this:\n1st day: 3, 2\n2nd day: 2, 4\n3rd day: 1, 4\n\n\n\nAnswer :- \n/**\n * @input A : Integer array\n * @input n1 : Integer array\'s ( A ) length\n * @input B : Integer\n * \n * @Output Integer\n */\nint canShip (int *A, int n1, int W, int D)\n{\n    int days = 1;\n    int i=0;\n    int sum=0;\n    while(i<n1)\n    {\n        if(sum+A[i] <= W)\n        {\n            sum = sum + A[i];   \n        }\n        else \n        {\n            days++;\n            sum = A[i];\n        } \n        i++;\n    }\n\n    //printf(\"days=%d D=%d\\n\",days,D);\n    if(days <= D )\n        return 1;\n    return 0;\n}\n\nint solve(int* A, int n1, int B) {\n    int min = INT_MIN;\n    int max = 0;\n\n    int j = 0;\n    for(j=0; j<n1; j++)\n    {\n        if(A[j] > min)\n            min = A[j];\n        max = max+A[j];\n    }\n\n    int mid;\n    while(min < max)\n    {\n        mid = (min+max)/2;\n        //printf(\"Checking for mid=%d [%d:%d]\\n\",mid,min,max);\n        if(canShip(A, n1, mid, B) == 1)\n        {\n            max = mid;\n        }\n        else\n        {\n            min = mid+1;\n        }\n    }\n    \n    return min;\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=MG-Ac4TAvTY&pp=ygUdaW50ZXJ2aWV3Yml0IGNhcGFjaXR5IHRvIHNoaXA%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
