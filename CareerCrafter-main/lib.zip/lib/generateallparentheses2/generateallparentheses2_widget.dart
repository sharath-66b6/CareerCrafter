import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'generateallparentheses2_model.dart';
export 'generateallparentheses2_model.dart';

class Generateallparentheses2Widget extends StatefulWidget {
  const Generateallparentheses2Widget({super.key});

  @override
  State<Generateallparentheses2Widget> createState() =>
      _Generateallparentheses2WidgetState();
}

class _Generateallparentheses2WidgetState
    extends State<Generateallparentheses2Widget> {
  late Generateallparentheses2Model _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => Generateallparentheses2Model());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Generate all Parentheses II',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1900.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven an integer A pairs of parentheses, write a function to generate all combinations of well-formed parentheses of length 2*A.\n\n\n\nProblem Constraints\n1 <= A <= 10\n\n\n\nInput Format\nFirst and only argument is integer A.\n\n\n\nOutput Format\nReturn a sorted list of all possible parenthesis.\n\n\n\nExample Input\nInput 1:\n\nA = 3\nInput 2:\n\nA = 1\n\n\nExample Output\nOutput 1:\n\n[ \"((()))\", \"(()())\", \"(())()\", \"()(())\", \"()()()\" ]\nOutput 2:\n\n[ \"()\" ]\n\n\nExample Explanation\nExplanation 1:\n\n All paranthesis are given in the output list.\nExplanation 2:\n\n All paranthesis are given in the output list.\n\n\n\nAnswer :-\n/**\n * @input A : Integer\n * \n * @Output string array. You need to malloc memory. \n *   Fill in len1 as number of strings. Make sure every string ends with null character\n * \n */\n void ans( char **v,int A, char *s,int pos,int c1,int c2,int *l)\n{\n    if(c2==A)\n    {   int i;\n        s[pos] = \'\\0\';\n        strcpy(v[(*l)],s);\n        *l = (*l) +1;return;\n    }\n    if(c1<A)\n    {\n           s[pos] = \'(\';\n        ans(v,A,s,pos+1,c1+1,c2,l);\n    }\n    if(c1>c2)\n    {\n        s[pos] = \')\';\n        ans(v,A,s,pos+1,c1,c2+1,l);\n    }\n    \n    \n}\nchar** generateParenthesis(int A, int *l) {\n    \n     int q = 2*A; char **a = (char**)malloc(20000*sizeof(char*));int i;\n    for(i  = 0;i<20000;i++)\n    a[i] = (char*)malloc(sizeof(char)*q);\n    \nchar *s = (char *)malloc(sizeof(char)*q);\n *l = 0;\n    ans(a,A,s,0,0,0,l);\n\n    return a;\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=m9cAnLM3-yg&pp=ygUmaW50ZXJ2aWV3Yml0IGdlbmVyYXRlIGFsbCBwYXJlbnRoZXNlIDI%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
