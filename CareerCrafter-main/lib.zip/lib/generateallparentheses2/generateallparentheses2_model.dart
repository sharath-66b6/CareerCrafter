import '/flutter_flow/flutter_flow_util.dart';
import 'generateallparentheses2_widget.dart' show Generateallparentheses2Widget;
import 'package:flutter/material.dart';

class Generateallparentheses2Model
    extends FlutterFlowModel<Generateallparentheses2Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
