import '/flutter_flow/flutter_flow_util.dart';
import 'binarysearch_widget.dart' show BinarysearchWidget;
import 'package:flutter/material.dart';

class BinarysearchModel extends FlutterFlowModel<BinarysearchWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
