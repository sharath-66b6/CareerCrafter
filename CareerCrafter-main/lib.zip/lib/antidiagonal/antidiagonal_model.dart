import '/flutter_flow/flutter_flow_util.dart';
import 'antidiagonal_widget.dart' show AntidiagonalWidget;
import 'package:flutter/material.dart';

class AntidiagonalModel extends FlutterFlowModel<AntidiagonalWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
