import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'antidiagonal_model.dart';
export 'antidiagonal_model.dart';

class AntidiagonalWidget extends StatefulWidget {
  const AntidiagonalWidget({super.key});

  @override
  State<AntidiagonalWidget> createState() => _AntidiagonalWidgetState();
}

class _AntidiagonalWidgetState extends State<AntidiagonalWidget> {
  late AntidiagonalModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => AntidiagonalModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Anti Diagonals',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1400.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nGive a N*N square matrix, return an array of its anti-diagonals. Look at the example for more details.\nExample:\n\nInput:\n\n1 2 3\n4 5 6\n7 8 9\nReturn the following:\n[ \n  [1],\n  [2, 4],\n  [3, 5, 7],\n  [6, 8],\n  [9]\n]\n\n\nInput: \n1 2\n3 4\nReturn the following: \n[\n  [1],\n  [2, 3],\n  [4]\n]\n\n\nAnswer :-\nint ** diagonal(int** a, int row, int col, int *length) {\n    *length = 2*row -1 ; \n    int ** res = malloc(sizeof(int *)*(*length));\n    int i,j,k,x,len ,count = 0 ;\n    for(len=1;len<=row;len++)\n    {\n        i=0;\n        j=len-1 ;\n        res[count] = malloc(sizeof(int)*(len+1));\n        res[count][0] = len ;\n        while(j>=0)\n        {\n            res[count][i+1] = a[i][j] ;\n            i++ ;\n            j--;\n        }\n        count++ ;\n    }\n    for(len-=2,k=1;len>0;len--,k++)\n    {\n        j= row-1 ;\n        i= k ;\n        res[count] = malloc(sizeof(int)*(len+1));\n        res[count][0] = len ;\n        x=1 ;\n        while(i<row)\n        {\n            res[count][x++]=a[i][j] ;\n            i++;\n            j--;\n        }\n        count++ ;\n    }\n    \n    return res; \n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=87PJMk5R8-Y&pp=ygUaaW50ZXJ2aWV3Yml0IGFudGkgZGlhZ29uYWw%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
