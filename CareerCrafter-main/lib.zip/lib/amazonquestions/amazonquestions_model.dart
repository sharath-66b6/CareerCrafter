import '/flutter_flow/flutter_flow_util.dart';
import 'amazonquestions_widget.dart' show AmazonquestionsWidget;
import 'package:flutter/material.dart';

class AmazonquestionsModel extends FlutterFlowModel<AmazonquestionsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
