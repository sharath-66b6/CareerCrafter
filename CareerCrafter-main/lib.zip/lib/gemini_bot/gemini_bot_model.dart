import '/flutter_flow/flutter_flow_util.dart';
import 'gemini_bot_widget.dart' show GeminiBotWidget;
import 'package:flutter/material.dart';

class GeminiBotModel extends FlutterFlowModel<GeminiBotWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;
  // Stores action output result for [Gemini - Generate Text] action in Button widget.
  String? result;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    textFieldFocusNode?.dispose();
    textController?.dispose();
  }
}
