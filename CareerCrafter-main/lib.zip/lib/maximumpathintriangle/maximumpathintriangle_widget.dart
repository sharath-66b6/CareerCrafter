import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'maximumpathintriangle_model.dart';
export 'maximumpathintriangle_model.dart';

class MaximumpathintriangleWidget extends StatefulWidget {
  const MaximumpathintriangleWidget({super.key});

  @override
  State<MaximumpathintriangleWidget> createState() =>
      _MaximumpathintriangleWidgetState();
}

class _MaximumpathintriangleWidgetState
    extends State<MaximumpathintriangleWidget> {
  late MaximumpathintriangleModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MaximumpathintriangleModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Maximum Path in Triangle',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2200.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nGiven a 2D integer array A of size  N * N   representing a triangle of numbers.\n\nFind the maximum path sum from top to bottom. Each step you may move to adjacent numbers on the row below.\n\nNOTE:\n\nAdjacent cells to cell (i,j) are only (i+1,j) and (i+1,j+1)\nRow i contains i integer and n-i zeroes for all i in [1,n] where zeroes represents empty cells.\n\n\nProblem Constraints\n 0 <= N <= 1000 \n\n 0 <= A[i][j] <= 1000 \n\n\n\nInput Format\nFirst and only argument is an 2D integer array A of size N * N.\n\n\n\nOutput Format\nReturn a single integer denoting the maximum path sum from top to bottom in the triangle.\n\n\n\nExample Input\nInput 1:\n\n A = [\n        [3, 0, 0, 0]\n        [7, 4, 0, 0]\n        [2, 4, 6, 0]\n        [8, 5, 9, 3]\n     ]\nInput 2:\n\n A = [\n        [8, 0, 0, 0]\n        [4, 4, 0, 0]\n        [2, 2, 6, 0]\n        [1, 1, 1, 1]\n     ]\n\n\nExample Output\nOutput 1:\n\n 23\nOutput 2:\n\n 19\n\n\nExample Explanation\nExplanation 1:\n\n Given triangle looks like:  3\n                             7 4\n                             2 4 6\n                             8 5 9 3\n        So max path is (3 + 7 + 4 + 9) = 23\nExplanation 1:\n\n Given triangle looks like:  8\n                             4 4\n                             2 2 6\n                             1 1 1 1\n        So max path is (8 + 4 + 6 + 1) = 19\n\n\n\n\nAnswer :-\n/**\n * @input A : 2D integer array \n * @input n11 : Integer array\'s ( A ) rows\n * @input n12 : Integer array\'s ( A ) columns\n * \n * @Output Integer\n */\nint max(int a, int b)\n{\n    if(a>b) return a ;\n    else return b; \n}\nint solve(int** A, int n11, int n12) \n{\n    int** dp = (int**)malloc(sizeof(int**)*n11);\n    int i,j ;\n    for(i=0;i<n11;i++)\n    *(dp+i) = (int*)malloc(sizeof(int)*n12) ;\n    \n    for(i=0;i<n12;i++)\n    dp[n11-1][i] = A[n11-1][i] ;\n    \n    for(i=n11-2;i>=0;i--)\n    {\n        for(j=i;j>=0;j--)\n        dp[i][j] = A[i][j] + max(dp[i+1][j], dp[i+1][j+1]);\n    }\n    return dp[0][0] ;\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=aHEaPDc8fYM&pp=ygUlaW50ZXJ2aWV3Yml0IG1heGltdW0gcGF0aCBpbiB0cmlhbmdsZQ%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
