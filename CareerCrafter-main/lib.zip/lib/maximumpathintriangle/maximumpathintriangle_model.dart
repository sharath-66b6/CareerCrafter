import '/flutter_flow/flutter_flow_util.dart';
import 'maximumpathintriangle_widget.dart' show MaximumpathintriangleWidget;
import 'package:flutter/material.dart';

class MaximumpathintriangleModel
    extends FlutterFlowModel<MaximumpathintriangleWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
