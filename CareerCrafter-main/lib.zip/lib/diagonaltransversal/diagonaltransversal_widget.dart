import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'diagonaltransversal_model.dart';
export 'diagonaltransversal_model.dart';

class DiagonaltransversalWidget extends StatefulWidget {
  const DiagonaltransversalWidget({super.key});

  @override
  State<DiagonaltransversalWidget> createState() =>
      _DiagonaltransversalWidgetState();
}

class _DiagonaltransversalWidgetState extends State<DiagonaltransversalWidget> {
  late DiagonaltransversalModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => DiagonaltransversalModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Diagonal Traversal',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2900.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nConsider lines of slope -1 passing between nodes.\n\nGiven a Binary Tree A containing N nodes, return all diagonal elements in a binary tree belonging to same line.\n\nNOTE:\n\nSee Sample Explanation for better understanding.\nOrder does matter in the output.\nTo get the same order as in the output traverse the tree same as we do in pre-order traversal.\n\n\nProblem Constraints\n 0 <= N <= 105 \n\n\n\nInput Format\nFirst and only Argument represents the root of binary tree A.\n\n\n\nOutput Format\nReturn a 1D array denoting the diagonal traversal of the tree.\n\n\n\nExample Input\nInput 1:\n\n            1\n          /   \\\n         4      2\n        / \\      \\\n       8   5      3\n          / \\    /\n         9   7  6\nInput 2:\n\n             11\n          /     \\\n         20      12\n        / \\       \\\n       1   15      13\n          /  \\     /\n         2    17  16\n          \\   /\n          22 34\n\n\nExample Output\nOutput 1:\n\n [1, 2, 3, 4, 5, 7, 6, 8, 9]\nOutput 2:\n\n [11, 12, 13, 20, 15, 17, 16, 1, 2, 22, 34]\n\n\nExample Explanation\nExplanation 1:\n\n \n 1) Diagonal 1 contains [1, 2, 3]\n 2) Diagonal 2 contains [4, 5, 7, 6]\n 3) Diagonal 3 contains [8, 9]\n\n\nNOTE:\nThe order in the output matters like for Example:\n6 and 7 belong to same diagonal i.e diagonal 2 but as 7 comes before 6 in pre-order traversal so 7 will be added to answer array first.\n\n\n\nSo concantenate all the array as return it as a single one.\n Final output: [1, 2, 3, 4, 5, 7, 6, 8, 9]\n\nExplanation 2:\n\n \n 1) Diagonal 1 contains [11, 12, 13]\n 2) Diagonal 2 contains [20, 15, 17, 16]\n 3) Diagonal 2 contains [1, 2, 22, 34]\n\n\nSo concantenate all the array as return it as a single one.\n Final output: [11, 12, 13, 20, 15, 17, 16, 1, 2, 22, 34]\n\n\n\nAnswer :-\n/**\n * Definition for binary tree\n * struct TreeNode {\n *     int val;\n *     struct TreeNode *left;\n *     struct TreeNode *right;\n * };\n * \n * typedef struct TreeNode treenode;\n * \n * treenode* treenode_new(int val) {\n *     treenode* node = (treenode *) malloc(sizeof(treenode));\n *     node->val = val;\n *     node->left = NULL;\n *     node->right = NULL;\n *     return node;\n * }\n */\n/**\n * @input A : Root pointer of the tree \n * \n * @Output Integer array. You need to malloc memory, and fill the length in len1\n */\nint *ans = NULL;\nint iter = 0;\nint k = 0;\nvoid add_node(treenode **arr, treenode *root) {\n    while (root != NULL) {\n        arr[k++] = root;\n        root = root->right;\n    }\n}\nvoid path(treenode **arr) {\n    while (arr[iter] != 0) {\n        ans[iter] = arr[iter]->val;\n        if (arr[iter]->left != NULL)\n            add_node(arr, arr[iter]->left);\n        iter++;\n        \n    }\n}\nint* solve(treenode* A, int *len1) {\n    k = 0;\n    iter = 0;\n    ans = (int*)malloc(sizeof(int)*100000);\n    treenode* arr[100000] = { 0 };\n    add_node(arr, A);\n    path(arr);\n    *len1 = iter;\n    return ans;\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=OXJCeMUIqa0&pp=ygUhaW50ZXJ2aWV3Yml0IGRpYWdvbmFsIHRyYW5zdmVyc2Fs',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
