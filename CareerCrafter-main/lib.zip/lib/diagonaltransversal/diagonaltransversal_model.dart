import '/flutter_flow/flutter_flow_util.dart';
import 'diagonaltransversal_widget.dart' show DiagonaltransversalWidget;
import 'package:flutter/material.dart';

class DiagonaltransversalModel
    extends FlutterFlowModel<DiagonaltransversalWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
