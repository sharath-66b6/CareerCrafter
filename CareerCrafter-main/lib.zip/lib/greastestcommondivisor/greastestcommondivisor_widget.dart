import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'greastestcommondivisor_model.dart';
export 'greastestcommondivisor_model.dart';

class GreastestcommondivisorWidget extends StatefulWidget {
  const GreastestcommondivisorWidget({super.key});

  @override
  State<GreastestcommondivisorWidget> createState() =>
      _GreastestcommondivisorWidgetState();
}

class _GreastestcommondivisorWidgetState
    extends State<GreastestcommondivisorWidget> {
  late GreastestcommondivisorModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => GreastestcommondivisorModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Greatest Common Divisor',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1000.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven 2 non-negative integers A and B, find gcd(A, B).\nGCD of 2 integers m and n is defined as the greatest integer g such that g is a divisor of both m and n.\nBoth A and B fit in a 32-bit signed integer.\nNOTE: DO NOT USE LIBRARY FUNCTIONS\n\n\nProblem Constraints\n0 <= A <= 109\n0 <= B <= 109\n\n\nInput Format\nThe first argument is an integer A.\nThe second argument is an integer B.\n\n\nOutput Format\nReturn the Greatest Common Divisor of A and B\n\n\nExample Input\nInput 1:\nA = 6\nB = 9\n\n\nExample Output\nOutput 1:\n3\n\n\nExample Explanation\nExplanation 1:\n3 is the GCD of 6 and 9\n\n\nAnswer:-\nint gcd(int A, int B) \n{\n  if ( A==0 ) \n  return B;\n  else\n  return gcd ( B%A, A );\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=tSf-0uYHIDA&pp=ygUlaW50ZXJ2aWV3Yml0IGdyZWF0ZXN0IGNvbW1vbiBkaXZpc29yIA%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
