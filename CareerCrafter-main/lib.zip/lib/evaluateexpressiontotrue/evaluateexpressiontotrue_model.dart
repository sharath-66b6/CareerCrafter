import '/flutter_flow/flutter_flow_util.dart';
import 'evaluateexpressiontotrue_widget.dart'
    show EvaluateexpressiontotrueWidget;
import 'package:flutter/material.dart';

class EvaluateexpressiontotrueModel
    extends FlutterFlowModel<EvaluateexpressiontotrueWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
