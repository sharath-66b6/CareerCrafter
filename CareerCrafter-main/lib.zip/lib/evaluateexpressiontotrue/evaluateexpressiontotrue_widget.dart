import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'evaluateexpressiontotrue_model.dart';
export 'evaluateexpressiontotrue_model.dart';

class EvaluateexpressiontotrueWidget extends StatefulWidget {
  const EvaluateexpressiontotrueWidget({super.key});

  @override
  State<EvaluateexpressiontotrueWidget> createState() =>
      _EvaluateexpressiontotrueWidgetState();
}

class _EvaluateexpressiontotrueWidgetState
    extends State<EvaluateexpressiontotrueWidget> {
  late EvaluateexpressiontotrueModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => EvaluateexpressiontotrueModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Evaluate Expression To True',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2500.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \nGiven an expression, A, with operands and operators (OR , AND , XOR), in how many ways can you evaluate the expression to true, by grouping in different ways?\n\nOperands are only true and false.\n\nReturn the number of ways to evaluate the expression modulo 103 + 3.\n\n\n\nInput Format:\n\nThe first and the only argument of input will contain a string, A.\n\nThe string A, may contain these characters:\n    \'|\' will represent or operator \n    \'&\' will represent and operator\n    \'^\' will represent xor operator\n    \'T\' will represent true operand\n    \'F\' will false\nOutput:\n\nReturn an integer, representing the number of ways to evaluate the string.\nConstraints:\n\n1 <= length(A) <= 150\nExample:\n\nInput 1:\n    A = \"T|F\"\n\nOutput 1:\n    1\n\nExplanation 1:\n    The only way to evaluate the expression is:\n        => (T|F) = T \n\nInput 2:\n    A = \"T^T^F\"\n    \nOutput 2:\n    0\n    \nExplanation 2:\n    There is no way to evaluate A to a true statement.\n\n\n\nAnswer :-\n/**\n * @input A : String termination by \'\\0\'\n * \n * @Output Integer\n */\nint cnttrue(char* A) {\n    \n    int l=strlen(A);\n    char*op=(char*)malloc(sizeof(char)*(l/2+5));\n    char*ope=(char*)malloc(sizeof(char)*(l/2+5));\n    \n    int i,j=0,k=0,g;\n    \n    for(i=1;i<l;i=i+2){\n        op[k++]=A[i];\n        ope[j++]=A[i-1];\n    }\n    \n    ope[j++]=A[i-1];\n    ope[j]=\'\\0\';\n    op[k]=\'\\0\';\n // free(A);\n  // printf(\"%s %s  \",ope,op);\n    //j--;k--;\n    int**t=(int**)malloc(sizeof(int*)*j);\n    int**f=(int**)malloc(sizeof(int*)*j);\n    \n    for(i=0;i<j;i++){\n        t[i]=(int*)malloc(sizeof(int)*j);f[i]=(int*)malloc(sizeof(int)*j); \n        for(g=0;g<j;g++)t[i][g]=f[i][g]=0;\n        \n        if(ope[i]==\'T\')t[i][i]=1;\n        else f[i][i]=1;\n    }\n   // printf(\"%d %d \",j,k);\n    int L,n=j;\n    for(L=1;L<n;L++){\n        \n        for(i=0,j=L+i;i<n&&j<n;i++,j++){\n        \n            for(k=i;k<j;k++){\n                \n                if(op[k]==\'&\'){\n                    t[i][j]=(t[i][j]+ (t[i][k]*t[k+1][j])%1003)%1003;\n                    f[i][j]=(f[i][j]+ (f[i][k]*f[k+1][j]+f[i][k]*t[k+1][j]+t[i][k]*f[k+1][j])%1003)%1003;\n                }\n                else if(op[k]==\'|\'){\n                    t[i][j]=(t[i][j]+ (t[i][k]*t[k+1][j]+t[i][k]*f[k+1][j]+f[i][k]*t[k+1][j])%1003)%1003;\n                    f[i][j]=(f[i][j]+ (f[i][k]*f[k+1][j]%1003)%1003);\n                }\n                else if(op[k]==\'^\'){\n                    t[i][j]=(t[i][j]+ (t[i][k]*f[k+1][j]+f[i][k]*t[k+1][j])%1003)%1003;\n                    f[i][j]=(f[i][j]+ (t[i][k]*t[k+1][j]+f[i][k]*f[k+1][j])%1003)%1003;\n                }\n            }\n           // printf(\"%d %d %d %d  \",i,j,t[i][j],f[i][j]);\n        }\n    }\n    int x=t[0][n-1];\n    for(i=0;i<n;i++){\n        free(t[i]);free(f[i]);}\n        free(t);free(f);\n    free(op);free(ope);\n    return x%1003;\n    //return 0;\n    \n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=pGVguAcWX4g&pp=ygUnaW50ZXJ2aWV3Yml0IGV2YWx1dGUgZXhwcmVzc2lvbiB0byB0cnVl',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
