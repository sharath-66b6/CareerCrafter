import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'arraysum_model.dart';
export 'arraysum_model.dart';

class ArraysumWidget extends StatefulWidget {
  const ArraysumWidget({super.key});

  @override
  State<ArraysumWidget> createState() => _ArraysumWidgetState();
}

class _ArraysumWidgetState extends State<ArraysumWidget> {
  late ArraysumModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ArraysumModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Array Sum',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2000.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nYou are given two numbers represented as integer arrays A and B, where each digit is an element.\n You have to return an array which representing the sum of the two given numbers.\n\nThe last element denotes the least significant bit, and the first element denotes the most significant bit.\n\nNote : Array A and Array B can be of different size. ( i.e. length of Array A may not be equal to length of Array B ).\n\n\n\nProblem Constraints\n1 <= |A|, |B| <= 105\n0 <= Ai, Bi <= 9\n\n\nInput Format\nThe first argument is an integer array A. The second argument is an integer array B.\n\n\nOutput Format\nReturn an array denoting the sum of the two numbers.\n\n\nExample Input\nInput 1:\nA = [1, 2, 3]\nB = [2, 5, 5]\nInput 2:\n\nA = [9, 9, 1]\nB = [1, 2, 1]\n\n\nExample Output\nOutput 1:\n[3, 7, 8]\nOutput 2:\n\n[1, 1, 1, 2]\n\n\nExample Explanation\nExplanation 1:\nSimply, add all the digits in their place.\nExplanation 2:\n\n991 + 121 = 1112\nNote that the resultant array size might be larger.\n\n\nAnswer :-\n/**\n * @input A : Integer array\n * @input n1 : Integer array\'s ( A ) length\n * @input B : Integer array\n * @input n2 : Integer array\'s ( B ) length\n * \n * @Output Integer array. You need to malloc memory, and fill the length in len1\n */\nint* addArrays(int* A, int n1, int* B, int n2, int *len1) {\n    int maxn = (n2 > n1) ? n2 : n1;\n    int* extA = (int*) malloc(sizeof(int)*maxn);\n    int* extB = (int*) malloc(sizeof(int)*maxn);\n    int i;\n    for (i = (maxn - 1); i >= 0 ; i--) {\n        int jA = i - (maxn - n1);\n        int jB = i - (maxn - n2);\n        extA[i] = (jA >= 0) ? A[jA] : 0;\n        extB[i] = (jB >= 0) ? B[jB] : 0;\n    }\n    *len1 = maxn;\n    int* res = (int*) malloc(sizeof(int)*(*len1));\n    int carry = 0;\n    for (i = (*len1 - 1); i >= 0; i--) {\n        int sum = extA[i] + extB[i] + carry;\n        res[i] = sum % 10;\n        carry = sum / 10;\n    }\n    if (carry > 0) {\n        *len1 = maxn + 1;\n        int* temp = (int*) malloc(sizeof(int)*(*len1));\n        temp[0] = carry;\n        int i;\n        for (i = 0; i < *len1; i++) {\n            temp[i+1] = res[i];\n        }\n        free(res);\n        res = temp;\n    }\n    free(extA);\n    free(extB);\n    return res;\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=QOMu1LNSs2g&pp=ygUWaW50ZXJ2aWV3Yml0IGFycmF5IHN1bQ%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
