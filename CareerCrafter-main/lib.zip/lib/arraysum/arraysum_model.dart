import '/flutter_flow/flutter_flow_util.dart';
import 'arraysum_widget.dart' show ArraysumWidget;
import 'package:flutter/material.dart';

class ArraysumModel extends FlutterFlowModel<ArraysumWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
