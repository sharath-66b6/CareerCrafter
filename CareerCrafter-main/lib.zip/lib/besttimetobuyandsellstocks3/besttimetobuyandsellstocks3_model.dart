import '/flutter_flow/flutter_flow_util.dart';
import 'besttimetobuyandsellstocks3_widget.dart'
    show Besttimetobuyandsellstocks3Widget;
import 'package:flutter/material.dart';

class Besttimetobuyandsellstocks3Model
    extends FlutterFlowModel<Besttimetobuyandsellstocks3Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
