import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'besttimetobuyandsellstocks3_model.dart';
export 'besttimetobuyandsellstocks3_model.dart';

class Besttimetobuyandsellstocks3Widget extends StatefulWidget {
  const Besttimetobuyandsellstocks3Widget({super.key});

  @override
  State<Besttimetobuyandsellstocks3Widget> createState() =>
      _Besttimetobuyandsellstocks3WidgetState();
}

class _Besttimetobuyandsellstocks3WidgetState
    extends State<Besttimetobuyandsellstocks3Widget> {
  late Besttimetobuyandsellstocks3Model _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => Besttimetobuyandsellstocks3Model());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Best Time to Buy and Sell Stocks III',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1900.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nSay you have an array, A, for which the ith element is the price of a given stock on day i.\n\nDesign an algorithm to find the maximum profit. You may complete at most 2 transactions.\n\nReturn the maximum possible profit.\n\nNote: You may not engage in multiple transactions at the same time (ie, you must sell the stock before you buy again).\n\n\nProblem Constraints\n1 <= length(A) <= 7e5\n1 <= A[i] <= 1e7\n\n\nInput Format\nThe first and only argument is an integer array, A.\n\n\nOutput Format\nReturn an integer, representing the maximum possible profit.\n\n\nExample Input\nInput 1:\n    A = [1, 2, 1, 2]\n\n\nInput 2:\n    A = [7, 2, 4, 8, 7]\n\n\n\nExample Output\nOutput 1:\n    2\nOutput 2:\n    6\n\n\nExample Explanation\nExplanation 1: \n    Day 0 : Buy \n    Day 1 : Sell\n    Day 2 : Buy\n    Day 3 : Sell\n\n\nExplanation 2:\n    Day 1 : Buy\n    Day 3 : Sell\n\n\n\n\nAnswer :-\n/**\n * @input A : Read only ( DON\'T MODIFY ) Integer array\n * @input n1 : Integer array\'s ( A ) length\n * \n * @Output Integer\n */\nint maxProfit(const int* A, int n1) {\n    int l[n1];\n    int r[n1];\n     l[0] = 0;\n    r[n1-1] = 0;int i,j;\n    int min = A[0];\n    for( i = 1;i<n1;i++)\n{    l[i] =(l[i-1]<(A[i]-min))?A[i]-min : l[i-1];\nmin = (A[i]<min)?A[i]:min;\n}\n     int max = A[n1-1];\n     \n    for( i = n1-2;i>=0;i--)\n    {\n         r[i] = (r[i+1]<(max-A[i]))?(max-A[i]):r[i+1];\nmax = (A[i]>max)?A[i]:max;\n    }\n      max = 0;\n    for( i = 0;i<n1;i++)\n    {\n        (max =  (l[i]+r[i])>max? (l[i]+r[i]):max);\n    }\n    return max;\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=37s1_xBiqH0&pp=ygUvaW50ZXJ2aWV3Yml0IGJlc3QgdGltZSB0byBidXkgYW5kIHNlbGwgc3RvY2tzIDM%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
