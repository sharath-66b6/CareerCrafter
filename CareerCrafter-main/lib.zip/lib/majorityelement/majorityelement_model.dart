import '/flutter_flow/flutter_flow_util.dart';
import 'majorityelement_widget.dart' show MajorityelementWidget;
import 'package:flutter/material.dart';

class MajorityelementModel extends FlutterFlowModel<MajorityelementWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
