import '/flutter_flow/flutter_flow_util.dart';
import 'difffk2_widget.dart' show Difffk2Widget;
import 'package:flutter/material.dart';

class Difffk2Model extends FlutterFlowModel<Difffk2Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
