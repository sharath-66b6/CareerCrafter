import '/flutter_flow/flutter_flow_util.dart';
import 'maxdistance_widget.dart' show MaxdistanceWidget;
import 'package:flutter/material.dart';

class MaxdistanceModel extends FlutterFlowModel<MaxdistanceWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
