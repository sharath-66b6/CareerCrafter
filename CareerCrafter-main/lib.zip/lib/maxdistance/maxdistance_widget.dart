import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'maxdistance_model.dart';
export 'maxdistance_model.dart';

class MaxdistanceWidget extends StatefulWidget {
  const MaxdistanceWidget({super.key});

  @override
  State<MaxdistanceWidget> createState() => _MaxdistanceWidgetState();
}

class _MaxdistanceWidgetState extends State<MaxdistanceWidget> {
  late MaxdistanceModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MaxdistanceModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Max Distance',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven an array A of integers, find the maximum of j - i subjected to the constraint of A[i] <= A[j].\n\n\n\nProblem Constraints\n1 <= |A| <= 106\n-109 <= Ai <= 109\n\n\nInput Format\nFirst and only argument is an integer array A.\n\n\n\nOutput Format\nReturn an integer denoting the maximum value of j - i;\n\n\n\nExample Input\nInput 1:\n\n A = [3, 5, 4, 2]\n\n\nExample Output\nOutput 1:\n\n 2\n\n\nExample Explanation\nExplanation 1:\n\n Maximum value occurs for pair (3, 4).\n\n\n\n\nAnswer :-\nint maximumGap(const int* A, int n1) {\n    int lmin[n1], \n    rmax[n1], \n    i, j,\n    max = -1;\n    \n    for(i=0; i<n1; i++){ lmin[i] = (i==0 || A[i]<lmin[i-1])? A[i] : lmin[i-1]; }\n    for(i=n1-1; i>=0; i--){ rmax[i] = (i==n1-1 || A[i]>rmax[i+1])? A[i] : rmax[i+1];}\n    for(i=0, j=0; i<n1 && j<n1; ){\n        if(A[i]<=rmax[j]){\n            if(j-i > max) max = j - i;\n            j++;\n        }else{\n            i++;\n        }\n    }\n    return max;\n}',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=u2yHsFzrNQo&pp=ygUZaW50ZXJ2aWV3Yml0IG1heCBkaXN0YW5jZQ%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
