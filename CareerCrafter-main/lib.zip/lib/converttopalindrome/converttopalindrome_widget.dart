import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'converttopalindrome_model.dart';
export 'converttopalindrome_model.dart';

class ConverttopalindromeWidget extends StatefulWidget {
  const ConverttopalindromeWidget({super.key});

  @override
  State<ConverttopalindromeWidget> createState() =>
      _ConverttopalindromeWidgetState();
}

class _ConverttopalindromeWidgetState extends State<ConverttopalindromeWidget> {
  late ConverttopalindromeModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ConverttopalindromeModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Convert to Palindrome',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1900.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nGiven a string A consisting only of lowercase characters, we need to check whether it is possible to make this string a palindrome after removing exactly one character from this.\n\nIf it is possible then return 1 else return 0.\n\n\n\nProblem Constraints\n3 <= |A| <= 105\n\n A[i] is always a lowercase character.\n\n\n\nInput Format\nFirst and only argument is an string A.\n\n\n\nOutput Format\nReturn 1 if it is possible to convert A to palindrome by removing exactly one character else return 0.\n\n\n\nExample Input\nInput 1:\n\n A = \"abcba\"\nInput 2:\n\n A = \"abecbea\"\n\n\nExample Output\nOutput 1:\n\n 1\nOutput 2:\n\n 0\n\n\nExample Explanation\nExplanation 1:\n\n We can remove character ‘c’ to make string palindrome\nExplanation 2:\n\n It is not possible to make this string palindrome just by removing one character \n\n\nAnswer :-\n/**\n * @input A : String termination by \'\\0\'\n * \n * @Output Integer\n */\nint solve(char* A) {\n    int i=0;\n    int j = strlen(A)-1;\n    int c=0;\n    int flag=0;\n    while(i<j){\n        if(A[i] == A[j]){\n            i++;\n            j--;\n        }\n        else{\n            if(A[i] == A[j-1]){\n                c++;\n                j--;\n            }\n            else if(A[j] == A[i+1]){\n                c++;\n                i++;\n            }\n            else{\n                flag=1;\n                break;\n            }\n        }\n        \n        if(c>1){\n            flag=1;\n            break;\n        }\n    }\n    if(flag==1){\n        return 0;\n    }\n    else\n    {\n        return 1;\n    }\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=JW8DqPL98pM&pp=ygUjaW50ZXJ2aWV3Yml0IGNvbmN2ZXJ0IHRvIHBhbGluZHJvbWU%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
