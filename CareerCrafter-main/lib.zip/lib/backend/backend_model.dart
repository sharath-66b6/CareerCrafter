import '/flutter_flow/flutter_flow_util.dart';
import 'backend_widget.dart' show BackendWidget;
import 'package:flutter/material.dart';

class BackendModel extends FlutterFlowModel<BackendWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
