import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'longestsubstringwithoutrepeat_model.dart';
export 'longestsubstringwithoutrepeat_model.dart';

class LongestsubstringwithoutrepeatWidget extends StatefulWidget {
  const LongestsubstringwithoutrepeatWidget({super.key});

  @override
  State<LongestsubstringwithoutrepeatWidget> createState() =>
      _LongestsubstringwithoutrepeatWidgetState();
}

class _LongestsubstringwithoutrepeatWidgetState
    extends State<LongestsubstringwithoutrepeatWidget> {
  late LongestsubstringwithoutrepeatModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => LongestsubstringwithoutrepeatModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Longest Substring Without Repeat',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1900.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven a string A, find the length of the longest substring without repeating characters.\n\nNote: Users are expected to solve in O(N) time complexity.\n\n\n\nProblem Constraints\n1 <= size(A) <= 106\n\n String consists of lowerCase,upperCase characters and digits are also present in the string A.\n\n\n\nInput Format\nSingle Argument representing string A.\n\n\n\nOutput Format\nReturn an integer denoting the maximum possible length of substring without repeating characters.\n\n\n\nExample Input\nInput 1:\n\n A = \"abcabcbb\"\nInput 2:\n\n A = \"AaaA\"\n\n\nExample Output\nOutput 1:\n\n 3\nOutput 2:\n\n 2\n\n\nExample Explanation\nExplanation 1:\n\n Substring \"abc\" is the longest substring without repeating characters in string A.\nExplanation 2:\n\n Substring \"Aa\" or \"aA\" is the longest substring without repeating characters in string A.\n\n\nAnswer :-\n/**\n * @input A : String termination by \'\\0\'\n * \n * @Output Integer\n */\nint lengthOfLongestSubstring(char* A) {\n    int * hash=(int *)calloc(sizeof(int),256);\n    int max=1;\n    int len=0;\n    int i;\n    for(i=0;A[i]!=\'\\0\';i++)\n    {\n        \n        int x=A[i];\n        len++;\n        //printf(\"i:%d char:%c hash[x]:%d len:%d max:%d\\n\",i+1,A[i],hash[A[i]],len,max);\n        if(hash[x]==0)\n            {\n                hash[x]=i+1;\n            }\n        else\n            {\n                \n                int diff=(i+1)-hash[x];\n                if(len>diff)\n                    {\n                        if(len-1>max)\n                            max=len-1;\n                        len=diff;\n                    }\n                hash[x]=i+1;\n            }\n    }\n    //printf(\"Final len: %d\",len);\n    if(len>max)\n        max=len;\n    return max;\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=RqxIXM6eyiY&pp=ygUtaW50ZXJ2aWV3Yml0IGxvbmdlc3Qgc3Vic3RyaW5nIHdpdGhvdXQgcmVwZWF0',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
