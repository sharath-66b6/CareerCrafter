import '/flutter_flow/flutter_flow_util.dart';
import 'longestsubstringwithoutrepeat_widget.dart'
    show LongestsubstringwithoutrepeatWidget;
import 'package:flutter/material.dart';

class LongestsubstringwithoutrepeatModel
    extends FlutterFlowModel<LongestsubstringwithoutrepeatWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
