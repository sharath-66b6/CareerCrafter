import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'klargestelements_model.dart';
export 'klargestelements_model.dart';

class KlargestelementsWidget extends StatefulWidget {
  const KlargestelementsWidget({super.key});

  @override
  State<KlargestelementsWidget> createState() => _KlargestelementsWidgetState();
}

class _KlargestelementsWidgetState extends State<KlargestelementsWidget> {
  late KlargestelementsModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => KlargestelementsModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'K Largest Elements',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2400.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nGiven an 1D integer array A of size N you have to find and return the B largest elements of the array A.\n\nNOTE:\n\nReturn the largest B elements in any order you like.\n\n\nProblem Constraints\n1 <= N <= 105\n\n1 <= B <= N\n\n1 <= A[i] <= 103\n\n\n\nInput Format\nFirst argument is an 1D integer array A\n\nSecond argument is an integer B.\n\n\n\nOutput Format\nReturn a 1D array of size B denoting the B largest elements.\n\n\n\nExample Input\nInput 1:\n\n A = [11, 3, 4]\n B = 2\nInput 2:\n\n A = [11, 3, 4, 6]\n B = 3\n\n\nExample Output\nOutput 1:\n\n [11, 4]\nOutput 2:\n\n [4, 6, 11]\n\n\nExample Explanation\nExplanation 1:\n\n The two largest elements of A are 11 and 4\nExplanation 2:\n\n The three largest elements of A are 11, 4 and 6\n\n\n\n\nAnswer :-\n/**\n * @input A : Integer array\n * @input n1 : Integer array\'s ( A ) length\n * @input B : Integer\n * \n * @Output Integer array. You need to malloc memory, and fill the length in len1\n */\nvoid heapify(int *arr,int i,int n)\n{\n    if(n==0)\n        return;\n    int l,r,min=arr[i],j=i,temp;\n    l=2*i+1;\n    r=2*i+2;\n    if(l<n && arr[l]>min)\n    {\n        j=l;\n        min=arr[l];\n    }\n    if(r<n && arr[r]>min)\n    {\n        j=r;\n        min=arr[r];\n    }\n    if(j!=i)\n    {\n        temp=arr[j];\n        arr[j]=arr[i];\n        arr[i]=temp;\n        heapify(arr,j,n);\n    }\n        \n    \n}\nint *bheap(int *arr,int n)\n{\n    int i;\n    for(i=n/2-1;i>=0;i--)\n        heapify(arr,i,n);\n    return arr;\n}\n\nint* solve(int* A, int n1, int B, int *len1) {\n    int *arr,i;\n    if(B==0)\n        return NULL;\n    //if(B==n1)\n    //    return A;\n    *len1=B;\n    arr=(int *)malloc(*len1*sizeof(int));\n    A=bheap(A,n1);\n    for(i=0;i<B;i++)\n    {\n        arr[i]=A[0];\n        A[0]=A[n1-1-i];\n        heapify(A,0,n1-1-i);\n    }\n   // for(i=0;i<B;i++)\n    //    arr[i]=A[i];\n    return arr;\n    //*len1=B;\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=4UXfNU-OOR0&pp=ygUfaW50ZXJ2aWV3Yml0IGsgbGFyZ2VzdCBlbGVtZW50cw%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
