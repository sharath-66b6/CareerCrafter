import '/flutter_flow/flutter_flow_util.dart';
import 'klargestelements_widget.dart' show KlargestelementsWidget;
import 'package:flutter/material.dart';

class KlargestelementsModel extends FlutterFlowModel<KlargestelementsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
