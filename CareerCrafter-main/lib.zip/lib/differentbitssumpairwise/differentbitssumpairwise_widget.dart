import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'differentbitssumpairwise_model.dart';
export 'differentbitssumpairwise_model.dart';

class DifferentbitssumpairwiseWidget extends StatefulWidget {
  const DifferentbitssumpairwiseWidget({super.key});

  @override
  State<DifferentbitssumpairwiseWidget> createState() =>
      _DifferentbitssumpairwiseWidgetState();
}

class _DifferentbitssumpairwiseWidgetState
    extends State<DifferentbitssumpairwiseWidget> {
  late DifferentbitssumpairwiseModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => DifferentbitssumpairwiseModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Different Bits Sum Pairwise',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1900.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nWe define f(X, Y) as the number of different corresponding bits in the binary representation of X and Y. \nFor example, f(2, 7) = 2, since the binary representation of 2 and 7 are 010 and 111, respectively. The first and the third bit differ, so f(2, 7) = 2.\n\nYou are given an array of N positive integers, A1, A2,..., AN. Find sum of f(Ai, Aj) for all pairs (i, j) such that 1 ≤ i, j ≤ N. Return the answer modulo 109+7.\n\n\n\nProblem Constraints\n1 <= N <= 105\n\n1 <= A[i] <= 231 - 1\n\n\n\nInput Format\nThe first and only argument of input contains a single integer array A.\n\n\n\nOutput Format\nReturn a single integer denoting the sum.\n\n\n\nExample Input\nInput 1:\n\n A = [1, 3, 5]\nInput 2:\n\n A = [2, 3]\n\n\nExample Output\nOuptut 1:\n\n 8\nOutput 2:\n\n 2\n\n\nExample Explanation\nExplanation 1: \n\n f(1, 1) + f(1, 3) + f(1, 5) + f(3, 1) + f(3, 3) + f(3, 5) + f(5, 1) + f(5, 3) + f(5, 5) \n = 0 + 1 + 1 + 1 + 0 + 2 + 1 + 2 + 0 = 8\nExplanation 2:\n\n f(2, 2) + f(2, 3) + f(3, 2) + f(3, 3) = 0 + 1 + 1 + 0 = 2\n\n\n\nAnswer :-\n/**\n * @input A : Integer array\n * @input n1 : Integer array\'s ( A ) length\n * \n * @Output Integer\n */\n #define li 1000000007\nint cntBits(int* A, int n) {\n    \n    long long int ans=0; //return value\n    int i,j,k;\n   long long int count0,count1; //count of no of 0s and 1s\n   for(i=0;i<32;i++)\n   {  count0=0,count1=0;\n       for(j=0;j<n;j++)\n        {\n            if(A[j]%2==1)\n            {\n                count1++;\n            }\n            else\n              count0++;\n           A[j]/=2;   \n        }\n       ans=(ans+(2*((count0*count1)%li))%li)%li;\n   }\n   int p=ans;\n   return p;\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=OKROwC2fLEg&pp=ygUoaW50ZXJ2aWV3Yml0IGRpZmZlcmVudCBiaXRzIHN1bSBwYWlyd2lzZQ%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
