import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'nextsimilarnumber_model.dart';
export 'nextsimilarnumber_model.dart';

class NextsimilarnumberWidget extends StatefulWidget {
  const NextsimilarnumberWidget({super.key});

  @override
  State<NextsimilarnumberWidget> createState() =>
      _NextsimilarnumberWidgetState();
}

class _NextsimilarnumberWidgetState extends State<NextsimilarnumberWidget> {
  late NextsimilarnumberModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => NextsimilarnumberModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Next Similar Number',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2600.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nGiven a number A in a form of string.\n\nYou have to find the smallest number that has same set of digits as A and is greater than A.\n\nIf A is the greatest possible number with its set of digits, then return -1.\n\n\n\nProblem Constraints\n 1 <= A <= 10100000\n\n A doesn\'t contain leading zeroes.\n\n\n\nInput Format\nFirst and only argument is an numeric string denoting the number A.\n\n\n\nOutput Format\nReturn a string denoting the smallest number greater than A with same set of digits , if A is the largest possible then return -1.\n\n\n\nExample Input\nInput 1:\n\n A = \"218765\"\nInput 2:\n\n A = \"4321\"\n\n\nExample Output\nOutput 1:\n\n \"251678\"\nOutput 2:\n\n \"-1\"\n\n\nExample Explanation\nExplanation 1:\n\n The smallest number greater then 218765 with same set of digits is 251678.\nExplanation 2:\n\n The given number is the largest possible number with given set of digits so we will return -1.\n\n\n\nAnswer :-\n/**\n * @input A : String termination by \'\\0\'\n * \n * @Output string. Make sure the string ends with null character\n */\nchar *sort(char *string,int a,int b)\n{\n    int i,j;char temp;\n    for (i = a; i < b-1; i++) \n    {\n      for (j = i+1; j < b; j++) \n      {\n         if (string[i] > string[j]) \n         {\n            temp = string[i];\n            string[i] = string[j];\n            string[j] = temp;\n         }\n      }\n   }\n   return string;\n}\nchar* solve(char* A) \n{\n    int i=0;int len=strlen(A);int desc=1,digit,index,min=INT_MAX,min_index;\n    while(A[i]!=\'\\0\' && i<len-1)\n    {\n        if(A[i+1]>A[i])\n        {\n            desc=0;\n            break;\n        }\n            i++;\n            \n    }\n    if(desc==1)\n    return \"-1\";\n    else\n    {\n       for(i=len-1;i>=0;i--)\n       {\n           if(A[i-1]<A[i])\n           {\n           digit=A[i-1];\n           index=i-1;\n           break;\n           }\n       }\n      // printf(\"digit=%d at index=%d\\n\",digit,index);\n       \n       for(i=index+1;i<=len-1;i++)\n       {\n           if(A[i]<min && A[i]>A[index])\n           {\n           min=A[i];\n           min_index=i;\n           }\n       }\n       //printf(\"min=%d at min_index=%d\\n\",min,min_index);\n       A[index]=min;\n       A[min_index]=digit;\n       //printf(\"A[index]=%d A[min_index]=%d\\n\",A[index],A[min_index]);\n       A=sort(A,index+1,len);\n       \n    }\n    return A;\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=-h1FHkDxpKs&pp=ygUgaW50ZXJ2aWV3Yml0IG5leHQgc2ltaWxhciBudW1iZXI%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
