import '/flutter_flow/flutter_flow_util.dart';
import 'nextsimilarnumber_widget.dart' show NextsimilarnumberWidget;
import 'package:flutter/material.dart';

class NextsimilarnumberModel extends FlutterFlowModel<NextsimilarnumberWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
