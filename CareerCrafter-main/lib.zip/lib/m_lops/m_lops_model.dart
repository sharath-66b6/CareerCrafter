import '/flutter_flow/flutter_flow_util.dart';
import 'm_lops_widget.dart' show MLopsWidget;
import 'package:flutter/material.dart';

class MLopsModel extends FlutterFlowModel<MLopsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
