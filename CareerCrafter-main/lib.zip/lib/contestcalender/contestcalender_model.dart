import '/flutter_flow/flutter_flow_util.dart';
import 'contestcalender_widget.dart' show ContestcalenderWidget;
import 'package:flutter/material.dart';

class ContestcalenderModel extends FlutterFlowModel<ContestcalenderWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
