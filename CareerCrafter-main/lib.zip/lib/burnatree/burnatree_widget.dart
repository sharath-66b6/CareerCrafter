import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'burnatree_model.dart';
export 'burnatree_model.dart';

class BurnatreeWidget extends StatefulWidget {
  const BurnatreeWidget({super.key});

  @override
  State<BurnatreeWidget> createState() => _BurnatreeWidgetState();
}

class _BurnatreeWidgetState extends State<BurnatreeWidget> {
  late BurnatreeModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => BurnatreeModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Burn a Tree',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 3600.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n\nGiven a binary tree denoted by root node A and a leaf node B from this tree.\n\n It is known that all nodes connected to a given node (left child, right child and parent) get burned in 1 second. Then all the nodes which are connected through one intermediate get burned in 2 seconds, and so on.\n\nYou need to find the minimum time required to burn the complete binary tree.\n\n\n\nProblem Constraints\n2 <= number of nodes <= 105\n\n1 <= node value, B <= 105\n\nnode value will be distinct\n\n\n\nInput Format\nFirst argument is a root node of the binary tree, A.\n\nSecond argument is an integer B denoting the node value of leaf node.\n\n\n\nOutput Format\nReturn an integer denoting the minimum time required to burn the complete binary tree.\n\n\n\nExample Input\nInput 1:\n\n Tree :      1 \n            / \\ \n           2   3 \n          /   / \\\n         4   5   6\n B = 4\nInput 2:\n\n Tree :      1\n            / \\\n           2   3\n          /     \\\n         4       5 \n B = 5 \n\n\nExample Output\nOutput 1:\n\n 4\nOutput 2:\n\n 4\n\n\nExample Explanation\nExplanation 1:\n\n After 1 sec: Node 4 and 2 will be burnt. \n After 2 sec: Node 4, 2, 1 will be burnt.\n After 3 sec: Node 4, 2, 1, 3 will be burnt.\n After 4 sec: Node 4, 2, 1, 3, 5, 6(whole tree) will be burnt.\n \nExplanation 2:\n\n After 1 sec: Node 5 and 3 will be burnt. \n After 2 sec: Node 5, 3, 1 will be burnt.\n After 3 sec: Node 5, 3, 1, 2 will be burnt.\n After 4 sec: Node 5, 3, 1, 2, 4(whole tree) will be burnt.\n\n\n\nAnswer :-\n/**\n * Definition for binary tree\n * struct TreeNode {\n *     int val;\n *     struct TreeNode *left;\n *     struct TreeNode *right;\n * };\n * \n * typedef struct TreeNode treenode;\n * \n * treenode* treenode_new(int val) {\n *     treenode* node = (treenode *) malloc(sizeof(treenode));\n *     node->val = val;\n *     node->left = NULL;\n *     node->right = NULL;\n *     return node;\n * }\n */\n/**\n * @input A : Root pointer of the tree \n * @input B : Integer\n * \n * @Output Integer\n */\n\nstruct info{\n    \n    int left;\n    int right;\n    int timer;\n    int contains;\n};\n\nstruct info newNode(){\n    \n    struct info New;\n    New.left = 0 ;\n    New.right = 0;\n    New.timer = -1;\n    New.contains = 0;\n    return New;\n} \n\nint mx(int a , int b){\n    if(a>=b)\n        return a;\n    else    \n        return b;    \n}\n\nstruct info findAns(treenode* root , int target, int *res, struct info Info)\n{\n    if(root == NULL)\n        return Info;\n        \n    if(root->val == target){\n        Info.contains = 1;\n        Info.left = Info.right = Info.timer =0;\n        return Info;\n    }\n    \n    struct info left = newNode();\n    left = findAns(root->left,target,res,left);\n    \n    struct info right = newNode();\n    right = findAns(root->right,target,res,right);\n    \n    if(root->left)\n        Info.left =  1 + mx(left.left , left.right);\n        \n    if(root->right)    \n        Info.right = 1 + mx(right.left , right.right);\n    \n    if(left.contains || right.contains) Info.contains = 1;\n    \n    if(root->left && left.contains){\n        Info.timer = left.timer +1;   \n    }\n    if(root->right && right.contains){\n        Info.timer = right.timer+1;\n    }\n        \n    if(Info.contains){\n        \n        if(root->left && left.contains){\n            *res = mx(*res,  Info.timer + Info.right);\n        }\n        else if(root->right && right.contains){\n            *res = mx(*res,  Info.timer + Info.left);\n        }\n    }\n    return Info;\n}\n \nint solve(treenode* root, int target) {\n    \n    int res = INT_MIN;\n    struct info a = newNode();\n    //printf(\"%d %d %d %d\",a.left,a.right,a.timer,a.contains);\n    a = findAns(root,target, &res,a);\n    return res;\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=gvH2RACiR4Y&pp=ygUYaW50ZXJ2aWV3Yml0IGJ1cm4gYSB0cmVl',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
