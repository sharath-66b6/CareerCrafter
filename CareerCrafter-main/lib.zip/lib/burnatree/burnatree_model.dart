import '/flutter_flow/flutter_flow_util.dart';
import 'burnatree_widget.dart' show BurnatreeWidget;
import 'package:flutter/material.dart';

class BurnatreeModel extends FlutterFlowModel<BurnatreeWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
