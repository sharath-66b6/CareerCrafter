import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'addbinarystrings_model.dart';
export 'addbinarystrings_model.dart';

class AddbinarystringsWidget extends StatefulWidget {
  const AddbinarystringsWidget({super.key});

  @override
  State<AddbinarystringsWidget> createState() => _AddbinarystringsWidgetState();
}

class _AddbinarystringsWidgetState extends State<AddbinarystringsWidget> {
  late AddbinarystringsModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => AddbinarystringsModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Add Binary Strings',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 1700.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven two binary strings A and B. Return their sum (also a binary string).\n\n\nProblem Constraints\n1 <= length of A <= 105\n\n1 <= length of B <= 105\n\nA and B are binary strings\n\n\n\nInput Format\nThe two argument A and B are binary strings.\n\n\n\nOutput Format\nReturn a binary string denoting the sum of A and B\n\n\n\nExample Input\nInput 1:\nA = \"100\"\nB = \"11\"\nInput 2:\nA = \"110\"\nB = \"10\"\n\n\nExample Output\nOutput 1:\n\"111\"\nOutput 2:\n\"1000\"\n\n\nExample Explanation\nFor Input 1:\nThe sum of 100 and 11 is 111.\nFor Input 2:\n \nThe sum of 110 and 10 is 1000.\n\n\nAnswer:-\n/**\n * @input A : String termination by \'\\0\'\n * @input B : String termination by \'\\0\'\n * \n * @Output string. Make sure the string ends with null character\n */\nchar* addBinary(char* A, char* B) {\n    int len=(strlen(A)>=strlen(B))?strlen(A):strlen(B);\n    char *C=(char *)malloc((len+5)*sizeof(char));\n    int j=strlen(A)-1, m=strlen(B)-1,carry=0,i=0;\n    while(j>=0 && m>=0){\n        carry=carry+(A[j]-\'0\')+(B[m]-\'0\');   j--; m--;\n        C[i++]=(carry%2+\'0\'); carry/=2;\n    }\n    while(j>=0){\n        carry=carry+(A[j]-\'0\'); j--;\n        C[i++]=(carry%2+\'0\');  carry/=2;\n    }\n    while(m>=0){\n        carry=carry+(B[m]-\'0\');  m--;\n        C[i++]=(carry%2+\'0\'); carry/=2;\n    }\n    if(carry) C[i++]=carry+\'0\';\n    for(j=0;j<i/2;j++){\n        char ch=C[j]; C[j]=C[i-1-j]; C[i-1-j]=ch;\n    } C[i]=\'\\0\';\n    return C;\n}\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=ZUt8L8cbbBI&pp=ygUeaW50ZXJ2aWV3Yml0IGFkZCBiaW5hcnkgc3RyaW5n',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
