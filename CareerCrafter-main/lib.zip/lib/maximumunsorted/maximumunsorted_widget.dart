import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'maximumunsorted_model.dart';
export 'maximumunsorted_model.dart';

class MaximumunsortedWidget extends StatefulWidget {
  const MaximumunsortedWidget({super.key});

  @override
  State<MaximumunsortedWidget> createState() => _MaximumunsortedWidgetState();
}

class _MaximumunsortedWidgetState extends State<MaximumunsortedWidget> {
  late MaximumunsortedModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MaximumunsortedModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Maximum Unsorted Subarray',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven an array A of non-negative integers of size N. Find the minimum sub-array Al, Al+1 ,..., Ar such that if we sort(in ascending order) that sub-array, then the whole array should get sorted.\nIf A is already sorted, output -1.\n\n\n\nProblem Constraints\n1 <= N <= 1000000\n\n1 <= A[i] <= 1000000\n\n\n\nInput Format\nFirst and only argument is an array of non-negative integers of size N.\n\n\n\nOutput Format\nReturn an array of length two where the first element denotes the starting index(0-based) and the second element denotes the ending index(0-based) of the sub-array. If the array is already sorted, return an array containing only one element i.e. -1.\n\n\n\nExample Input\nInput 1:\n\nA = [1, 3, 2, 4, 5]\nInput 2:\n\nA = [1, 2, 3, 4, 5]\n\n\nExample Output\nOutput 1:\n\n[1, 2]\nOutput 2:\n\n[-1]\n\n\nExample Explanation\nExplanation 1:\n\nIf we sort the sub-array A1, A2, then the whole array A gets sorted.\nExplanation 2:\n\nA is already sorted.\n\n\n\nAnswer :-\n/**\n * @input A : Integer array\n * @input n1 : Integer array\'s ( A ) length\n * \n * @Output Integer array. You need to malloc memory, and fill the length in len1\n */\nint* subUnsort(int* A, int n1, int *len1) {\n    int l, h;\n    l=0; h = n1-1;\n    int* res;\n    int i, k=0;\n    for(l=0;l<n1-1;l++){\n        if(A[l]>A[l+1]){\n            break;\n        }\n    }\n   // printf(\"here i am %d\", l);\n    if(l==n1-1){\n        *len1 = 1;\n        res = (int *)malloc(sizeof(int)*(*len1));\n        res[0] = -1;\n        \n        return res;\n    }\n    \n    for(h=n1-1;h>0;h--){\n        if(A[h]<A[h-1]){\n            break;\n        }\n    }\n    int max = A[l], min = A[l];\n    for(i=l+1;i<=h;i++){\n        if(max<A[i])\n            max = A[i];\n        if(min>A[i])\n            min = A[i];\n    }\n    \n    for(i=0;i<l;i++){\n        if(A[i]>min){\n            l= i;\n            break;\n        }\n    }\n    for(i=n1-1;i>=h+1;i--){\n        if(A[i]<max){\n            h= i;\n            break;\n        }\n    }\n   // printf(\"len = %d\",l);\n    *len1 = 2;k=0;\n    res = (int *)malloc(sizeof(int)*(*len1));\n    res[0] = l; res[1] = h;\n    return res;\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=Ov6dnq8ShgQ&pp=ygUmaW50ZXJ2aWV3Yml0IG1heGltdW0gdW5zb3J0ZWQgc3ViYXJyYXk%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
