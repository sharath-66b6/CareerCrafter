import '/flutter_flow/flutter_flow_util.dart';
import 'maximumunsorted_widget.dart' show MaximumunsortedWidget;
import 'package:flutter/material.dart';

class MaximumunsortedModel extends FlutterFlowModel<MaximumunsortedWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
