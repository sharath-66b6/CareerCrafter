import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'maximumsizesquaresubmatrix_model.dart';
export 'maximumsizesquaresubmatrix_model.dart';

class MaximumsizesquaresubmatrixWidget extends StatefulWidget {
  const MaximumsizesquaresubmatrixWidget({super.key});

  @override
  State<MaximumsizesquaresubmatrixWidget> createState() =>
      _MaximumsizesquaresubmatrixWidgetState();
}

class _MaximumsizesquaresubmatrixWidgetState
    extends State<MaximumsizesquaresubmatrixWidget> {
  late MaximumsizesquaresubmatrixModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MaximumsizesquaresubmatrixModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Maximum Size Square Sub-matrix',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2700.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven a 2D binary matrix A of size  N x M  find the area of maximum size square sub-matrix with all 1\'s.\n\n\n\nProblem Constraints\n1 <= N, M <= 103\n\n A[i][j] = 1 or A[i][j] = 0\n\n\n\nInput Format\nFirst argument is an 2D matrix A of size N x M.\n\n\n\nOutput Format\nOutput the area of maximum size square sub-matrix in A with all 1\'s.\n\n\n\nExample Input\nInput 1:\n\n A = [\n\n        [0, 1, 1, 0, 1],\n\n        [1, 1, 0, 1, 0],\n\n        [0, 1, 1, 1, 0],\n\n        [1, 1, 1, 1, 0],\n\n        [1, 1, 1, 1, 1],\n\n        [0, 0, 0, 0, 0]\n     ]\nInput 2:\n\n A = [\n\n       [1, 1],\n       [1, 1]\n     ]\n\n\nExample Output\nOutput 1:\n\n 9\nOutput 2:\n\n 4\n\n\nExample Explanation\nExplanation 1:\n\n  Consider the below binary matrix.\n \n The area of the square is 3 * 3 = 9\nExplanation 2:\n\n The given matrix is the largest size square possible so area will be 2 * 2 = 4\n\n\n\n\nAnswer :-\n/**\n * @input A : 2D integer array \n * @input n11 : Integer array\'s ( A ) rows\n * @input n12 : Integer array\'s ( A ) columns\n * \n * @Output Integer\n */\nint ma(int a, int b){\n    if(a>b)\n    return a;\n    else \n    return b;\n}\nint mi(int a, int b){\n    if(a<b)\n    return a;\n    else \n    return b;\n}\nint max(int a, int b, int c){\n    if(a>ma(b,c))\n    return a;\n    else \n    return ma(b,c);\n}\nint min(int a, int b, int c){\n    if(a<mi(b,c))\n    return a;\n    else \n    return mi(b,c);\n}\nint solve(int** A, int n11, int n12) {\n    int arr[n11][n12];\n    int i,j;\n    int m=0;\n    for(i=0;i<n11;i++)\n    {\n        for(j=0;j<n12;j++)\n        {\n            if((j==0)||(i==0))\n            {\n                if(A[i][j]==0)\n                arr[i][j]=0;\n                else\n                arr[i][j]=1;\n            }\n            else if(A[i][j]==0)\n            {\n                arr[i][j]=max(arr[i-1][j],arr[i][j-1],arr[i-1][j-1]);\n            }\n            else\n            {\n                arr[i][j]=min(A[i-1][j]*arr[i-1][j],A[i][j-1]*arr[i][j-1],A[i-1][j-1]*arr[i-1][j-1])+1;\n            }\n            if(arr[i][j]>m)\n            m=arr[i][j];\n            //printf(\"%d %d %d \\n\",i,j,arr[i][j]);\n        }\n    }\n    return m*m;\n}\n\n',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=WxjYE4_agbo&pp=ygUraW50ZXJ2aWV3Yml0IG1heGltdW0gc2l6ZSBzcXVhcmUgc3ViIG1hdHJpeA%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
