import '/flutter_flow/flutter_flow_util.dart';
import 'maximumsizesquaresubmatrix_widget.dart'
    show MaximumsizesquaresubmatrixWidget;
import 'package:flutter/material.dart';

class MaximumsizesquaresubmatrixModel
    extends FlutterFlowModel<MaximumsizesquaresubmatrixWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
