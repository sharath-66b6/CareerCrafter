import '/flutter_flow/flutter_flow_util.dart';
import 'microsoftprinciple_widget.dart' show MicrosoftprincipleWidget;
import 'package:flutter/material.dart';

class MicrosoftprincipleModel
    extends FlutterFlowModel<MicrosoftprincipleWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
