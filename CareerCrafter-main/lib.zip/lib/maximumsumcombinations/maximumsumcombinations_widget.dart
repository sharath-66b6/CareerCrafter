import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_youtube_player.dart';
import 'package:flutter/material.dart';
import 'maximumsumcombinations_model.dart';
export 'maximumsumcombinations_model.dart';

class MaximumsumcombinationsWidget extends StatefulWidget {
  const MaximumsumcombinationsWidget({super.key});

  @override
  State<MaximumsumcombinationsWidget> createState() =>
      _MaximumsumcombinationsWidgetState();
}

class _MaximumsumcombinationsWidgetState
    extends State<MaximumsumcombinationsWidget> {
  late MaximumsumcombinationsModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MaximumsumcombinationsModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubeFullScreenWrapper(
      child: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          appBar: AppBar(
            backgroundColor: FlutterFlowTheme.of(context).primary,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30.0,
              borderWidth: 1.0,
              buttonSize: 60.0,
              icon: const Icon(
                Icons.arrow_back_rounded,
                color: Colors.white,
                size: 30.0,
              ),
              onPressed: () async {
                context.pop();
              },
            ),
            title: Text(
              'Maximum Sum Combinations',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Outfit',
                    color: Colors.white,
                    fontSize: 22.0,
                    letterSpacing: 0.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 2.0,
          ),
          body: SafeArea(
            top: true,
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              scrollDirection: Axis.vertical,
              children: [
                Container(
                  width: 100.0,
                  height: 2400.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: Align(
                    alignment: const AlignmentDirectional(0.0, -1.0),
                    child: Text(
                      'Problem Description\n \n \n\nGiven two equally sized 1-D arrays A, B containing N integers each.\n\nA sum combination is made by adding one element from array A and another element of array B.\n\nReturn the maximum C valid sum combinations from all the possible sum combinations.\n\n\n\nProblem Constraints\n1 <= N <= 105\n\n1 <= A[i] <= 105\n\n1 <= C <= N\n\n\n\nInput Format\nFirst argument is an one-dimensional integer array A of size N.\n\nSecond argument is an one-dimensional integer array B of size N.\n\nThird argument is an integer C.\n\n\n\nOutput Format\nReturn a one-dimensional integer array of size C denoting the top C maximum sum combinations.\n\nNOTE:\n\nThe returned array must be sorted in non-increasing order.\n\n\n\nExample Input\nInput 1:\n\n A = [3, 2]\n B = [1, 4]\n C = 2\nInput 2:\n\n A = [1, 4, 2, 3]\n B = [2, 5, 1, 6]\n C = 4\n\n\nExample Output\nOutput 1:\n\n [7, 6]\nOutput 1:\n\n [10, 9, 9, 8]\n\n\nExample Explanation\nExplanation 1:\n\n 7     (A : 3) + (B : 4)\n 6     (A : 2) + (B : 4)\nExplanation 2:\n\n 10   (A : 4) + (B : 6)\n 9   (A : 4) + (B : 5)\n 9   (A : 3) + (B : 6)\n 8   (A : 3) + (B : 5)\n\n\n\n\n\n\nAnswer :- \nfrom heapq import heappush, heappop\n\nclass Solution:\n    # @param A : list of integers\n    # @param B : list of integers\n    # @param C : integer\n    # @return a list of integers\n    def solve(self, A, B, C):\n        A.sort()\n        B.sort()\n        # print A\n        # print B\n        ans = []\n        N = len(A)\n\n        pq = []\n        my_set = set()\n\n        heappush(pq, [-(A[N - 1] + B[N - 1]), (N - 1, N - 1)])\n        my_set.add((N - 1, N - 1))\n\n        for count in range(C):\n            temp = heappop(pq)\n            ans.append(-temp[0])\n\n            i = temp[1][0]\n            j = temp[1][1]\n\n            if i >= 1:\n                sm = A[i - 1] + B[j]\n                temp1 = (i - 1, j)\n                if temp1 not in my_set:\n                    heappush(pq, [-sm, temp1])\n                    my_set.add(temp1)\n\n            if j >= 1:\n                sm = A[i] + B[j - 1]\n                temp2 = (i, j - 1)\n                if temp2 not in my_set:\n                    heappush(pq, [-sm, temp2])\n                    my_set.add(temp2)\n\n        return ans',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            letterSpacing: 0.0,
                          ),
                    ),
                  ),
                ),
                Container(
                  width: 100.0,
                  height: 300.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                  child: const FlutterFlowYoutubePlayer(
                    url:
                        'https://www.youtube.com/watch?v=Vf9A6deeZhA&pp=ygUlaW50ZXJ2aWV3Yml0IG1heGltdW0gc3VtIGNvbWJpbmF0aW9ucw%3D%3D',
                    autoPlay: false,
                    looping: true,
                    mute: false,
                    showControls: true,
                    showFullScreen: true,
                    strictRelatedVideos: false,
                  ),
                ),
              ].divide(const SizedBox(height: 12.0)),
            ),
          ),
        ),
      ),
    );
  }
}
