import '/flutter_flow/flutter_flow_util.dart';
import 'maximumsumcombinations_widget.dart' show MaximumsumcombinationsWidget;
import 'package:flutter/material.dart';

class MaximumsumcombinationsModel
    extends FlutterFlowModel<MaximumsumcombinationsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
